<?php
defined('IN_ADMIN') or exit('No permission resources.');
include $this->admin_tpl('header');?>
<form name="searchform" action="" method="get" >
<input type="hidden" value="admin" name="m">
<input type="hidden" value="category" name="c">
<input type="hidden" value="search_list" name="a">
<table width="100%" cellspacing="0" class="search-form">
    <tbody>
        <tr>
        <td>
        <div class="explain-col">  
                <input name="keyword" type="text" style="width:400px" value="<?php if(isset($keyword)) echo $keyword;?>" class="input-text" />
                <input type="submit" name="search" class="button" value="<?php echo L('search');?>" />
    </div>
        </td>
        </tr>
    </tbody>
</table>
</form>
<form name="myform" action="?m=admin&c=category&a=listorder" method="post">
<div class="pad_10">
<div class="explain-col">
<?php echo L('category_cache_tips');?>，<a href="?m=admin&c=category&a=public_cache&menuid=43&module=admin"><?php echo L('update_cache');?></a>
</div>
<div class="bk10"></div>
<div class="table-list">
    <table width="100%" cellspacing="0" >
        <thead>
            <tr>
            <th width="38"><?php echo L('listorder');?></th>
            <th width="30">栏目id</th>
            <th ><?php echo L('catname');?></th>
            <th align='left' width='50'><?php echo L('category_type');?></th>
            <th align='left' width="50"><?php echo L('modelname');?></th>
            <th align='center' width="40"><?php echo L('items');?></th>
            <th align='center' width="30"><?php echo L('vistor');?></th>
            <th align='center' width="80"><?php echo L('domain_help');?></th>
            <th ><?php echo L('operations_manage');?></th>
            </tr>
        </thead>
    <tbody>
    <?php 
        foreach ($categorys as $r) {
     ?>
        
        <tr>
                    <td align='center'><input name='listorders[<?php echo $r['catid']?>]' type='text' size='3' value='<?php echo $r['listorder']?>' class='input-text-c'></td>
                    <td align='center'><?php echo $r['catid']?></td>
                    <td ><?php echo $r['spacer'].$r['catname'].$r['display_icon']?></td>
                    <td><?php echo $r['typename']?></td>
                    <td><?php echo $r['modelname']?></td>
                    <td align='center'><?php echo $r['items']?></td>
                    <td align='center'><?php echo $r['url'] ?></td>
                    <td align='center'><?php echo $r['help'] ?></td>
                    <td align='center' ><?php echo $r['str_manage']?></td>
                </tr>
                
    <?php }?>
    </tbody>
    </table>

    <div class="btn">
    <input type="hidden" name="pc_hash" value="<?php echo $_SESSION['pc_hash'];?>" />
    <input type="submit" class="button" name="dosubmit" value="<?php echo L('listorder')?>" /></div>  </div>
</div>
</div>
<div id="pages"><?php echo $pages?></div>
</form>
<script language="JavaScript">
<!--
    window.top.$('#display_center_id').css('display','none');
//-->
</script>
</body>
</html>
