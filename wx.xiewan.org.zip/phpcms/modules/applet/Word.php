<?php
require_once "vendor/autoload.php";
require_once "vendor/fukuball/jieba-php/src/vendor/multi-array/MultiArray.php";
require_once "vendor/fukuball/jieba-php/src/vendor/multi-array/Factory/MultiArrayFactory.php";
require_once "vendor/fukuball/jieba-php/src/class/Jieba.php";
require_once 'task/DB.php';

use Fukuball\Jieba\Jieba;

/**
 * 识别敏感词汇
 * Class Word
 */
class Word extends DB
{
	public function index(){
        $name = $_GET['command'];

        Jieba::init();

        Jieba::loadUserDict(dirname(__FILE__).'/vendor/fukuball/jieba-php/src/dict/word.txt');
        $listArr = Jieba::cut($name);

        foreach ($listArr as $key=>$val){
            $listArr[$key] = "'".$val."'";
        }
        $list = implode(',', $listArr);
        $command = $this->find("select * from v9_sensitive_words where name IN ($list)");

        $res = $command ? 2 : 1;
        echo json_encode(['res' => $res]);
	}
}
?>