<?php 
pc_base::load_app_class('foreground');
pc_base::load_sys_class('format', '', 0);
pc_base::load_sys_class('form', '', 0);
pc_base::load_app_func('util','content');

class WxApplet{

	/**
	**获取用户openid
	**
	*/
	public function userinfo(){
		$code = $_POST['code'];
		// $_POST['info']['nickname'] = $_POST['nickname'];
		// $_POST['info']['headimgurl'] = $_POST['headimgurl'];
		if(empty($code)){
			echo '{"msg":"code空"}';return;
		}
		$secret = pc_base::load_config('system','applet_appsecret');
		$applet_id = pc_base::load_config('system','applet_id');

		$ch = curl_init('https://api.weixin.qq.com/sns/jscode2session?appid='.$applet_id.'&secret='.$secret.'&js_code='.$code.'&grant_type=authorization_code');  
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST,"POST");  
        curl_setopt($ch, CURLOPT_POST, 1 );
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 1);
        $datajson = curl_exec ($ch);
        curl_close($ch);
		$result=json_decode($datajson,true);

        $openid = $result['openid']; 
        $Postdata['info']['openid'] = $result['openid'];
        $Postdata['info']['sex'] = $_POST['sex'];
        $Postdata['info']['userid'] = $userid = $this->getRandOnlyId();
        $Postdata['info']['nickname'] = $_POST['nickname'];
        $Postdata['info']['headimgurl'] = $_POST['headimgurl'];
        $Postdata['info']['create_time'] = time();

        $user = pc_base::load_model('wx_userinfo_model');
        $userdata = $user->get_one("`openid`= '$openid'",'id,userid,openid','id ASC');
		if(empty($userdata)){
			$result = $user->insert($Postdata['info']);
			if($result){
				echo '{"msg":"'.$userid.'","data":"'.$openid.'"}';return;
			}else{
				echo '{"msg":"no"}';return;
			}
		}else{
			echo '{"msg":"'.$userdata['userid'].'","data":"'.$userdata['openid'].'"}';return;
		}

	}
	/**
	**获取用户唯一id
	**
	*/
	public function getRandOnlyId() {
        $rand=rand(0,99);//两位随机
        $all=$rand.time();
        $num = 6;
        $onlyid=$num.base_convert($all,16,10);//把16进制转为10进制的唯一ID
        return $onlyid;
	}
	/**
	 * 下载微信用户头像
	 */
	public function getUserImg(){
		$openid = $_POST['openid'];
		$url = $_POST['headimgurl'];
		$saveName = $openid.".jpg"; 
		$path = PHPCMS_PATH."uploadfile/user/";

		if(file_exists($path.$saveName)){
			unlink($path.$saveName);
		}
		$image = file_get_contents($url); 
		$res = file_put_contents($path.$saveName, $image);

		if($res != false){ 
			$data = [
				'data' => "https://wx.xiewan.org/uploadfile/user/".$saveName,
			];
			echo json_encode([
				'msg' => 'success',
				'data' => $data,
			]);
			return;
		}else {
			echo json_encode([
				'msg' => 'fail',
			]);
			return;
		}
		
	}
}
?>