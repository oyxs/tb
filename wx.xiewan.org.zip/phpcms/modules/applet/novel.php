<?php 
pc_base::load_app_class('foreground');
pc_base::load_sys_class('format', '', 0);
pc_base::load_sys_class('form', '', 0);
pc_base::load_app_func('util','content');

class novel {

	/**
	**小说列表
	**
	*/
	public function index(){
		$news=pc_base::load_model('category_model');
	 	$catid = intval($_GET['catid']);
	 	if(empty($catid)){
	 		echo '{"Msg":"id空"}';return;
	 	}
	 	$page = isset($_GET['page']) && intval($_GET['page']) ? intval($_GET['page']) : 1;
        $pagesize = 20;
        $offset = $pagesize*($page-1);
	 	if($catid){
	 		$where="a.parentid= '$catid '";
	 		
            $data=$news->query("select a.catname, a.description,a.author,a.image,a.catid,a.novel_type,b.id FROM v9_category a left JOIN v9_news b ON a.catid = b.catid WHERE ".$where." GROUP BY b.catid having b.id is NOT null ORDER BY a.catid desc LIMIT ".$offset.",".$pagesize);
            $data = $news->fetch_array($data);

            if(empty($data)){
            	echo '{"Msg":"null"}';return;
            }
            $totalnums=$news->query("select a.catname, a.description,a.author,a.image,a.catid,a.novel_type,b.id FROM v9_category a left JOIN v9_news b ON a.catid = b.catid WHERE ".$where." GROUP BY b.catid having b.id is NOT null ");
            $totalnums = count($news->fetch_array($totalnums));

            $totalnums = isset($totalnums) ? $totalnums : 0;
            $pages = pages($totalnums, $page, $pagesize);
            $pagex=ceil($totalnums/$pagesize);
			    if($page<=$pagex){
			        $data[0]['next_page']=$page+1;
			    }
			    if($pagex>0){
			        $data[0]['sum_page']=$pagex;
			    }else if($pagex==0){
			        $data[0]['sum_page']=$pagex;
			    }
			    // for($i=0;$i<count($data);$i++){
			    // 	$data[$i]['description']=str_cut($data[$i]['description'],160);
			    // }
			     
			    $data= json_encode($data);
			    echo  $data;return;
	 	}
	}
	/**
	**小说详细页
	**
	*/
	public function NovelDetail(){
		$news=pc_base::load_model('category_model');
	 	$catid = intval($_GET['catid']);
	 	if(empty($catid)){
	 		echo '{"Msg":"id空"}';return;
	 	}
	 	$where="`catid`='$catid'  ";	
        $data=$news->get_one($where, 'catname,status,description,author,image,catid,novel_type,update_time','catid desc');
        if(empty($data)){
            echo '{"Msg":"null"}';return;
        }
        $data= json_encode($data);
        echo  $data;return;
	}
	/**
	**小说章节列表
	**
	*/
	public function chapterList(){
		$news=pc_base::load_model('news_model');
	 	$catid = intval($_GET['catid']);
	 	if(empty($catid)){
	 		echo '{"Msg":"id空"}';return;
	 	}
	 	$o_status = intval($_GET['order']);
	 	$page = isset($_GET['page']) && intval($_GET['page']) ? intval($_GET['page']) : 1;
	 	$pagesize = isset($_GET['pagesize']) && intval($_GET['pagesize']) ? intval($_GET['pagesize']) : 10;
        //$pagesize = 10;
        $offset = $pagesize*($page-1);
	 	if($catid){
	 		$where="`catid`= '$catid ' ";
	 		if($o_status == 1){
	 			$order = 'id asc';
	 		}else{
	 			$order = 'id desc';
	 		}
            $data=$news->select($where, 'id,title',$offset.','.$pagesize,$order);
            $totalnums=$news->count($where);
            $totalnums = isset($totalnums) ? $totalnums : 0;
            $pages = pages($totalnums, $page, $pagesize);
            $pagex=ceil($totalnums/$pagesize);
			    if($page<=$pagex){
			        $data[0]['next_page']=$page+1;
			    }
			    if($pagex>0){
			        $data[0]['sum_page']=$pagex;
			    }else if($pagex==0){
			        $data[0]['sum_page']=$pagex;
			    }
			     
			    $data= json_encode($data);
			    echo  $data;return;
	 	}
	}

	/**
	**最新章节
	**
	*/
	public function Newestchapter(){
		$news=pc_base::load_model('news_model');
	 	$catid = intval($_GET['catid']);
	 	if(empty($catid)){
	 		echo '{"Msg":"id空"}';return;
	 	}
	 	$Newest = $news -> get_one("catid = '$catid'", 'title,id','id desc');
	 	$totalnums=$news->count("catid = '$catid'");
	 	$Newest['sum']=$totalnums;
	 	$data= json_encode($Newest);
	 	echo $data;return;
	}
	/**
	**同类型小说
	**
	*/
	public function SameNovel(){
		$news=pc_base::load_model('category_model');
	 	$catid = intval($_GET['catid']);
	 	if(empty($catid)){
	 		echo '{"Msg":"id空"}';return;
	 	}
	 	$CATEGORYS = getcache('category_content_1','commons');
	 	$parentid=$CATEGORYS[$catid]['parentid'];
	 	$where ="parentid='$parentid' and catid != '$catid'";

        $data=$news->select($where , 'image,catname,catid','0,3','RAND()');    
        $data= json_encode($data);
		echo  $data;return; 
	}
	/**
	**小说阅读页面
	**
	*/
	public function NovelShow(){
		$news=pc_base::load_model('news_model');
		$category=pc_base::load_model('category_model');
	 	$news_data=pc_base::load_model('news_data_model');
	 	$catid = intval($_GET['catid']);
	 	$id = intval($_GET['novelid']);
	 	if(empty($catid)){
	 		echo '{"Msg":"id空"}';return;
	 	}
	 	if(empty($id)){
	 		$next_id = $news->get_one("`catid`= '$catid' AND `status`=99",'id,title,catid','id ASC');//下一篇id
	 		$next_data = $news_data->get_one("`id`= '".$next_id['id']."' ",'content,id','id ASC');
	 		$next_page = $news->get_one("`catid`= '$catid' AND `id`>'".$next_id['id']."' AND `status`=99",'id','id ASC');
	 	}else{
	 		$next_id = $news->get_one("`catid`= '$catid' and `id` = '$id' AND `status`=99",'id,title,catid','id ASC');//下一篇id
	 		$next_data = $news_data->get_one("`id`= '".$next_id['id']."' ",'content,id','id ASC');
	 		$next_page = $news->get_one("`catid`= '$catid' AND `id`>'$id' AND `status`=99",'id','id ASC');
	 	}
	 	if($next_data){
	 		$catdata=$category->get_one("`catid` = '$catid'", 'catname,author,image,catid','catid desc');
	 	}else{
	 		echo '{"Msg":"没有数据"}';return;
	 	}
		$previous_page = $news->get_one("`catid` = '$catid' AND `id`<'$id' AND `status`=99",'id','id DESC');
	 	$next_data['title']=$next_id['title'];
	 	$next_data['catname']=$catdata['catname'];
	 	$next_data['author']=$catdata['author'];
	 	$next_data['image']=$catdata['image'];
	 	$next_data['catid']=$catdata['catid'];
	 	$next_data['previous']=$previous_page['id'];
	 	$next_data['next']=$next_page['id'];
	 	$data= json_encode($next_data);
	 	echo $data;return;
	}

	/**
	**加载下一章数据
	**
	*/
	public function getnextchapter(){
	 	$news=pc_base::load_model('news_model');
	 	$news_data=pc_base::load_model('news_data_model');
	 	$catid = intval($_GET['catid']);
	 	$id = intval($_GET['novelid']);
	 	if(empty($catid) || empty($id)){
	 		echo '{"Msg":"id空"}';return;
	 	}
	 	$next_id = $news->get_one("`catid`= '$catid' AND `id`>'$id' AND `status`=99",'id,title','id ASC');//下一篇id
	 	$next_data = $news_data->get_one("`id`= '".$next_id['id']."' ",'content,id','id ASC');
	 	$next = $news->get_one("`catid`= '$catid' AND `id`>'".$next_data['id']."' AND `status`=99",'id','id ASC');
	 	if(empty($next_data)){
	 		$previous = $news->get_one("`catid` = '$catid' AND `id`<'$id' AND `status`=99",'id','id DESC');
	 		$data= '{"content":"no","id":'.$previous['id'].'}';
	 	}else{
	 		//$previous_page = $news->get_one("`catid` = '$catid' AND `id`<'$id' AND `status`=99",'id','id DESC');
			//下一页
			$next_page = $news->get_one("`catid`= '$catid' AND `id`>'$id' AND `status`=99",'id','id ASC');
	 		if(empty($next)){
	 			$next_data['next_id']='no';
	 		}else{
	 			$next_data['next_id']=$next['id'];//有值代表还有下一篇
	 		} 
	 		$next_data['previous']=$id;
	 		$next_data['next']=$next_page['id'];
	 		$next_data['title']=$next_id['title'];
	 		$data= json_encode($next_data);
	 	}
	 	echo $data;return;
	}

	/**
	**搜索
	**
	*/
	public function search(){
		$this->db = pc_base::load_model('category_model');
		$page = isset($_GET['page']) && intval($_GET['page']) ? intval($_GET['page']) : 1;
		$keyword=$_GET['q'];
		$flag=$_GET['flag'];
		if(empty($keyword)){
	 		echo '{"Msg":"关键词空"}';return;
	 	}
	 	if(empty($flag)){
	 		$flag = 1;
	 	}
		$pagesize =20 ;
		$offset = ($page - 1) * $pagesize;
		if(isset($keyword) && $keyword != ''){
			if($flag == 1){
				$where = "a.catname like '%".$keyword."%'";
			}else{
				$where = "a.author = '".$keyword."'";
			}
			
			$pagesize = 100;
		}

		$data = $this->db->query("select a.catname, a.description,a.author,a.image,a.catid,a.url,a.novel_type,b.id FROM v9_category a left JOIN v9_news b ON a.catid = b.catid WHERE ".$where." GROUP BY b.catid having b.id is NOT null ORDER BY a.catid desc LIMIT ".$offset.",".$pagesize);
		$data = $this->db->fetch_array($data);
		$total = $this->db->query("select a.catname, a.description,a.author,a.image,a.catid,a.novel_type,b.id FROM v9_category a left JOIN v9_news b ON a.catid = b.catid WHERE ".$where." GROUP BY b.catid having b.id is NOT null ");
		$total = count($this->db->fetch_array($total));
		if(isset($keyword) && $keyword != ''){
			if(empty($data)){
				echo '{"msg":"null"}';return;
			}else{
				$pagex=ceil($total/$pagesize);
				if($page<=$pagex){
					$data[0]['next_page']=$page+1;
				}
				if($pagex>0){
					$data[0]['sum_page']=$pagex;
				}else if($pagex==0){
					$data[0]['sum_page']=$pagex;
				}
				$data= json_encode($data);
				echo  $data;return;
			}
			
		}
	}
	/**
	**搜索页面--热词
	**
	*/
	public function HotWords(){
		$hot = pc_base::load_model('wx_hotsearch_model');
		$flag = $_GET['flag'];
		if(empty($flag)){
	 		$flag = 1;
	 	}
		$data = $hot->select("flag = $flag","keyword,flag", '','listorder desc');
		if(empty($data)){
			echo '{"Msg":"查无数据"}';return;
		}
		$data= json_encode($data);
		echo  $data;return;
	}

	/**
	**历史记录列表
	**
	*/
	public function Historical(){
		$userid=$_GET['userid'];
		if(empty($userid)){
			echo '{"Msg":"用户id空"}';return;
		}else{
			$where = "`userid` = '$userid'";
		}
		$page = isset($_GET['page']) && intval($_GET['page']) ? intval($_GET['page']) : 1;
        $pagesize = 20;
        $offset = $pagesize*($page-1);

		$history = pc_base::load_model('history_model');
		$data=$history->select($where, 'id,novelid,catid,catname,image,author,title,create_time',$offset.','.$pagesize,'id desc');
        $totalnums=$history->count($where);
        $totalnums = isset($totalnums) ? $totalnums : 0;
        $pages = pages($totalnums, $page, $pagesize);
        $pagex=ceil($totalnums/$pagesize);
		if($page<=$pagex){
			$data[0]['next_page']=$page+1;
		}
		if($pagex>0){
			$data[0]['sum_page']=$pagex;
		}else if($pagex==0){
			$data[0]['sum_page']=$pagex;
		}
		for($i=0;$i<count($data);$i++){
			$data[$i]['time']=$this->time_tran($data[$i]['create_time']);;
		}
		if(empty($data)){
			echo '{"Msg":"查无数据"}';return;
		}	     
		$data= json_encode($data);
		echo  $data;return;
	}

	/**
	**保存历史记录
	**
	*/
	public function HistoricalAdd(){
		$catname=$_GET['catname'];
		$image=$_GET['image'];
		$author=$_GET['author'];
		$title=$_GET['title'];
		$novelid=$_GET['id'];
		$catid=$_GET['catid'];
		$userid=$_GET['userid'];
		$time = date ( 'Y-m-d H:i:s', time () );
		$history = pc_base::load_model('history_model');

		$his = $history ->get_one("`catid`= '$catid' and userid = $userid",'id','id ASC');
		$info=array("userid"=>$userid,"catname"=>$catname,"image"=>$image,"author"=>$author,"title"=>$title,"novelid"=>$novelid,"catid"=>$catid,"create_time"=>$time); 
		if(empty($his)){	
			$result = $history->insert($info);
			if($result){
				echo '{"Msg":"ok"}';return;
			}else{
				echo '{"Msg":"no"}';return;
			}
		}else{
			$result = $history->update($info,array('catid'=>$catid,"userid"=>$userid));
			if($result){
				echo '{"Msg":"ok"}';return;
			}else{
				echo '{"Msg":"no"}';return;
			}
		}
	}
	/**
	**删除历史记录
	*/
	public function delHistory(){
		$userid=$_GET['userid'];
		$history = pc_base::load_model('history_model');
		$del=$history->delete(array('userid'=>$userid));
		if($del){
			echo '{"Msg":"ok"}';return;
		}else{
			echo '{"Msg":"no"}';return;
		}
	}

	/**
	**计算时间差
	**
	*/
	public function time_tran($the_time){
	    $now_time = date("Y-m-d H:i:s",time());
	    $now_time = strtotime($now_time);
	    $show_time = strtotime($the_time);
	    $dur = $now_time - $show_time;
	    if($dur < 0){
	   		return $the_time;
	    }else{
	    	if($dur < 60){
	     		return $dur.'秒前';
	    	}else{
	     		if($dur < 3600){
	      			return floor($dur/60).'分钟前';
	     		}else{
	      			if($dur < 86400){
	       				return floor($dur/3600).'小时前';
	      			}else{
		      			if($dur < 259200){//3天内
		        			return floor($dur/86400).'天前';
		       			}else{
		        			return floor ( $dur / 86400 ) . '天前';
		       			}
		       		}
		       	}
		    }   		
    	}
 	}
 	/**
 	**收藏列表
 	**
 	*/
 	public function collectList(){
 		$userid=$_GET['userid'];
 		if(empty($userid)){
			echo '{"Msg":"用户id空"}';return;
		}
		
		$page = isset($_GET['page']) && intval($_GET['page']) ? intval($_GET['page']) : 1;
        $pagesize = 20;
        $offset = $pagesize*($page-1);

		$collect = pc_base::load_model('collect_model');
		$where = "`userid` = '$userid'";
		$data=$collect->query("select b.catname,b.description,b.author,b.image,a.catid from v9_collect a LEFT JOIN v9_category b on a.catid=b.catid WHERE ".$where." ORDER BY a.id desc LIMIT ".$offset.",".$pagesize);
        $data = $collect->fetch_array($data);

        if(empty($data)){
            echo '{"Msg":"查无数据"}';return;
        }
        $totalnums=$collect->query("select b.catname,b.description,b.author,b.image,a.catid from v9_collect a LEFT JOIN v9_category b on a.catid=b.catid WHERE ".$where);
        $totalnums = count($collect->fetch_array($totalnums));
        $totalnums = isset($totalnums) ? $totalnums : 0;
        $pages = pages($totalnums, $page, $pagesize);
        $pagex=ceil($totalnums/$pagesize);
		if($page<=$pagex){
			$data[0]['next_page']=$page+1;
		}
		if($pagex>0){
			$data[0]['sum_page']=$pagex;
		}else if($pagex==0){
			$data[0]['sum_page']=$pagex;
		}
		
		$data= json_encode($data);
		echo  $data;return;
 	}

 	/**
 	**判断是否收藏
 	**
 	*/
 	public function checkcoll(){
 		$userid=$_GET['userid'];
 		$catid=$_GET['catid'];

 		if(empty($userid)){
			echo '{"Msg":"用户id空"}';return;
		}
		if(empty($catid)){
			echo '{"Msg":"小说id空"}';return;
		}
		$collect = pc_base::load_model('collect_model');
		$coll = $collect ->get_one("`catid`= '$catid' and userid = $userid",'id','id ASC');
		if(empty($coll)){
			echo '{"Msg":"2"}';return;
		}else{
			echo '{"Msg":"1"}';return;
		}
 	}

 	/**
 	**小说收藏功能
 	**
 	*/
 	public function collect(){
 		$userid=$_GET['userid'];
 		$catid=$_GET['catid'];

 		if(empty($userid)){
			echo '{"Msg":"用户id空"}';return;
		}
		if(empty($catid)){
			echo '{"Msg":"小说id空"}';return;
		}

		$collect = pc_base::load_model('collect_model');
		$coll = $collect ->get_one("`catid`= '$catid' and userid = $userid",'id','id ASC');
		if(empty($coll)){
			$time = date ( 'Y-m-d H:i:s', time () );
	 		$info=array("userid"=>$userid,"catid"=>$catid,"create_time"=>$time); 
			$result = $collect->insert($info);
			if($result){
				echo '{"Msg":"ok"}';return;
			}else{
				echo '{"Msg":"no"}';return;
			}
		}else{
			echo '{"Msg":"已收藏过"}';return;
		}
		
 	}

 	/**
 	**取消收藏
 	*/
 	public function  cancelcollect(){

 		$userid=$_POST['userid'];
 		$catid=$_POST['catid'];

 		if(empty($userid)){
			echo '{"Msg":"用户id空"}';return;
		}
		if(empty($catid)){
			echo '{"Msg":"小说id空"}';return;
		}
		$collect = pc_base::load_model('collect_model');
		if(strpos($catid,',') !== false){
			$catid = explode(",", $catid); 
			foreach($catid as $id) {
				$del=$collect->delete(array('userid'=>$userid,'catid'=>$id));
			}
		}else{
			$del=$collect->delete(array('userid'=>$userid,'catid'=>$catid));
		}

		if($del){
			echo '{"Msg":"ok"}';return;
		}else{
			echo '{"Msg":"no"}';return;
		}
 	}



}
?>