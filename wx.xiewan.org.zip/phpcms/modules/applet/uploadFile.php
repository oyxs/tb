<?php
define('PHPCMS_PATH', dirname(__FILE__).DIRECTORY_SEPARATOR);
pc_base::load_app_class('foreground');
pc_base::load_sys_class('format', '', 0);
pc_base::load_sys_class('form', '', 0);
pc_base::load_app_func('util','content');
require_once PHPCMS_PATH.'/phpcms/modules/applet/speech.php';
/**
* 文件上传类
*/
class uploadFile {
/**
* 上传文件
* @param $files 等待上传的文件(表单传来的$_FILES[])
* @return 
*/
public function upload_file() {
	// 获取文件基本信息
	$media		= $_FILES['file'];
	$tmp_name 	= $media['tmp_name'];
	$error 		= $media['error'];

	$openid = $_POST['openid'];//用户唯一标识
	$redpackid = $_POST['redpackid'];//红包id

	if(empty($openid)){
		$data = [
                'data' => '用户id空',
            ];
		echo json_encode([
            'msg' => 'fail',
            'data' => $data,
        ]);
		return;
	}
	if(empty($redpackid)){
		$data = [
                'data' => '红包id空',
            ];
		echo json_encode([
            'msg' => 'fail',
            'data' => $data,
        ]);
		return;
	}

	if($error == 0 && is_uploaded_file($tmp_name)) {
		$time = time ();
		$md5 = md5(file_get_contents($media["tmp_name"]));
		$uploaded = PHPCMS_PATH."uploadfile/silk/". $md5.'.silk';//上传后的文件名
		$src = "https://wx.xiewan.org/uploadfile/silk/". $md5.'.silk';
		//移动文件
		$speech=pc_base::load_model('wx_speech_model');
		$info=array("openid"=>$openid,"rid"=>$redpackid,"voice"=>$src,"create_time"=>$time); 
		if($speech->insert($info) && move_uploaded_file($tmp_name,$uploaded)){//上传成功
			//echo '{"msg":"上传成功！"}';return;
			$silk = new speech();
			$id = $speech->insert_id();
			$result = $silk->silkdecoder($uploaded,$id);
			if($result == "fail"){
				$data = [
	                'data' => '识别失败',
	            ];
				echo json_encode([
		            'msg' => 'fail',
		            'data' => $data,
		        ]);
				return;
			}else{
				$data = [
	                'rpid' => $id,
	                'result' => $result,
	            ];
				echo json_encode([
		            'msg' => 'success',
		            'data' => $data,
		        ]);
				return;
			}
		}else{
			$data = [
	            'data' => '上传失败！',
	        ];
			echo json_encode([
		            'msg' => 'fail',
		            'data' => $data,
		        ]);
			return;
		}
	}else{
		$data = [
	            'data' => '录音文件错误',
	        ];
		echo json_encode([
		    'msg' => 'fail',
		    'data' => $data,
		]);
		return;
	}
}

}
?>