<?php 
require_once PHPCMS_PATH.'/phpcms/modules/applet/AipSpeech.php';
pc_base::load_app_class('foreground');
pc_base::load_sys_class('format', '', 0);
pc_base::load_sys_class('form', '', 0);
pc_base::load_app_func('util','content');
class speech {

	public function silkdecoder($real_file,$yid){
		$cmd = "sh /usr/local/silk-v3-decoder/converter.sh ".$real_file." wav";
		exec($cmd,$out);
		$real_file = str_replace(".silk",".wav",$real_file);
		$yytime = $this->getWavLength($real_file);
		$speech=pc_base::load_model('wx_speech_model');
		$updatearr = array('length'=>$yytime);
		$speech->update($updatearr, array('id'=>$yid));
		//if(strpos($out['0'],'[ok]') !== false ){
			$APP_ID = pc_base::load_config('system','BaiSpeech_ID');
			$API_KEY = pc_base::load_config('system','BaiSpeech_KEY');
			$SECRET_KEY = pc_base::load_config('system','BaiSpeech_appsecret');
			$client = new AipSpeech($APP_ID, $API_KEY, $SECRET_KEY);
			
			// 识别本地文件
			$vstr=$client->asr(file_get_contents($real_file), 'wav', 16000, array(
			    'lan' => 'zh',
			));
			@unlink($real_file);
			if($vstr['err_msg'] == 'success.' && $vstr['err_no'] == '0'){
				$result = str_replace("，","",$vstr['result']['0']);
				return  $result;
			}else{
				return 'fail';
			}
		// }else{
		// 	echo '转码失败';
		// }
	}

	function getWavLength($file, $base=10) {
	    $fp = fopen($file, 'r');
	    if (fread($fp,4) != 'RIFF') {
	        return '';
	    }
	    fseek($fp, 20);
	    $rawheader = fread($fp, 16);
	    $header = unpack('vtype/vchannels/Vsamplerate/Vbytespersec/valignment/vbits',$rawheader);
	    $pos = ftell($fp);
	    while (fread($fp, 4) != 'data' && !feof($fp)) {
	        $pos++;
	        fseek($fp,$pos);
	    }
	    $rawheader = fread($fp, 4);
	    $data = unpack('Vdatasize',$rawheader);
	    $sec = $data[datasize] / $header[bytespersec];
	    if($base==60) {
	        $seconds = intval($sec % 60);
	        $minutes = intval(($sec - $sec * 60) / 60);
	        return $minutes.':'.$seconds;
	    } else {
	        return $sec;
	    }
	}

}
?>