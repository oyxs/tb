<?php

include_once 'task/DB.php';

class RedPacket extends DB
{
    const RandomTitle = [
        '新年快乐！你们的礼物都在这里~',
        '新年快乐！快来说口令拿福利~',
        '别犹豫，说出口令就能获得福利',
        '快来试试这种口令拿福利',
    ];

    const RandomCommand = [
        '恭喜发财',
        '新年快乐',
        '新春快乐',
        '红包拿来',
    ];

    //获取用户
    public function getUser($openid)
    {
        return $this->find("select * from v9_wx_userinfo where openid = '$openid'");
    }

    //获取余额
    public function getMoney()
    {
        $openid = $_GET['openid'];
        $res = 0;
        $data = [];
        $user = $this->getUser($openid);

        if (!empty($user) && $user != null){
            $res = 1;
            $data = ['money' => $user['money']];
        }

        echo json_encode([
            'res' => $res,
            'data' => $data,
            'title' => self::RandomCommand[rand(0,count(self::RandomCommand)-1)],//默认口令提示
        ]);
    }

    //更新红包余额
    public function updateMoney($openid, $money)
    {
        $res = 0;
        $user = $this->getUser($openid);
        if (!empty($user) && $user != null){
            $update = $this->update("UPDATE v9_wx_userinfo SET money = $money WHERE openid = '$openid'");
            if ($update > 0){
                $res = 1;
            }
        }
        return $res;
    }

    //生成红包
    public function createRp()
    {
        $openid = $_GET['openid'];//用户唯一标识
        $command = $_GET['command'];//口令
        $reward = $_GET['reward'];//赏金
        $money = $_GET['money'];//最终支付金额
        $number = $_GET['number'];//数量
        $out_trade_no = $_GET['out_trade_no'] ? $_GET['out_trade_no'] : '0';//支付的订单号
        $res = 0;
        $data = [];
        $nowtime = date('Y-m-d H:i:s');
        $user = $this->getUser($openid);// where openid = {$openid}
        if (!empty($user) && $user != null && $money <= $user['money']){

            $createRedPackage = $this->create("
                INSERT INTO red_package (
                    openid,
                    command,
                    money,
                    reward,
                    syje,
                    number,
                    surplus,
                    out_trade_no,
                    is_handle,
                    create_time,
                    update_time
                )
                VALUES
                (
                    '$openid',
                    '$command',
                    '$money',
                    '$reward',
                    '$reward',
                    '$number',
                    '0',
                    '$out_trade_no',
                    '0',
                    '$nowtime',
                    '$nowtime'
                )
            ");
            if ($createRedPackage > 0){
                $rp = $this->find("select * from red_package where openid = '{$openid}' AND command = '{$command}' AND create_time = '{$nowtime}'");
                $res = 1;

                //如果优先使用了余额支付 则扣除用户红包余额中用来支付的相应金额
//                $realPay = $reward + ($reward * 0.02);
                if ($money != $reward){
//                    $newMoney = $user['money'] - ($realPay - $money);
                    $newMoney = $user['money'] - ($reward - $money);
                    $updateMoney = $this->updateMoney($openid, $newMoney);
                    if ($updateMoney <= 0){
                        $res = 0;
                    }
                }

                $data = [
                    'command' => $command,
                    'rp_id' => $rp['id'],
                ];
            }
        }

        echo json_encode([
            'res' => $res,
            'data' => $data,
        ]);
    }

    //分享红包
    public function shareRp()
    {
        $rp_id = $_GET['rp_id'];//红包ID
        $res = 0;
        $data = [];

        $rp = $this->find("select * from red_package where id = $rp_id");
        if (!empty($rp) && $rp != null){
            $user = $this->getUser($rp['openid']);
            if (!empty($user) && $user != null){
                $res = 1;
                $data = [
                    'photo' => $user['headimgurl'],
                    'command' => $rp['command'],
                    'rp_id' => $rp['id'],
                    'openid' => $rp['openid'],
                    'title' => self::RandomTitle[rand(0,count(self::RandomTitle)-1)],
                ];
            }
        }

        echo json_encode([
            'res' => $res,
            'data' => $data,
        ]);
    }

    //抢红包页面
    public function rpPage()
    {
        $rp_id = $_GET['rp_id'];//红包ID
        $openid = $_GET['openid'];//用户唯一标识
        $res = 0;
        $data = [];

        $rp = $this->find("select * from red_package where id = $rp_id");
        if (!empty($rp) && $rp != null){
            $rpUser = $this->getUser($rp['openid']);
//            $user = $this->getUser($openid);
            //如果红包剩余金额超过24小时没有被领取 则 把剩余金额返回到账户余额 并且只执行一次金额退回！
            $is_expire = "0";
            $howLongTime = strtotime(date('Y-m-d H:i:s')) - strtotime($rp['create_time']);
            if ($howLongTime >= 86400){
                $is_expire = "1";
            }

            $rprc = $this->findAll("
                SELECT
                    v9_wx_speech.openid,
                    v9_wx_speech.voice,
                    v9_wx_speech.length,
                    FROM_UNIXTIME(v9_wx_speech.create_time,'%Y-%m-%d %H:%i:%s') as create_time,
                    v9_wx_userinfo.headimgurl AS photo,
                    v9_wx_userinfo.nickname AS nickname,
                    red_package_record.money AS rp_money,
                    USER .sex
                FROM
                    v9_wx_speech
                INNER JOIN v9_wx_userinfo
                INNER JOIN red_package_record
                INNER JOIN v9_wx_userinfo AS USER ON v9_wx_speech.openid = v9_wx_userinfo.openid
                AND red_package_record.rp_id = v9_wx_speech.rid
                AND red_package_record.openid = v9_wx_speech.openid
                AND USER .openid = v9_wx_speech.openid
                WHERE
                    v9_wx_speech.rid = ".$rp_id." 
                AND red_package_record.rp_id = ".$rp_id." 
                AND v9_wx_speech.status = 1 
                GROUP BY
                    v9_wx_speech.openid
                ORDER BY
                    v9_wx_speech.create_time DESC
            ");

            $is_taker = "0";
            $take_money = "0";
            foreach ($rprc as $item){
                if ($item['openid'] == $openid){
                    $is_taker = "1";
                    $take_money = $item['rp_money'];
                }
            }

            $res = 1;
            $data = [
                'photo' => $rpUser['headimgurl'],
                'nickname' => $rpUser['nickname'],
                'openid' => $rpUser['openid'],
                'command' => $rp['command'],
                'is_taker' => $is_taker,
                'take_money' => $take_money,
                'is_expire' => $is_expire,//是否过期
                'sum' => $rp['reward'],
                'count' => $rp['number'],
                'surplus' => $rp['surplus'],
                'list' => $rprc,
            ];
        }

        echo json_encode([
            'res' => $res,
            'data' => $data,
        ]);
    }

    //抢红包
    public function takeRp()
    {
        $openid = $_GET['openid'];
        $rp_id = $_GET['rp_id'];//红包ID
        $s_id = $_GET['s_id'];//红包ID
        $res = 0;
        $user = $this->getUser($openid);
        if (!empty($user) && $user != null){
            $rp = $this->find("select * from red_package where id = $rp_id");
            if (!empty($rp) && $rp != null){
                if ($rp['surplus'] < $rp['number']){
                    //标记有效语音
                    $speech = $this->find("SELECT * FROM v9_wx_speech WHERE id = $s_id AND status = 0");
                    if (!empty($speech) && $speech != null){
                        $updateSpeech = $this->update("UPDATE v9_wx_speech SET status = 1 WHERE id = $s_id");
                        if ($updateSpeech > 0){//$updateSpeech > 0

                            $syje = $this->getSyMoney($rp);//红包当前剩余总金额
                            $syhbsl = $rp['number'] - $rp['surplus'];//红包当前剩余数量

                            //计算最终抢到的红包金额 随机红包金额计算

                            if ($rp['surplus'] < ($rp['number'] - 1)){//剩余至少两个红包 就给 随机金额
                                $money = $this->getRandomMoney($syje, $syhbsl);
                            }else if ($rp['surplus'] == ($rp['number'] - 1)){//剩余一个红包 直接给 红包剩余金额
                                $money = $syje;
                            }else{
                                $money = 0;
                            }

                            //更新红包 已抢数量、已抢总金额
                            $surplus = $rp['surplus'] + 1;
                            $syje2 = $syje - $money; // 已抢总金额 = 当前剩余总金额 - 此次被抢金额
                            $updateRp = $this->update("
                              UPDATE 
                                  red_package 
                              SET 
                                  surplus = $surplus,
                                  syje = $syje2 
                              WHERE id = $rp_id
                            ");

                            //记录被抢红包
                            $createRecord = $this->create("
                                INSERT INTO red_package_record (
                                    rp_id,
                                    rp_openid,
                                    openid,
                                    money,
                                    type,
                                    create_time,
                                    update_time
                                )
                                VALUES
                                (
                                    '$rp_id',
                                    '{$rp['openid']}',
                                    '$openid',
                                    '$money',
                                    '0',
                                    '".date('Y-m-d H:i:s')."',
                                    '".date('Y-m-d H:i:s')."'
                                )
                            ");

                            //被抢金额写入用户红包余额
                            $newMoney = $user['money']+$money;
                            $updateMoney = $this->updateMoney($openid, $newMoney);

                            if ($updateRp > 0 && $createRecord > 0 && $updateMoney > 0){
                                $res = 1;
                            }
                        }
                    }
                }
            }
        }

        echo json_encode([
            'res' => $res,
        ]);
    }

    //获取红包剩余金额
    public function getSyMoney($rp){
        //已经被抢的总金额
        $sum = $this->find("SELECT sum(money) AS sum FROM red_package_record WHERE rp_id = {$rp['id']}");
        if (!empty($sum) && $sum != null){
            $sums = $sum['sum'];
        }else{
            $sums = 0;
        }
        $syje = $rp['reward'] - $sums;//红包剩余金额 = 红包设定总金额 - 已经被抢的总金额
        return $syje;
    }

    //获取随机金额
    public function getRandomMoney($bonus_total, $bonus_count, $bonus_type=1){
        $bonus_items  = array(); // 将要瓜分的结果
        $bonus_balance = $bonus_total; // 每次分完之后的余额
        $bonus_avg = number_format($bonus_total/$bonus_count, 2); // 平均每个红包多少钱
        $i = 0;
        $mmin = 0.01;
        $bdje = [ //保底随机金额
            0.01,
            0.02,
            0.03,
            0.04,
            0.05,
        ];
        while($i<$bonus_count){
            if($i<$bonus_count-1){
                // $rand = $bonus_type?(rand(1, $bonus_balance*100-1)/100):$bonus_avg; // 根据红包类型计算当前红包的金额
                $rand = number_format(abs(rand(1, $bonus_balance*100-1) / 100), 2); // 根据红包类型计算当前红包的金额
                if ($rand < $mmin) {
                    $rand = number_format(abs($bdje[rand(0,4)]), 2);
                }
                $bonus_items[] = $rand;
                $bonus_balance -= $rand;
            }else{
                $bonus_items[] = number_format(abs($bonus_balance), 2); // 最后一个红包直接承包最后所有的金额，保证发出的总金额正确
            }
            $i++;
        }
        // return $bonus_items;
        // return number_format(abs((rand(1, (($bonus_total*100) - 1))) / 100), 2);
        return $bonus_items[rand(0, count($bonus_items)-1)];
    }

    //我发出的
    public function mySend()
    {
        $openid = $_GET['openid'];
        $page = $_GET['page'] ? $_GET['page'] : 1;
        $pageNum = $_GET['pageNum'] ? $_GET['pageNum'] : 1000;
        $f = ($page - 1) * $pageNum;
        $t = $pageNum;
        $res = 0;
        $data = [];
        $user = $this->getUser($openid);

        if (!empty($user) && $user != null){
            $rp = $this->findAll("SELECT * FROM red_package WHERE openid = '$openid' ORDER BY create_time DESC LIMIT {$f},{$t}");
            $sum = $this->find("SELECT sum(reward) AS sum FROM red_package WHERE openid = '$openid'");
            if (!empty($sum) && $sum != null){
                $sums = $sum['sum'];
            }else{
                $sums = "0";
            }
            $count = $this->find("SELECT count(*) AS count FROM red_package WHERE openid = '$openid'");
            $res = 1;
            $data = [
                'photo' => $user['headimgurl'],
                'nickname' => $user['nickname'],
                'sum' => $sums,
                'count' => $count['count'],
                'list' => $rp,
            ];
        }

        echo json_encode([
            'res' => $res,
            'data' => $data,
        ]);
    }

    //我收到的
    public function myReceive()
    {
        $openid = $_GET['openid'];
        $page = $_GET['page'] ? $_GET['page'] : 1;
        $pageNum = $_GET['pageNum'] ? $_GET['pageNum'] : 1000;
        $f = ($page - 1) * $pageNum;
        $t = $pageNum;
        $res = 0;
        $data = [];
        $user = $this->getUser($openid);

        if (!empty($user) && $user != null){
            $rprc = $this->findAll("
                SELECT
                    red_package_record.*, 
                    v9_wx_userinfo.headimgurl AS photo,
                    v9_wx_userinfo.nickname AS nickname
                FROM
                    red_package_record
                LEFT JOIN v9_wx_userinfo ON red_package_record.rp_openid = v9_wx_userinfo.openid
                WHERE
                    red_package_record.openid = '".$openid."'
                ORDER BY
                    red_package_record.create_time DESC
                LIMIT {$f},{$t}
            ");

            $sum = $this->find("SELECT sum(money) AS sum FROM red_package_record WHERE openid = '$openid'");
            if (!empty($sum) && $sum != null){
                $sums = $sum['sum'];
            }else{
                $sums = "0";
            }
            $count = $this->find("SELECT count(*) AS count FROM red_package_record WHERE openid = '$openid'");
            $res = 1;
            $data = [
                'photo' => $user['headimgurl'],
                'nickname' => $user['nickname'],
                'sum' => $sums,
                'count' => $count['count'],
                'list' => $rprc,
            ];
        }

        echo json_encode([
            'res' => $res,
            'data' => $data,
        ]);
    }

    //提现
    public function withdraw()
    {
        $openid = $_POST['openid'];
        $money = $_POST['money'];
        $res = 0;
        $data = [];
        $user = $this->getUser($openid);
        if (!empty($user) && $user != null){
            if ($money <= $user['money'] && $money >= 1){
                //微信提现接口
                $wxWithdraw = $this->wxWithdraw($user, $money);
                if ($wxWithdraw['state'] == 1){
                    //写入用户红包余额
                    $newMoney = $user['money'] - $money;
                    $updateMoney = $this->updateMoney($openid, $newMoney);
                    if ($updateMoney > 0){
                        $res = 1;
                        $data = [
                            'money' => $newMoney,
                        ];
                    }
                }
            }
        }

        echo json_encode([
            'res' => $res,
            'data' => $data,
        ]);
    }

    //微信提现 模块
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
    private function wxWithdraw($user, $money)
    {
        $res['state'] = 0;
        $wx = pc_base::load_model('wxPay_model');
        $data['openid'] = $user['openid'];
        $data_total = $money * 100;//订单总金额，单位分
        $data['amount'] = $data_total;
        $data['crsNo'] = 'W'.date('YmdHis',time()).$this->randomkeys(2);
        $data['order_status'] = '-1';//未支付
        $insertId = $wx->insert($data);

        if($insertId){
            $res = $this->wxApi($data_total, $data['openid'], $data['crsNo']);
        }

        return $res;
    }

    //【企业付款到零钱】(需要注意的地方：1.所有参数不能包含空白字符串，2.xml参数顺序要根据生成签名的参数拼接顺序(字典序)，3.ssl证书)
    private function wxApi($total_fee, $openid, $order_id)
    {
        if(empty($total_fee)){
            echo json_encode(array('state'=>0,'Msg'=>'金额有误'));exit;
        }
        if(empty($openid)){
            echo json_encode(array('state'=>0,'Msg'=>'登录失效，请重新登录(openid参数有误)'));exit;
        }
        if(empty($order_id)){
            echo json_encode(array('state'=>0,'Msg'=>'自定义订单有误'));exit;
        }
        $appid = pc_base::load_config('system','applet_id');//如果是公众号 就是公众号的appid;小程序就是小程序的appid
        $mch_id = '1490333942';
        $KEY = '1o9Vf140164aqC51f6f0U26e79da144D';
        $nonce_str =    $this->randomkeys(32);//随机字符串
        $out_trade_no = $order_id;//商户订单号
        $spbill_create_ip = $_SERVER['SERVER_ADDR'];
        $amount = $total_fee;//总金额 最低为一分钱 必须是整数

        //这里是按照顺序的 因为下面的签名是按照(字典序)顺序 排序错误 肯定出错
        $post['mch_appid'] = $appid;
        $post['mchid'] = $mch_id;
        $post['nonce_str'] = $nonce_str;//随机字符串
        $post['partner_trade_no'] = $out_trade_no;
        $post['openid'] = $openid;
        $post['check_name'] = 'NO_CHECK';
        $post['amount'] = $amount;
        $post['desc'] = '红包提现';
        $post['spbill_create_ip'] = $spbill_create_ip;//服务器终端的ip
        $sign = $this->MakeSign($post,$KEY);              //签名

        $post_xml = '<xml>
                <amount>'.$amount.'</amount>
                <check_name>NO_CHECK</check_name>
                <desc>红包提现</desc>
                <mch_appid>'.$appid.'</mch_appid>
                <mchid>'.$mch_id.'</mchid>
                <nonce_str>'.$nonce_str.'</nonce_str>
                <openid>'.$openid.'</openid>
                <partner_trade_no>'.$out_trade_no.'</partner_trade_no>
                <spbill_create_ip>'.$spbill_create_ip.'</spbill_create_ip>
                <sign>'.$sign.'</sign>
            </xml> ';

        //【企业付款到零钱】接口
        $url = 'https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers';
        $xml = $this->http_request($url,$post_xml);     //POST方式请求http
        $array = $this->xml2array($xml);               //将【企业付款到零钱】api返回xml数据转换成数组，全要大写

        if($array['RETURN_CODE'] == 'SUCCESS' && $array['RESULT_CODE'] == 'SUCCESS'){
            $time = time();
            $tmp['appId'] = $appid;
            $tmp['nonceStr'] = $nonce_str;
            $tmp['package'] = 'prepay_id='.$array['PREPAY_ID'];
            $tmp['signType'] = 'MD5';
            $tmp['timeStamp'] = "$time";

            $data['state'] = 1;
            $data['timeStamp'] = "$time";           //时间戳
            $data['nonceStr'] = $nonce_str;         //随机字符串
            $data['signType'] = 'MD5';              //签名算法，暂支持 MD5
            $data['package'] = 'prepay_id='.$array['PREPAY_ID'];   //统一下单接口返回的 prepay_id 参数值，提交格式如：prepay_id=*
            $data['paySign'] = $this->MakeSign($tmp,$KEY);       //签名,具体签名方案参见微信公众号支付帮助文档;
            $data['out_trade_no'] = $out_trade_no;

        }else{
            $data['state'] = 0;
            $data['text'] = "错误";
            $data['RETURN_CODE'] = $array['RETURN_CODE'];
            $data['RETURN_MSG'] = $array['RETURN_MSG'];
        }

        return $data;
    }

    //生成签名, $KEY就是支付key
    private function MakeSign($params, $KEY)
    {
        //签名步骤一：按字典序排序数组参数
        ksort($params);
        $string = $this->ToUrlParams($params);  //参数进行拼接key=value&k=v
        //签名步骤二：在string后加入KEY
        $string = $string . "&key=".$KEY;
        //签名步骤三：MD5加密
        $string = md5($string);
        //签名步骤四：所有字符转为大写
        $result = strtoupper($string);
        return $result;
    }

    //将参数拼接为url: key1=value1&key2=value2
    public function ToUrlParams($params)
    {
        $string = '';
        if( !empty($params) ){
            $array = array();
            foreach( $params as $key => $value ){
                $array[] = $key.'='.$value;
            }
            $string = implode("&",$array);
        }
        return $string;
    }

    //curl请求
    private function http_request($url, $data, $aHeader=array())
    {
        $curl = curl_init();
        if( count($aHeader) >= 1 ){
            curl_setopt($curl, CURLOPT_HTTPHEADER, $aHeader);
        }
        curl_setopt($curl, CURLOPT_URL, $url);

        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);

        curl_setopt($curl,CURLOPT_SSLCERTTYPE,'PEM');
        curl_setopt($curl,CURLOPT_SSLCERT, getcwd().'/phpcms/modules/applet/pems/apiclient_cert.pem');

        curl_setopt($curl,CURLOPT_SSLKEYTYPE,'PEM');
        curl_setopt($curl,CURLOPT_SSLKEY, getcwd().'/phpcms/modules/applet/pems/apiclient_key.pem');

        curl_setopt($curl,CURLOPT_CAINFO,'/phpcms/modules/applet/pems/rootca.pem');

        if (!empty($data)){
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($curl);
        curl_close($curl);
        return $output;
    }

    //获取xml里面数据，转换成array
    private function xml2array($xml)
    {
        $p = xml_parser_create();
        xml_parse_into_struct($p, $xml, $vals, $index);
        xml_parser_free($p);
        $data = "";
        foreach ($index as $key=>$value) {
            if($key == 'xml' || $key == 'XML') continue;
            $tag = $vals[$value[0]]['tag'];
            $value = $vals[$value[0]]['value'];
            $data[$tag] = $value;
        }
        return $data;
    }

    //随机字符串
    function randomkeys($len)
    {
        $chars='ABDEFGHJKLMNPQRSTVWXYabdefghijkmnpqrstvwxy23456789';
        mt_srand((double)microtime()*1000000*getmypid());
        $password='';
        while(strlen($password)<$len)
            $password.=substr($chars,(mt_rand()%strlen($chars)),1);
        return $password;
    }
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

    //生成朋友圈分享图
    public function getSharePhoto($rpId=0)
    {
        if (!$rpId){
            header('Content-Type: image/jpeg');
            $rp_id = $_GET['rp_id'];
        }else{
            $rp_id = $rpId;
        }
        //获取access_token get
        $grant_type = 'client_credential';
        $appid = 'wxaa7168d609a00c68';
        $secret = 'f28e9c7a4567d190903f760bf56a5f8f';
        $url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type='.$grant_type.'&appid='.$appid.'&secret='.$secret;
        $getAccessToken = $this->curlRequest($url);
        $getAccessToken = json_decode($getAccessToken, true);
        $access_token = $getAccessToken['access_token'];
        //获取小程序码 post
        $url2 = 'https://api.weixin.qq.com/wxa/getwxacode?access_token='.$access_token;
        $postParams = [
            'path' => '/pages/redPacket/redPacket?rp_id='.$rp_id,
            'width' => 430,
            'auto_color' => true,
            //'line_color' => '{"r":"0","g":"0","b":"0"}',
        ];
        $headers = ["Content-type: application/json;charset=UTF-8","Accept: application/json","Cache-Control: no-cache", "Pragma: no-cache"];
        $getCode = $this->curlRequest($url2, json_encode($postParams),$headers);

        if (!$rpId){
            echo $getCode;
        }else{
            $fileName = getcwd().'/phpcms/modules/applet/task/img/'.$rp_id.'.jpg';
            file_put_contents($fileName, $getCode);
            return $fileName;
        }

    }

    //通用 curl请求
    private function curlRequest($url, $data=[], $aHeader=array())
    {
        $curl = curl_init();
        if( count($aHeader) >= 1 ){
            curl_setopt($curl, CURLOPT_HTTPHEADER, $aHeader);
        }
        curl_setopt($curl, CURLOPT_URL, $url);

        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);

        if (!empty($data)){
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($curl);
        curl_close($curl);
        return $output;
    }

    //获取分享图
    public function getPhoto()
    {
//        echo $_SERVER['HTTP_HOST'].'/phpcms/modules/applet/task/rp_750_941.jpg';

//        header('Content-Type: image/jpeg');
        $rp_id = $_GET['rp_id'];
        $rp = $this->find("select * from red_package where id = $rp_id");
        $user = $this->getUser($rp['openid']);
        $photo = $user['headimgurl'];
        $rpBackPhoto = getcwd().'/phpcms/modules/applet/task/img/rp_'.$rp_id.'.jpg';
        copy(getcwd().'/phpcms/modules/applet/task/img/rp_750_941.jpg', $rpBackPhoto);
        $getSharePhoto = $this->getSharePhoto($rp_id);
        $rpBack = imagecreatefromjpeg($rpBackPhoto);//红包背景图
        $touxiang = imagecreatefromjpeg($photo);//头像
        // 下载头像 修改尺寸
        $fn = 'tx_'.$rp_id.'.jpg';
        $fileName = getcwd().'/phpcms/modules/applet/task/img/'.$fn;
        imagejpeg($touxiang, $fileName);
        $this->resizejpg($fileName, $fileName, 110, 110,$fileName);
        $txHandel = imagecreatefromjpeg($fileName);//头像
        // 放上头像
        imagecopymerge($rpBack, $txHandel, 322, 17, 0, 0, imagesx($txHandel), imagesy($txHandel), 100);
        imagejpeg($rpBack, $rpBackPhoto);

        // 放上小程序码
        $this->resizejpg($getSharePhoto, $getSharePhoto, 152, 152,$getSharePhoto);
        $xcxmHandel = imagecreatefromjpeg($getSharePhoto);//小程序码
        imagecopymerge($rpBack, $xcxmHandel, 300, 367, 0, 0, imagesx($xcxmHandel), imagesy($xcxmHandel), 100);
        imagejpeg($rpBack, $rpBackPhoto);

        // 放上口令
        $content = $rp['command'];
        $textcolor = imagecolorallocate($rpBack, 220, 216, 150);//指定字体颜色

        $imagettfbbox = imagettfbbox(26, 0, getcwd()."/phpcms/modules/applet/task/simhei.ttf",$content);
        $x = 375 - (($imagettfbbox[2] - $imagettfbbox[0]) / 2);
        $y = 235;
        imagettftext($rpBack,26,0, $x, $y,$textcolor,getcwd()."/phpcms/modules/applet/task/simhei.ttf",$content);
        imagejpeg($rpBack, $rpBackPhoto);

        echo $_SERVER['HTTP_HOST'].'/phpcms/modules/applet/task/img/rp_'.$rp_id.'.jpg';
    }

    // 重置图片文件大小
    function resizejpg($imgsrc,$imgdst,$imgwidth,$imgheight,$fileName)
    {
        $arr = getimagesize($imgsrc);
        //header("Content-type: image/jpg");
        $imgWidth = $imgwidth;
        $imgHeight = $imgheight;
        $imgsrc = imagecreatefromjpeg($imgsrc);
        $image = imagecreatetruecolor($imgWidth, $imgHeight); //创建一个彩色的底图
        imagecopyresampled($image, $imgsrc, 0, 0, 0, 0,$imgWidth,$imgHeight,$arr[0], $arr[1]);
        imagejpeg($image, $fileName);
    }

    //查看服务器信息
    public function getServerInfo()
    {
        echo json_encode($_SERVER);
    }

    //查看需要过24小时退回余额的红包
    public function handle()
    {
        $expireTime = date('Y-m-d H:i:s', strtotime(date('Y-m-d H:i:s')) - 86400);
        $rps = $this->findAll("SELECT * FROM red_package WHERE red_package.surplus != red_package.number AND create_time <= '{$expireTime}' AND syje != 0");

        echo json_encode([
            $expireTime,
            $rps,
        ]);
    }

    //投诉
    public function complain()
    {
        $res = 0;
        $openid = $_GET['openid'];
        $phone = $_GET['phone'];
        $type = $_GET['type'];//{"a","b"}
//        if ($type != ''){
//            $type = implode(',', json_decode($type, true));
//        }
//var_dump($type);die();
        $complain = $this->create("
            INSERT INTO complain (
                openid,
                phone,
                type,
                create_time
            )
            VALUES
            (
                '$openid',
                '$phone',
                '$type',
                '".date('Y-m-d H:i:s')."'
            )
        ");

        if ($complain > 0){
            $res = 1;
        }

        echo json_encode([
            'res' => $res,
        ]);
    }
}