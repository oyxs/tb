<?php

class DB
{
    public $db;

    public function __construct()
    {
        $this->db = mysqli_connect(
            '120.76.236.188',
            'liguoliang',
            '4UOtEaULfzv8bpvR',
            'novel'
        );
        mysqli_query($this->db , "set names utf8");
    }

    public function __destruct()
    {
        mysqli_close($this->db);
    }

    public function query($sql)
    {
        return mysqli_query($this->db, $sql);
    }

    public function find($sql)
    {
        $data = [];

        $result = $this->query($sql);
        if ($result) {
            $data= mysqli_fetch_assoc($result);
        }
        return $data;
    }

    public function findAll($sql)
    {
        $data = [];
        $result = $this->query($sql);
        if ($result) {
            while($rows = mysqli_fetch_assoc($result)){
                $data[] = $rows;
            }
        }
        return $data;
    }

    public function create($sql)
    {
        $this->query($sql);
        return mysqli_affected_rows($this->db);
    }

    public function update($sql)
    {
        $this->query($sql);
        return mysqli_affected_rows($this->db);
    }

    public function delete($sql)
    {
        $this->query($sql);
        return mysqli_affected_rows($this->db);
    }
}