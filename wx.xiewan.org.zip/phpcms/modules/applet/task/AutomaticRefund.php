<?php

include_once 'DB.php';

class AutomaticRefund extends DB
{
//    public static function redisLink()
//    {
//        $redis = new Redis();
//        $redis->connect('120.76.236.188', 6379);
//        $redis->auth('eyg5ohdampAVnICT9qF2KyCxeg8=');
//        echo "Server is running: " . $redis->ping();
//    }

    public function handle()
    {
        $expireTime = date('Y-m-d H:i:s', strtotime(date('Y-m-d H:i:s')) - 86400);
        $rps = $this->findAll("SELECT * FROM red_package WHERE red_package.surplus != red_package.number AND create_time <= '{$expireTime}' AND syje != 0 AND is_handle = 0");
        $ress = 0;

        if (!empty($rps) && $rps != null){
            foreach ($rps as $rp){
                //红包剩余过期金额 退回用户余额
                $thye = self::updateMoney($rp);
                if ($thye){
                    $ress ++;
                }
            }
        }
        echo $ress;
    }

    //更新红包余额 标记已处理退款
    public function updateMoney($rp)
    {
        $res = 0;
        $openid = $rp['openid'];
        $rpid = $rp['id'];
        $user = $this->find("select * from v9_wx_userinfo where openid = '$openid'");
        $money = $user['money'] + $rp['syje'];
        $update = self::update("UPDATE v9_wx_userinfo SET money = $money WHERE openid = '$openid'");
        $updateRp = self::update("UPDATE red_package SET is_handle = 1 WHERE id = $rpid");
        if ($update > 0 && $updateRp > 0){
            $res = 1;
        }
        return $res;
    }
}

$AutomaticRefund = new AutomaticRefund();
echo $AutomaticRefund->handle();