<?php
/**
 *  extention.func.php 用户自定义函数库
 *
 * @copyright			(C) 2005-2010 PHPCMS
 * @license				http://www.phpcms.cn/license/
 * @lastmodify			2010-10-27
 */

/**
* 根据box类型字段获取显示名称
* @param $field 字段名称
* @param $value 字段值
* @param $modelid 字段所在模型id
*/
function box($field, $value, $modelid='') {
        $fields = getcache('model_field_'.$modelid,'model');
        extract(string2array($fields[$field]['setting']));
        $options = explode("\n",$fields[$field]['options']);
        foreach($options as $_k) {
                $v = explode("|",$_k);
                $k = trim($v[1]);
                $option[$k] = $v[0];
        }
        $string = '';
        switch($fields[$field]['boxtype']) {
                        case 'radio':
                                $string = $option[$value];
                        break;

                        case 'checkbox':
                                $value_arr = explode(',',$value);
                                foreach($value_arr as $_v) {
                                        if($_v) $string .= $option[$_v].' 、';
                                }
                        break;

                        case 'select':
                                $string = $option[$value];
                        break;

                        case 'multiple':
                                $value_arr = explode(',',$value);
                                foreach($value_arr as $_v) {
                                        if($_v) $string .= $option[$_v].' 、';
                                }
                        break;
                }
                        return $string;
}
 
?>