<?php
$LANG['keyword_manage'] = '';
$LANG['keyword_name'] = '关键词';
$LANG['remove_all_selected']			=	'删除选定的敏感词';
?>