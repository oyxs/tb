<?php
namespace App\Http\Controllers;

use App\Models\BroadsideAdCount;
use App\Models\IpLocation;
use App\Models\TestAd;
use App\Models\TopAdCount;
use Illuminate\Http\Request;
use App\Models\Ad as Ad;

class AdController extends Controller {

    /**
     * Show the profile for the given user.
     *
     * @param  int  $id
     * @return Response
     */
    public function get(Request $request, $id) {
	$userev = $request->input('userev') ? $request->input('userev') : 0;
	$page=rand(1,5);
	if($page<=3){
		$page=0;
	}else{
		$page=1;
	}
	$sdsoft = $request->input('sdsoft');
	$winver = $request->input('winver') ? $request->input('winver') : 0;
        $adObj = new Ad();
        $data = $adObj->getProcessData($request->ip(), $sdsoft, $id,$page);
        if(empty($data)) {
            exit("FALSE");
        }
		if($userev >0){
			$sites = $adObj->getProcessData($request->ip(), $sdsoft,7,$page);
			if(!empty($sites)) {
				$sites['site'] = $data['site'];
				$data=$sites;
			}
		}

        if ($id == 3) {
            $data['site']['customArea'] = "";
        } else {
            $data['site']['customArea'] = '<libmem url="http://image.zheguow.com/upload/downer/fx/data14.jpg" md5="FBDD37317D273752D5A522ABB623EA3E"/>';
        }



        $data['winver']=$winver;

        //优质浏览器替换
        /*$randNum=$this->random(10, '123456789abcdefghijklmnpqrstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ');
        foreach($data['content']  as $k =>$v){
            foreach($v as $key=>$value){
                if(is_array($value)){
                    if($value['id']==23){
                       $data['content'][$k][$key]['savePath'] ="tengxllq_".$randNum.".exe";
                       $data['content'][$k][$key]['link'] = "http://static.zhijunboji.com/www/uploadfile/2017/0811/tengxllq_".$randNum.".exe";
                    }
                }

            }
        }*/

        header("Content-Type: text/xml;charset=UTF-8");
        return view("ad.get", $data);
    }

    /**
     * @param Request $request
     * @param $id
     * @return \Illuminate\View\View
     * 新广告接口
     */
    public function ad(Request $request, $id)
    {

        $userev = $request->input('userev') ? $request->input('userev') : 0;
        $page=rand(1,5);
        if($page<=3){
            $page=0;
        }else{
            $page=1;
        }
      
        $sdsoft = $request->input('sdsoft');
        $winver = $request->input('winver') ? $request->input('winver') : 0;
        $adObj = new Ad();

        $data = $adObj->getProcessData($request->ip(), $sdsoft, $id,$page);


        if(empty($data)) {
            exit("FALSE");
        }else{
           
            $material_id_1 = !empty($data['content']['page5'][0]['id'])?$data['content']['page5'][0]['id']:'';
            $material_id_2 = !empty($data['content']['page5'][1]['id'])?$data['content']['page5'][1]['id']:'';

            $siteId = $id;
            new TopAdCount();
            $ip = new IpLocation();
            $cityName  = $ip->getCityName($request->ip());
            $topAdCount = new TopAdCount();
            if(!empty($material_id_1)){
                $topAdCount->adCount($siteId,$material_id_1,$request->ip(),$cityName,'show');
            }
            if(!empty($material_id_2)){
                $topAdCount->adCount($siteId,$material_id_2,$request->ip(),$cityName,'show');
            }
        }
        if($userev >0){
            $sites = $adObj->getProcessData($request->ip(), $sdsoft,7,$page);
            if(!empty($sites)) {
                $sites['site'] = $data['site'];
                $data=$sites;
            }
        }
        $data['winver']=$winver;
        $data['date']=date("w");
        $data['slide'] = "http://api.zheguow.com/slide?id=".$id;
        header("Content-Type: text/xml;charset=UTF-8");
        return view("ad.ad", $data);
    }

    public function BakGet(Request $request, $id) {
        error_reporting(E_ALL);
        ini_set('display_errors', 'On');
        $data = Ad::getByIp($request->ip(), $id);
        if(empty($data)) {
            exit("FALSE");
        }
        header("Content-Type: text/xml;charset=UTF-8");
        return view("ad.get", $data);
    }

    /**
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     * 顶部广告统计接口
     */
    public function TopAdCount(Request $request)
    {
        $siteId = $request->input('site_id') ? $request->input('site_id') : 0;
        $materialId = $request->input('material_id') ? $request->input('material_id') : 0;
        if($siteId==0||$materialId==0){
            die('参数错误');
        }
        $ip = new IpLocation();
        $cityName  = $ip->getCityName($request->ip());
        $topAdCount = new TopAdCount();
        $result = $topAdCount->adCount($siteId,$materialId,$request->ip(),$cityName);
        if($result){
            $data = array('static'=>'ok');
        }else{
            $data = array( 'static'=>'false');
        }
        return response()->json($data);
    }

    /**
     * @param Request $request
     * 侧边广告接口
     */
    public function BroadsideAdCount(Request $request)
    {
        //$id = $request->input('id') ? $request->input('id') : 0;//站点ID
        $siteId = $request->input('siteId') ? $request->input('siteId') : 0;
        $material_id_all = $request->input('material_id_all') ? $request->input('material_id_all') : 0;//物料id字符串
        $material_id = $request->input('material_id') ? $request->input('material_id') : 0;//点击物料ID
        $key_id = $request->input('key_id') ? $request->input('key_id') : 0;//第几个物料

        $ip = new IpLocation();
        $cityName  = $ip->getCityName($request->ip());
        $BroadsideAdCount = new BroadsideAdCount();

        $result = $BroadsideAdCount->adCount( $material_id,$siteId,$material_id_all,$key_id,$request->ip(),$cityName);

        if($result){
            $data = array('static'=>'ok');
        }else{
            $data = array( 'static'=>'false');
        }
        return response()->json($data);

    }

    /*function random($length, $chars = '1234567890') {
        $hash = '';
        $max = strlen($chars) - 1;
        for($i = 0; $i < $length; $i++) {
            $hash .= $chars[mt_rand(0, $max)];
        }
        return $hash;
    }*/
    
}

