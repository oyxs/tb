<?php namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Zhuzhichao\IpLocationZh\Ip;
use App\Models\User;
use App\Models\Ad;
class SiteController extends Controller {
    public function error(Request $request) {
        $userev = $request->input('userev') ? $request->input('userev') : 0;
    	echo 'OK';
    }
    
    public function stat(Request $request) {
        $userev = $request->input('userev') ? $request->input('userev') : 0;
        echo 'OK';
    }
    public function url(Request $request){

        $webid = $request->get('webid');
        if($webid==3||$webid==7){
            $data = [
                
            ];
        }elseif($webid==6){
            $data = [
                ['name'=>'爱淘宝','url'=>'http://atb.wuyouba.com/'],
                ['name'=>'天猫','url'=>'http://tm.wuyouba.com/'],
            ];

        }else{
            $data = [
                ['name'=>'百度一下,你就知道','url'=>'http://bd.xuyisc.com/'],
                ['name'=>'淘宝网','url'=>'http://an.887510.net'],
                ['name'=>'全场9.9特卖','url'=>'http://zktbbt.91ecc.com/'],
                ['name'=>'聚划算','url'=>'http://gobuy.887510.net'],
                ['name'=>'爱淘宝_淘优惠','url'=>'http://goshop.887510.net'],
                ['name'=>'京东商城','url'=>'http://www.zheguow.com/jd_arive.html'],
            ];
        }
        return response()->json($data);

    }
    public function md(Request $request)
    {

        $webid = $request->get('webid');
        header("Content-type: text/xml");
        //if($webid==2||$webid==4||$webid==5||$webid==9||$webid==10){
		if($webid==100000){	
			echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
				echo "<DOCUMENT>
					<data><![CDATA[http://image.zheguow.com/module/md.txt]]></data>
	                <hash>E0C4417EC6F81C16FE501D72C83CDDDA</hash>
				</DOCUMENT>";
			
		}else{ 
			echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
            echo "<DOCUMENT>
					<data></data>
	                <hash></hash>
				</DOCUMENT>";
		}
		

    }

    /**
     * @param Request $request
     * 轮播图页面
     */
    public function slide(Request $request)
    {

        $siteId = $request->get('id');
        $adObj = new ad();
        $ad = $adObj->getSiteAd($siteId);

        $content = $ad->content;
        $data['content'] = unserialize($content)[0]['page6'];


        $data['date'] = date('w');
        $data['siteId'] = $siteId;
        return view("ad.slide", $data);
    }


}
