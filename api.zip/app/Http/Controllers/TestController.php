<?php namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TestAd as TestAd;

class TestController extends Controller {

    /**
     * Show the profile for the given user.
     * 
     * @param  int  $id
     * @return Response
     */
    public function get(Request $request, $id) {
        error_reporting(E_ALL);
        ini_set('display_errors', 'On');
        $sdsoft = $request->input('sdsoft');
        $adObj = new TestAd();
		$data = $adObj->getProcessData($request->ip(), $sdsoft, $id);
        if(empty($data)) {
            exit("FALSE");
        }
        header("Content-Type: text/xml;charset=UTF-8");
		return view("ad.get", $data);
    }
    
}
