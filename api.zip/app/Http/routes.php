<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

$app->get('/', function() use ($app) {
    echo '<center>welcome to api.down.72zx.com!</center>';
});

$app->get('/xml/{id:[0-9]+}', [
	'uses' => 'App\Http\Controllers\AdController@get'
]);
$app->get('/ad/{id:[0-9]+}', [
		'uses' => 'App\Http\Controllers\AdController@ad'
]);

$app->get('/slide', [
		'uses' => 'App\Http\Controllers\SiteController@slide'
]);
$app->post('/topadcount', [
		'uses' => 'App\Http\Controllers\AdController@TopAdCount'
]);
$app->post('/broadsideadcount', [
		'uses' => 'App\Http\Controllers\AdController@BroadsideAdCount'
]);


$app->get('/test', [
		'uses' => 'App\Http\Controllers\AdController@test'
]);
$app->get('/stat', [
	'uses' => 'App\Http\Controllers\SiteController@stat'
]);
$app->get('/url', [
		'uses' => 'App\Http\Controllers\SiteController@url'
]);
$app->get('/md', [
		'uses' => 'App\Http\Controllers\SiteController@md'
]);

$app->get('/error', [
	'uses' => 'App\Http\Controllers\SiteController@error'
]);

$app->get('/testxml/{id:[0-9]+}', [
	'uses' => 'App\Http\Controllers\TestController@get'
]);