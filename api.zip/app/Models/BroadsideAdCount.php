<?php namespace App\Models;


class BroadsideAdCount {



    public function adCount( $material_id,$siteId,$material_id_all,$key_id,$ip,$cityName) {

        /*$date = date("Y-m-d");
        $get_data = app('db')->table('top_ad_count')->where(['ip'=>$ip,'material_id'=>$id,'create_time'=>$date])->get();
        if(!$get_data){*/


        if($key_id!=0){//页面点击事件
            $click = "click_".$key_id;
            $data = array(
                'siteId'=>$siteId,
                'material_id'=> $material_id.',',
                'create_time'=>date("Y-m-d"),
                'ip'=>$ip,
                'city_name' =>$cityName,
                'time' =>time(),
                "$click"=>1
            );
        }else{//轮播图页面调用时加载
            $material_id_data = explode(',',$material_id_all);
            $data = array(
                'create_time'=>date("Y-m-d"),
                'ip'=>$ip,
                'city_name' =>$cityName,
                'time' =>time(),
                'material_id' =>$material_id_all,
                'siteId'=>$siteId
            );
            foreach($material_id_data as $key=>$v){//显示物料标记
                if(!empty($v)){
                    $k = $key+1;
                    $k="show_".$k;
                    $data[$k]=1;
                }

            }

        }

        $count= app('db')->table('broad_side_adcount')->insert($data);
        return $count;
        /*}else{
            return 0;
        }*/
    }


}
