<?php namespace App\Models;
use Zhuzhichao\IpLocationZh\Ip as Ip;

class IpLocation {
	private static $firLevelCities = ['北京', '上海', '深圳', '广州', '天津', '常州', '马鞍山'];
	private static $secLevelCities = [
		'杭州','南京','济南','重庆','青岛','大连','宁波','厦门',
		'成都','武汉','哈尔滨','沈阳','西安','长春','长沙','福州',
		'郑州','石家庄','苏州','佛山','东莞','无锡','烟台','太原',
		'合肥','南昌','南宁','昆明','温州','淄博','唐山'
	];

	private static $txCities = ['深圳'];

	public static function isFirstLevelCity($ip) {
		$city = static::getCityName($ip);
		if(empty($city)) {
			return false;
		}
		if(in_array($city, static::$firLevelCities)) {
			return true;
		}
		return false;
	}

	public static function isTxCity($ip) {
		$city = static::getCityName($ip);
		if(empty($city)) {
			return false;
		}
		if(in_array($city, static::$txCities)) {
			return true;
		}
		return false;
	}

	public static function getCityName($ip) {
        $ipinfo = Ip::find($ip);
        if(empty($ipinfo[2])) {
        	return false;
        }
        return $ipinfo[2];
	}
}
