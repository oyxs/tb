<?php namespace App\Models;


class TopAdCount {


    /**
     * @param $id
     * @param $ip
     * @param $cityName
     * @return int
     * 顶部广告统计
     */
    public function adCount($siteId,$materialId,$ip,$cityName,$type='click') {
        $date = date("Y-m-d");
        /*$get_data = app('db')->table('top_ad_count')->where(['ip'=>$ip,'material_id'=>$id,'create_time'=>$date])->get();
        if(!$get_data){*/

        if($type =='click'){
            $data = array(
                'material_id'=>$materialId,
                'siteId'=>$siteId,
                'create_time'=>date("Y-m-d"),
                'ip'=>$ip,
                'city_name' =>$cityName,
                'time' =>time(),
                'click' =>1
            );
        }else{//展示
            $data = array(
                'material_id'=>$materialId,
                'siteId'=>$siteId,
                'create_time'=>date("Y-m-d"),
                'ip'=>$ip,
                'city_name' =>$cityName,
                'time' =>time(),
                'show' =>1
            );
        }


        $count= app('db')->table('top_ad_count')->insert($data);
            return $count;
        /*}else{
            return 0;
        }*/
    }


    public function showCount($id,$ip,$cityName)
    {
        $date = date("Y-m-d");
        /*$get_data = app('db')->table('top_ad_count')->where(['ip'=>$ip,'material_id'=>$id,'create_time'=>$date])->get();
        if(!$get_data){*/
        $data = array(
            'material_id'=>$id,
            'create_time'=>date("Y-m-d"),
            'ip'=>$ip,
            'city_name' =>$cityName,
            'time' =>time(),
            'click' =>1
        );

        $count= app('db')->table('top_ad_count')->insert($data);
        return $count;
        /*}else{
            return 0;
        }*/
    }


}
