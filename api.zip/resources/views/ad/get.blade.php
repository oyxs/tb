{!! '<'.'?xml version="1.0" encoding="UTF-8"?'.'>' !!}
<root>
	<web>
		<id>{{ $site['id'] }}</id>
		<name>{{ $site['name'] }}</name>
		<tag>{{ $site['apiTag'] }}</tag>
		<xmlurl><![CDATA[{!! $site['apiUrl'] !!}]]></xmlurl>
		<logourl><![CDATA[{{ $site['siteIcon'] }}]]></logourl>
		<firstlevelcity>{{ $site['firstlevelcity']?1:0 }}</firstlevelcity>
		<search><![CDATA[{!! $site['search'] !!}]]></search>
	</web>

	<task>
@foreach ($content as $key => $val)
	@if ($key!='alternative')
		<taskgroup page="{{ substr($key,4) }}">
		@foreach ($val as $v)
		@if ($v!='')
			@if ($v['type']=='startpage')
			<task silent="{{ $v['silent'] }}" taskid="{{ $v['id'] }}" tasktype="startpage" taskname="{{ $v['name'] }}" taskcolor="{{ $v['linkColor'] }}" tiptext="{{ $v['tip'] }}" defcheck="{{ $v['defCheck'] }}" deskname="{{ $v['linkName'] }}" altid="{{ $v['altid'] or '' }}">
				<taskurl><![CDATA[{!! $v['link'] !!}]]></taskurl>
			</task>
			@elseif ($v['type']=='install')
			<task silent="{{ $v['silent'] }}" taskid="{{ $v['id'] }}" tasktype="install" taskname="{{ $v['name'] }}" taskcolor="{{ $v['linkColor'] }}" tiptext="{{ $v['tip'] }}" defcheck="{{ $v['defCheck'] }}" savepath="{!! htmlspecialchars($v['savePath']) !!}" rootkey="{{ $v['rootKey'] }}" keyname="{{ $v['keyName'] }}" regext="{{ $v['regExt'] }}" altid="{{ $v['altid'] or '' }}" detectitem="{{ $v['detectItem'] or '' }}">
				<taskurl><![CDATA[{!! $v['link'] !!}]]></taskurl>
				<logourl><![CDATA[{{ trim($v['linkIcon']) }}]]></logourl>
				<cmdline><![CDATA[{!! $v['cmdLine'] !!}]]></cmdline>
			</task>
			@elseif ($v['type']=='createlink')
			<task silent="{{ $v['silent'] }}" taskid="{{ $v['id'] }}" tasktype="createlink" taskname="{{ $v['name'] }}" taskcolor="{{ $v['linkColor'] }}" tiptext="{{ $v['tip'] }}" defcheck="{{ $v['defCheck'] }}" savepath="{{ $v['savePath'] }}" deskname="{{ $v['linkName'] }}" altid="{{ $v['altid'] or '' }}">
				<taskurl><![CDATA[{!! $v['link'] !!}]]></taskurl>
				<linkico><![CDATA[{{ trim($v['linkIcon']) }}]]></linkico>
				@if(isset($v['logoUrl']))
				<logourl><![CDATA[{{ trim($v['logoUrl']) }}]]></logourl>
				@endif
			</task>
			@endif
		@endif
		@endforeach
		</taskgroup>
	@else 
		<alternative>
		@foreach ($val as $v)
		@if ($v!='')
			@if ($v['type']=='startpage')
			<task silent="{{ $v['silent'] }}" taskid="{{ $v['id'] }}" tasktype="startpage" taskname="{{ $v['name'] }}" taskcolor="{{ $v['linkColor'] }}" tiptext="{{ $v['tip'] }}" deskname="{{ $v['linkName'] }}" defcheck="{{ $v['defCheck'] }}">
				<taskurl><![CDATA[{!! $v['link'] !!}]]></taskurl>
			</task>
			@elseif ($v['type']=='install')
			<task silent="{{ $v['silent'] }}" taskid="{{ $v['id'] }}" tasktype="install" taskname="{{ $v['name'] }}" taskcolor="{{ $v['linkColor'] }}" tiptext="{{ $v['tip'] }}" defcheck="{{ $v['defCheck'] }}" savepath="{{ $v['savePath'] }}" rootkey="{{ $v['rootKey'] }}" keyname="{{ $v['keyName'] }}" regext="{{ $v['regExt'] }}">
				<taskurl><![CDATA[{!! $v['link'] !!}]]></taskurl>
				<logourl><![CDATA[{{ $v['linkIcon'] }}]]></logourl>
				<cmdline><![CDATA[{!! $v['cmdLine'] !!}]]></cmdline>
			</task>
			@elseif ($v['type']=='createlink')
			<task silent="{{ $v['silent'] }}" taskid="{{ $v['id'] }}" tasktype="createlink" taskname="{{ $v['name'] }}" taskcolor="{{ $v['linkColor'] }}" tiptext="{{ $v['tip'] }}" defcheck="{{ $v['defCheck'] }}" savepath="{{ $v['savePath'] }}" deskname="{{ $v['linkName'] }}">
				<taskurl><![CDATA[{!! $v['link'] !!}]]></taskurl>
				<linkico><![CDATA[{{ $v['linkIcon'] }}]]></linkico>
				@if(isset($v['logoUrl']))
				<logourl><![CDATA[{{trim($v['logoUrl'])}}]]></logourl>
				@endif
			</task>
			@endif
		@endif
		@endforeach
		</alternative>
	@endif
@endforeach

		<ChkCapColor>{{ $extra['ChkCapColor'] or '$FF000000' }}</ChkCapColor>
		<ChkTipColor>{{ $extra['ChkTipColor'] or '$FF000000' }}</ChkTipColor>
		<taskset>{{ $extra['taskset'] or 0 }}</taskset>
		<adweburl>
			<url><![CDATA[{!! $extra['adweburl1'] or '' !!}]]></url>
			<url><![CDATA[{!! $extra['adweburl2'] or '' !!}]]></url>
		</adweburl>
		<onclose>
			<url><![CDATA[{!! $extra['onclose'] or '' !!}]]></url>
	    </onclose>
	    {!! $site['customArea'] or '' !!}
	</task>
</root>
