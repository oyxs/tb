<!DOCTYPE html>
<html>
<head>
	<title>广告</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=8" />
	<meta id=“viewport” content="width=device-width; initial-scale=1.0; minimum-scale=0.5; maximum-scale=2.0; user-scalable=yes;" />
	<link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body style="padding:50px 0px 0px 50px;">
<div class="ad tmall-brand">
	<div class="time_bg"></div>
	<span id="ds2"></span>
	<ul class="slider-nav">
		@foreach ($content as $v)
			@if(!empty($v['id']))
		<li ><a href="javascript:void(0)"></a></li>
			@endif
		@endforeach
	</ul>
	<div class="ad_list" site-id = {{$siteId}}>
		<ul class="ad_list_ul">
			@foreach ($content as $key=> $v)
				@if(!empty($v['id']))
					@if($v['type']=='imglink'||$v['type']=='giflink')
			<li class="adClick" key-id="{{$key+1}}" material-id="{{$v['id']}}"><a href="{{$v['link']}}"  title="{{$v['linkName']}}" target="_blank"><img src="{{$v['img']}}" width="145" height="370"></a></li>
					@elseif($v['type']=='swflink')
						<li><a  class="adClick" key-id="{{$key+1}}" material-id="{{$v['id']}}" href="{{$v['link']}}" title="{{$v['linkName']}}" target="_blank"></a><embed  src="{{$v['img']}}" width="145" height="370"></embed></li>
					@endif
				@endif
			@endforeach
		</ul>
	</div>
</div>
<script src="js/jquery-1.10.1.min.js" type="text/javascript" charset="utf-8"></script>
<script src="js/jquery.SuperSlide.2.1.1.js" type="text/javascript" charset="utf-8"></script>
<script>
	$(function(){
		var siteId =$(".ad_list").attr("site-id");
		var material_id_all='';
		$(".adClick").each(function(){
			material_id_all+=$(this).attr("material-id")+',';
		});
		$.ajax({
			type:"POST",
			url:"/broadsideadcount",
			data: {material_id_all:material_id_all,siteId:siteId},
			async:true,
		});
		$(".adClick").click(function(){
			var material_id = $(this).attr("material-id");
			var key_id = $(this).attr("key-id");
			$.ajax({
				type:"POST",
				url:"/broadsideadcount",
				data: {material_id:material_id,key_id:key_id,siteId:siteId},
				async:true,
				success:function(data){
				}
			});
		});
	});

	var s=5,t1=null;
	function show(){
		s--;
		if(s>0){
			$("#ds2").html(s);
		}else{
			$("#ds2").html(0);
			return;
		}
	}
	jQuery(".tmall-brand").slide({
		titCell:".slider-nav li",
		mainCell:".ad_list_ul",
		effect:"left",
		delayTime:300,
		autoPlay:true,
		interTime:5000,
		mouseOverStop:false,
		endFun:function(){
			clearInterval(t1);
			s=5;
			show();
			t1 = setInterval(show, 1000);
		}
	});
</script>
</body>
</html>