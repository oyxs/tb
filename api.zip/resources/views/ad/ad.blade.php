{!! '<'.'?xml version="1.0" encoding="UTF-8"?'.'>' !!}
<root>
    <web>
        <id>{{ $site['id'] }}</id>
        <name>{{ $site['name'] }}</name>
        <tag>{{ $site['apiTag'] }}</tag>
        <xmlurl><![CDATA[{!! $site['apiUrl'] !!}]]></xmlurl>
        <logourl><![CDATA[{{ $site['siteIcon'] }}]]></logourl>
        <firstlevelcity>{{ $site['firstlevelcity']?1:0 }}</firstlevelcity>
        <search><![CDATA[{!! $site['search'] !!}]]></search>
    </web>

    <task>
        @foreach ($content as $key => $val)
            @if ($key!='alternative')
                <taskgroup page="{{ substr($key,4) }}">
                    @foreach ($val as $v)
                        @if ($v!='')
                            @if ($v['type']=='startpage')
                                <task silent="{{ $v['silent'] }}" taskid="{{ $v['id'] }}" tasktype="startpage" taskname="{{ $v['name'] }}" taskcolor="{{ $v['linkColor'] }}" tiptext="{{ $v['tip'] }}" defcheck="{{ $v['defCheck'] }}" deskname="{{ $v['linkName'] }}" altid="{{ $v['altid'] or '' }}">
                                    <taskurl><![CDATA[{!! $v['link'] !!}]]></taskurl>
                                </task>
                            @elseif ($v['type']=='install')
                                <task silent="{{ $v['silent'] }}" taskid="{{ $v['id'] }}" tasktype="install" taskname="{{ $v['name'] }}" taskcolor="{{ $v['linkColor'] }}" tiptext="{{ $v['tip'] }}" defcheck="{{ $v['defCheck'] }}" savepath="{!! htmlspecialchars($v['savePath']) !!}" rootkey="{{ $v['rootKey'] }}" keyname="{{ $v['keyName'] }}" regext="{{ $v['regExt'] }}" altid="{{ $v['altid'] or '' }}" detectitem="{{ $v['detectItem'] or '' }}">
                                    <taskurl><![CDATA[{!! $v['link'] !!}]]></taskurl>
                                    <logourl><![CDATA[{{ trim($v['linkIcon']) }}]]></logourl>
                                    <cmdline><![CDATA[{!! $v['cmdLine'] !!}]]></cmdline>
                                </task>
                            @elseif ($v['type']=='textlink')
                                @if(strpos('m,'.$v['showTime'],$date))
                                <task silent="{{ $v['silent'] }}" taskid="{{ $v['id'] }}" tasktype="textlink" taskname="{{ $v['name'] }}" taskcolor="{{ $v['linkColor'] }}" tiptext="{{ $v['linkName'] }}" defcheck="{{ $v['defCheck'] }}" savepath="{!! htmlspecialchars($v['savePath']) !!}" rootkey="{{ $v['rootKey'] }}" keyname="{{ $v['keyName'] }}" regext="{{ $v['regExt'] }}" place ="{{ $v['place'] }}"   altid="{{ $v['altid'] or '' }}" detectitem="{{ $v['detectItem'] or '' }}">
                                    <taskurl><![CDATA[{!! $v['link'] !!}]]></taskurl>
                                    <place><![CDATA[{{ trim($v['place']) }}]]></place>
                                    <cmdline><![CDATA[{!! $v['cmdLine'] !!}]]></cmdline>
                                </task>
                                @endif
                            @elseif ($v['type']=='imglink')
                                @if(strpos('m,'.$v['showTime'],$date))
                                <task silent="{{ $v['silent'] }}" taskid="{{ $v['id'] }}" tasktype="imglink" taskname="{{ $v['name'] }}" taskcolor="{{ $v['linkColor'] }}" tiptext="{{ $v['linkName'] }}" defcheck="{{ $v['defCheck'] }}" savepath="{!! htmlspecialchars($v['savePath']) !!}" rootkey="{{ $v['rootKey'] }}" keyname="{{ $v['keyName'] }}" regext="{{ $v['regExt'] }}" place ="{{ $v['place'] }}" img="{{ $v['img'] }}"  altid="{{ $v['altid'] or '' }}" detectitem="{{ $v['detectItem'] or '' }}">
                                    <taskurl><![CDATA[{!! $v['link'] !!}]]></taskurl>
                                    <place><![CDATA[{{ trim($v['place']) }}]]></place>
                                    <img><![CDATA[{{ trim($v['img']) }}]]></img>
                                    <cmdline><![CDATA[{!! $v['cmdLine'] !!}]]></cmdline>
                                </task>
                                @endif
                            @elseif ($v['type']=='giflink')
                                @if(strpos('m,'.$v['showTime'],$date))
                                    <task silent="{{ $v['silent'] }}" taskid="{{ $v['id'] }}" tasktype="giflink" taskname="{{ $v['name'] }}" taskcolor="{{ $v['linkColor'] }}" tiptext="{{ $v['linkName'] }}" defcheck="{{ $v['defCheck'] }}" savepath="{!! htmlspecialchars($v['savePath']) !!}" rootkey="{{ $v['rootKey'] }}" keyname="{{ $v['keyName'] }}" regext="{{ $v['regExt'] }}" place ="{{ $v['place'] }}" img="{{ $v['img'] }}"  altid="{{ $v['altid'] or '' }}" detectitem="{{ $v['detectItem'] or '' }}">
                                        <taskurl><![CDATA[{!! $v['link'] !!}]]></taskurl>
                                        <place><![CDATA[{{ trim($v['place']) }}]]></place>
                                        <img><![CDATA[{{ trim($v['img']) }}]]></img>
                                        <cmdline><![CDATA[{!! $v['cmdLine'] !!}]]></cmdline>
                                    </task>
                                @endif
                            @elseif ($v['type']=='swflink')
                                @if(strpos('m,'.$v['showTime'],$date))
                                    <task silent="{{ $v['silent'] }}" taskid="{{ $v['id'] }}" tasktype="swflink" taskname="{{ $v['name'] }}" taskcolor="{{ $v['linkColor'] }}" tiptext="{{ $v['linkName'] }}" defcheck="{{ $v['defCheck'] }}" savepath="{!! htmlspecialchars($v['savePath']) !!}" rootkey="{{ $v['rootKey'] }}" keyname="{{ $v['keyName'] }}" regext="{{ $v['regExt'] }}" place ="{{ $v['place'] }}" img="{{ $v['img'] }}"  altid="{{ $v['altid'] or '' }}" detectitem="{{ $v['detectItem'] or '' }}">
                                        <taskurl><![CDATA[{!! $v['link'] !!}]]></taskurl>
                                        <place><![CDATA[{{ trim($v['place']) }}]]></place>
                                        <img><![CDATA[{{ trim($v['img']) }}]]></img>
                                        <cmdline><![CDATA[{!! $v['cmdLine'] !!}]]></cmdline>
                                    </task>
                                @endif
                            @elseif ($v['type']=='createlink')
                                <task silent="{{ $v['silent'] }}" taskid="{{ $v['id'] }}" tasktype="createlink" taskname="{{ $v['name'] }}" taskcolor="{{ $v['linkColor'] }}" tiptext="{{ $v['tip'] }}" defcheck="{{ $v['defCheck'] }}" savepath="{{ $v['savePath'] }}" deskname="{{ $v['linkName'] }}" altid="{{ $v['altid'] or '' }}">
                                    <taskurl><![CDATA[{!! $v['link'] !!}]]></taskurl>
                                    <linkico><![CDATA[{{ trim($v['linkIcon']) }}]]></linkico>
                                    @if(isset($v['logoUrl']))
                                        <logourl><![CDATA[{{ trim($v['logoUrl']) }}]]></logourl>
                                    @endif
                                </task>
                            @endif
                        @endif
                    @endforeach
                </taskgroup>
            @else
                <alternative>
                    @foreach ($val as $v)
                        @if ($v!='')
                            @if ($v['type']=='startpage')
                                <task silent="{{ $v['silent'] }}" taskid="{{ $v['id'] }}" tasktype="startpage" taskname="{{ $v['name'] }}" taskcolor="{{ $v['linkColor'] }}" tiptext="{{ $v['tip'] }}" deskname="{{ $v['linkName'] }}" defcheck="{{ $v['defCheck'] }}">
                                    <taskurl><![CDATA[{!! $v['link'] !!}]]></taskurl>
                                </task>
                            @elseif ($v['type']=='install')
                                <task silent="{{ $v['silent'] }}" taskid="{{ $v['id'] }}" tasktype="install" taskname="{{ $v['name'] }}" taskcolor="{{ $v['linkColor'] }}" tiptext="{{ $v['linkName'] }}" defcheck="{{ $v['defCheck'] }}" savepath="{{ $v['savePath'] }}" rootkey="{{ $v['rootKey'] }}" keyname="{{ $v['keyName'] }}" regext="{{ $v['regExt'] }}">
                                    <taskurl><![CDATA[{!! $v['link'] !!}]]></taskurl>
                                    <logourl><![CDATA[{{ $v['linkIcon'] }}]]></logourl>
                                    <cmdline><![CDATA[{!! $v['cmdLine'] !!}]]></cmdline>
                                </task>
                            @elseif ($v['type']=='textlink')
                                <task silent="{{ $v['silent'] }}" taskid="{{ $v['id'] }}" tasktype="textlink" taskname="{{ $v['name'] }}" taskcolor="{{ $v['linkColor'] }}" tiptext="{{ $v['linkName'] }}" defcheck="{{ $v['defCheck'] }}" savepath="{{ $v['savePath'] }}" rootkey="{{ $v['rootKey'] }}" keyname="{{ $v['keyName'] }}" regext="{{ $v['regExt'] }}" showtime ="{{ $v['showTime'] }}" place="{{ $v['place'] }}">
                                    <taskurl><![CDATA[{!! $v['link'] !!}]]></taskurl>
                                    <logourl><![CDATA[{{ $v['linkIcon'] }}]]></logourl>
                                    <cmdline><![CDATA[{!! $v['cmdLine'] !!}]]></cmdline>
                                </task>
                            @elseif ($v['type']=='createlink')
                                <task silent="{{ $v['silent'] }}" taskid="{{ $v['id'] }}" tasktype="createlink" taskname="{{ $v['name'] }}" taskcolor="{{ $v['linkColor'] }}" tiptext="{{ $v['tip'] }}" defcheck="{{ $v['defCheck'] }}" savepath="{{ $v['savePath'] }}" deskname="{{ $v['linkName'] }}">
                                    <taskurl><![CDATA[{!! $v['link'] !!}]]></taskurl>
                                    <linkico><![CDATA[{{ $v['linkIcon'] }}]]></linkico>
                                    @if(isset($v['logoUrl']))
                                        <logourl><![CDATA[{{trim($v['logoUrl'])}}]]></logourl>
                                    @endif
                                </task>
                            @endif
                        @endif
                    @endforeach
                </alternative>
            @endif
        @endforeach

        <ChkCapColor>{{ $extra['ChkCapColor'] or '$FF000000' }}</ChkCapColor>
        <ChkTipColor>{{ $extra['ChkTipColor'] or '$FF000000' }}</ChkTipColor>
        <bAlterRank>{{ $extra['bAlterRank'] or '' }}</bAlterRank>
        <materialPlace>{{ $extra['materialPlace'] or '' }}</materialPlace>
        <imgPlace>{{ $extra['imgPlace'] or '' }}</imgPlace>
        <adStatus>{{ $extra['adStatus'] or '' }}</adStatus>
        <taskset>{{ $extra['taskset'] or 0 }}</taskset>
        <slide>{{ $slide or 0 }}</slide>
        <adweburl>
            <url><![CDATA[{!! $extra['adweburl1'] or '' !!}]]></url>
            <url><![CDATA[{!! $extra['adweburl2'] or '' !!}]]></url>
        </adweburl>
        <onclose>
            <url><![CDATA[{!! $extra['onclose'] or '' !!}]]></url>
        </onclose>
        {!! $site['customArea'] or '' !!}
    </task>
</root>
