#!/usr/bin/env python
import pymysql

DBCONFIG = { 'host': '127.0.0.1',
             'port': 3306,
             'user': 'remote',
             'password': 'jfC8Uj9u6eQKoD3S',
             'db': 'kr126',
             'charset': 'utf8' }
sql1 = 'select catid,shorttitle,version from v9_app group by catid,shorttitle,version having count(*)>1;'
sql2 = 'select id from v9_app where catid = %s and shorttitle = %s and version = %s;'
sql3 = 'delete from v9_app where id in ({0});'
sql4 = 'delete from v9_app_data where id in ({0});'
conn = pymysql.connect(**DBCONFIG)
with conn.cursor() as cursor:
    cursor.execute(sql1)
    res = cursor.fetchall()
    for catid, shorttitle, version in res:
        cursor.execute(sql2, (catid, shorttitle, version))
        id_res = cursor.fetchall()
        id_tuple = tuple([ r[0] for r in id_res ][1:])
        id_num = len(id_tuple)
        if id_num > 0:
            cursor.execute(sql3.format(','.join(['%s'] * id_num)), id_tuple)
            cursor.execute(sql4.format(','.join(['%s'] * id_num)), id_tuple)
        else:
            print('error count in {0} {1} {2}'.format(catid, shorttitle, version))
conn.commit()
conn.close()     
