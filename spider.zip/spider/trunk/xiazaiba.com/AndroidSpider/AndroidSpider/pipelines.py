# -*- coding: utf-8 -*-
__author__ = 'chenjianbin'
from scrapy.exceptions import DropItem
from AndroidSpider import config
from subprocess import Popen, TimeoutExpired
import requests
import datetime
import pathlib
import pymysql
import time
import re
import oss2
import shlex
import random
import json
import urllib.parse

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html
AccessKeyId = config.OSS.get('AccessKeyId')
AccessKeySecret = config.OSS.get('AccessKeySecret')
ENPOINT = config.OSS.get('ENPOINT')
BUCKET = config.OSS.get('BUCKET')
DIRECTORY = config.OSS.get('DIRECTORY')
DBCONFIG = config.DB


def raise_errors(msg):
    raise DropItem('=====>>>> {0} <<<<====='.format(msg))

class AndroidspiderPipeline(object):
    def process_item(self, item, spider):
        return item

class JudgePipeline(object):
    def process_item(self, item, spider):
        '''用于判断软件是否下载过,如未下载过,则判断分类,如果在数据库内无分类,则使用默认分类'''
        item['catid'] = 20
        catname = item.get('catname', '')
        shorttitle = item.get('shorttitle', '')
        version = item.get('version', '')
        sql1 = 'select id from v9_app where shorttitle = %s and version = %s'
        sql2 = 'select catid from v9_category where catname = %s'
        conn = pymysql.connect(**DBCONFIG)
        with conn.cursor(pymysql.cursors.DictCursor) as cursor:
            cursor.execute(sql1, (shorttitle, version))
            res = cursor.fetchone()
            if res:
                raise_errors('Software has been downloaded')
            else:
                cursor.execute(sql2, (catname))
                res = cursor.fetchall()
        conn.commit()
        conn.close()
        if res:
            for r in res:
                #如果为安卓应用分类id,则采用安卓应用分类id,否则保持默认id,新增电子书分类,catid为160
                if 118 <= r['catid'] <= 133 or r['catid'] == 160:
                    item['catid'] = r['catid']
                    break
        return item

class DownloadPipeline(object):
    '''1. 下载缩略图、软件截图以及APK'''
    def clean_dir(self, dirname):
        '''清理目录'''
        dirs = []
        files = pathlib.Path(dirname).glob('**/*')
        for f in files:
            if f.is_dir():
                dirs.append(f)
            else:
                f.unlink()
        for d in dirs:
            d.rmdir()

    def format_url(self, url):
        '''格式化url'''
        crawl_url = 'http://a.xiazaiba.com'
        if not (url.lower().startswith('http://') or url.lower().startswith('https://')):
            url = crawl_url + url
        return url

#    def gen_oss_objectname
            
    def process_item(self, item, spider):
        '''下载'''
        #parent_dir 前面不能有/,否则无法上传
        parent_dir = DIRECTORY
        our_url = 'http://oss.kr126.com/'
        auth = oss2.Auth(AccessKeyId, AccessKeySecret)
        bucket = oss2.Bucket(auth, ENPOINT, BUCKET)
        shorttitle = item.get('shorttitle', '')
        version = item.get('version', '')
        thumb = item.get('thumb', '')
        images = item.get('images', [])
        bdownload = item.get('bdownload', '')
        if not bdownload:
            raise_errors('bdownload URL Is None !')
        else:
            bdownload = self.format_url(bdownload)
        try:
            pkg = requests.get( bdownload, stream=True, timeout=60 )
            if not 100 <= pkg.status_code <= 399 or pkg.url.find('wy119.com') != -1 or pkg.url.find('samsung.com') != -1: 
                raise_errors('GET {0} Failed !'.format(bdownload))
            suffix = ''.join(pathlib.PurePath(pkg.url.split('?')[0]).suffixes)
            if not suffix == '.apk':
                raise_errors('Package Suffix Unsupported !')
            filename = shorttitle.strip().replace(' ', '_') + '_V' + version + '_kurui' + suffix
            now = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')[0:17]
            objectname = parent_dir + now[0:4] + '/' + now[4:8] + '/' + filename
            bucket.put_object(objectname, pkg)
        except Exception as e:
            raise_errors(e)
        fileurl = our_url + urllib.parse.quote(objectname)
        item['bdownload'] = json.dumps({ '0': { 'fileurl': fileurl, 'filename': filename } })

        if not thumb:
            raise_errors('Thumb URL Is None !')
        else:
            thumb =  self.format_url(thumb)
        suffix = ''.join(pathlib.PurePath(thumb.split('?')[0]).suffixes)
        now = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')[0:17]
        objectname = parent_dir + now[0:4] + '/' + now[4:8] + '/' + now + suffix
        try:
            pkg = requests.get( thumb, stream=True, timeout=60 )
            if not 100 <= pkg.status_code <= 399:
                raise_errors('GET {0} Failed !'.format(thumb))
            bucket.put_object(objectname, pkg)
        except Exception as e:
            raise_errors(e)
        item['thumb'] = our_url + objectname

        if not images:
            return item
        count = 0
        item['imglist'] = {}
        for image in images:
            if not image:
                continue
            timage = self.format_url(image)
            suffix = ''.join(pathlib.PurePath(timage.split('?')[0]).suffixes)
            now = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')[0:17]
            objectname = parent_dir + now[0:4] + '/' + now[4:8] + '/' + now + suffix
            try:
                pkg = requests.get( timage, stream=True, timeout=60 )
                if 100 <= pkg.status_code <= 399:
                    bucket.put_object(objectname, pkg)
            except Exception as e:
                print('{0}'.format(e))
            url = our_url + objectname
            item['imglist'][str(count)] = { 'url': url, 'alt': 'y'+str(count) }
            item['content'] = re.sub(image, url, item['content'])
            count += 1
        item['imglist'] = json.dumps(item.get('imglist', ''))
        return item




class ProcessDataPipeline(object):
    '''1. 处理掉content的div
       2. 出去title的字样 "-绿色下载吧"
       3. 判断keywords是否查出40字节,如果超出,则截取一部分; '''
    def process_item(self, item, spider):
        item['content'] = re.sub(r'(^<div\s*class="d3 mt10"\s*>\s*|</div>$)', '', item.get('content', ''))
        item['title'] = item.get('title', '').rsplit('-',maxsplit=1)[0]
        count = 5
        while count:
            count -= 1
            if len(item['keywords']) > 40:
                item['keywords'] = item.get('keywords', '').rsplit(',',maxsplit=1)[0]
            else:
                break
        return item

class DBPipeline(object):
    '''将抓取并处理后的数据插入数据库'''
    def process_item(self, item, spider):
        catid = item.get('catid')
        status = 1
        typeid = 0
        sql1 = 'insert into v9_app (`catid`, `status`, `typeid`,`title`,`shorttitle`,`size`, `version`, `platform`, `appauth`, `downcount`, `hot`, `keywords`, `description`, `thumb`, `inputtime`, `updatetime`) value (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
        sql2 = 'insert into v9_app_data (`id`, `bdownload`, `content`, `imglist`) value (%s,%s,%s,%s)'
        sql3 = 'insert into v9_hits (`hitsid`, `catid`, `views`) value (%s,%s,%s)'
        sql4 = 'update v9_app set `url`=%s where `id`=%s'
        itime = int(time.time())
        conn = pymysql.connect(**DBCONFIG)
        with conn.cursor() as cursor:
             cursor.execute(sql1, (catid, status, typeid, item.get('title', ''), item.get('shorttitle', ''), item.get('size', ''), item.get('version', ''), item.get('platform', 1), item.get('appauth', ''),
                           int(item.get('downcount', 0)), item.get('hot', 'number3'), item.get('keywords', ''), item.get('description', ''), item.get('thumb', ''), itime, itime))
             iid = int(cursor.lastrowid)
             cursor.execute(sql2, (iid, item.get('bdownload', ''), item.get('content', ''), item.get('imglist', '')))
             hitsid = 'c-12-' + str(iid)
             cursor.execute(sql3, (hitsid, catid, int(item.get('downcount', 0))))
             cursor.execute(sql4, ('http://www.kr126.com/soft/{0}.html'.format(iid), iid))
        conn.commit()
        conn.close()
        return item

