# -*- coding: utf-8 -*-
__author__ = 'chenjianbin'

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class AndroidspiderItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    pass

class AndroidItem(scrapy.Item):
    catid = scrapy.Field()
    title = scrapy.Field()
    shorttitle = scrapy.Field()
    version = scrapy.Field()
    size = scrapy.Field()
    platform = scrapy.Field()
    appauth = scrapy.Field()
    downcount = scrapy.Field()
    hot = scrapy.Field()
    keywords = scrapy.Field()
    description = scrapy.Field()
    thumb = scrapy.Field()
    bdownload = scrapy.Field()
    content = scrapy.Field()
    images = scrapy.Field()
    imglist = scrapy.Field()
    status = scrapy.Field()
    catname = scrapy.Field()
