# -*- coding: utf-8 -*-
__author__ = 'chenjianbin'
import scrapy
#from scrapy.spiders import CrawlSpider
from PCSpider.items import PCItem
from scrapy.exceptions import CloseSpider
import datetime
import pymysql
import time


HOST = '127.0.0.1'
#HOST = '120.26.234.213'
USER = 'remote'
PASSWORD = 'jfC8Uj9u6eQKoD3S'
DB = 'kr126'
PORT = 3306
CHARSET = 'utf8'
CLASSDICT = {}

class PCSpider(scrapy.Spider):
    name = "pc"
    allowed_domains = ["xiazaiba.com"]
    start_urls = ['http://www.xiazaiba.com/downlist/187.html']

    def parse(self, response):
        '''获取分类地址'''
        urls = response.xpath('//div/ul[@class="cats-list clearfix"]/li/a/@href').extract()
        for url in urls:
            yield scrapy.Request(url, callback=self.parse_class)

    def parse_class(self, response):
        '''获取更深一层分类地址'''
        cats = response.xpath('//div/ul[@class="cats-list clearfix"]/li/a/text()').extract()
        urls = response.xpath('//div/ul[@class="cats-list clearfix"]/li/a/@href').extract()
        cattuple = zip(cats, urls)
        for cat, url in cattuple:
            CLASSDICT[url] = cat
            yield scrapy.Request(url, callback=self.parse_soft, priority=1)

    def parse_a(self, response):
        try:
            next_page = response.xpath('//div[@class="page-num"]/a[@class="nextprev"]/@href').extract()[0]
        except Exception:
            next_page = ''
        if next_page:
            yield scrapy.Request(next_page, callback=self.parse_a, priority=2)
            yield scrapy.Request(next_page, callback=self.parse_soft, priority=2)

    def parse_soft(self, response):
        '''获取软件基本信息,并判断是否抓取过,如果抓取过则退出,否则yield到下一层'''
        softs = response.xpath('//div[@class="lay-740 fl"]/ul[@class="cur-cat-list"]/li')
        for soft in softs:
            item = PCItem()
            item['catname'] = CLASSDICT.get(response.url)
            try:
                item['size'] = soft.xpath('./dl/dd[@class="soft-ext"]/span/text()').re(r'大小.\s*(.*)')[0].strip()
                item['downcount'] = soft.xpath('./dl/dd[@class="soft-ext"]/span/text()').re(r'下载.\s*(\d+).*')[0]
                item['bdownload'] = soft.xpath('./a[@class="btn-dl"]/@href').extract()[0]
                item['thumb'] = soft.xpath('./a/img/@src').extract()[0]
                item['shorttitle'], item['version'] = soft.xpath('./dl/dt/a/text()').extract()[0].rsplit(' ', maxsplit = 1)
                item['ldate'] = soft.xpath('./dl/dd[@class="soft-ext"]/span/text()').re(r'.*?(\d{4})-(\d{2})-(\d{2}).*')
            except:
                print('some errors in {0}'.format(response.url))
            yield item
