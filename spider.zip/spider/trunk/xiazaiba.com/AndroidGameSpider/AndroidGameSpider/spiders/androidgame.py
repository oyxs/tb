# -*- coding: utf-8 -*-
__author__ = 'chenjianbin'
import scrapy
#from scrapy.spiders import CrawlSpider
from AndroidGameSpider.items import AndroidGameItem
from scrapy.exceptions import CloseSpider
import datetime
import pymysql
import time

URLDICT = {}


class AndroidGameSpider(scrapy.Spider):
    name = "androidgame"
    allowed_domains = ["a.xiazaiba.com"]
    start_urls = ['http://a.xiazaiba.com/youxi/']

    def parse(self, response):
        item = AndroidGameItem()
        '''获取APK信息,然后判断是否有下一页,如果有回调自己继续搜索下一页'''
        apps = response.xpath('//div/ul[@class="down-list"]/li')
        for app in apps:
            itemdict = {}
            try:
                itemdict['shorttitle'] = app.xpath('./div[@class="dlr fr"]/a/text()').extract()[0].strip()
                itemdict['size'] = app.xpath('./div/div[@class="d4 mt10"]/text()').re(r'大小:(.*)版本:.*')[0].strip()
                itemdict['version'] = app.xpath('./div/div[@class="d4 mt10"]/text()').re(r'大小:.*版本:(.*)')[0].strip()
                itemdict['thumb'] = app.xpath('.//img/@src').extract()[0]
#                itemdict['bdownload'] = app.xpath('.//div[@class="mt10"]/a/@href').extract()[0]
                itemdict['content'] = app.xpath('.//div[@class="d3 mt10"]').extract()[0]
                url = app.xpath('./div[@class="dlr fr"]/a/@href').extract()[0]
                URLDICT[url] = itemdict
                yield scrapy.Request(url, callback=self.parse_content, priority=1)
            except Exception as e:
                print('{0} in {1}'.format(e, response.url))
        next_page = response.xpath('//div[@class="ylmf-page"]/a[contains(text(), "下一页")]/@href').extract()[0]
        if next_page:
            yield scrapy.Request(next_page, callback=self.parse)


    def parse_content(self, response):
        '''判断最新软件更新是否抓取过,如果抓取过结束爬虫,如果没抓取过,抓取相应软件更新,交给管道进一步处理'''
        item = AndroidGameItem()
        item['platform'] = '1'
        item['hot'] = 'number3'
        item['appauth'] = '免费版'
        try:
            item['title'] = response.xpath('//html/head/title/text()').extract()[0]
            item['keywords'] = response.xpath('/html/head/meta[@name="Keywords"]/@content').extract()[0]
            item['description'] = response.xpath('/html/head/meta[@name="Description"]/@content').extract()[0]
            item['downcount'] = response.xpath('//div/ul[@class="gc-2-con clearfix mt10"]/li[3]/text()').re(r'.*?(\d+).*')[0].strip()
            item['catname'] = response.xpath('//div/ul[@class="gc-2-con clearfix mt10"]/li[5]/text()').re(r'分类.\s*(.*)')[0].strip()
            item['images'] = response.xpath('//div[@class="app-pics"]//img/@src').extract()
            item['bdownload'] = response.xpath('//div/ul[@class="gc-2-btn mt10"]/li/a/@href').extract()[0]
        except:
            print('{0} in {1}'.format(e, response.url))
        itemdict = URLDICT[response.url]
        for k, v in itemdict.items():
            item[k] = v

        '''只抓取今天的软件包'''
        ldate = response.xpath('//ul[@class="gc-2-con clearfix mt10"]/li').re(r'.*?(\d{4})-(\d{2})-(\d{2}).*')
        date_num = datetime.timedelta(days=2)
        if datetime.date.today() - date_num < datetime.date(int(ldate[0]), int(ldate[1]), int(ldate[2]) ):
            return item
        else:
            raise CloseSpider('软件抓取完毕！')

