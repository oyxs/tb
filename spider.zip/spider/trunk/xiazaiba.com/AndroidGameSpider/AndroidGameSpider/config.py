#!/usr/bin/env python
DB = {
      'host': '127.0.0.1',
      #'HOST': '120.26.234.213',
      'user': 'remote',
      'password': 'jfC8Uj9u6eQKoD3S',
      'db': 'kr126',
      'port': 3306,
      'charset': 'utf8',
     }

OSS = {
       'AccessKeyId': 'LTAImuMNiS1jtmHy',
       'AccessKeySecret': 'NLImG3mBwBTOC2gzNLITBv9zjIf2Kr',
       'ENPOINT': 'oss-cn-hangzhou-internal.aliyuncs.com',
       #'ENPOINT': 'oss-cn-hangzhou.aliyuncs.com',
       'BUCKET': 'oss-kr126-com',
       'DIRECTORY': 'www/uploadfile/'
      }
