__author__ = 'chenjianbin'
from scrapy import Request
#from scrapy.spiders import Spider, Rule
#from scrapy.selector import Selector
from scrapy.spiders import CrawlSpider
#from scrapy.linkextractors import LinkExtractor
from ZixunSpider.items import ZixunItem
from scrapy.exceptions import CloseSpider
import datetime
import time
import pymysql
import re

HOST = '127.0.0.1'
USER = 'remote'
PASSWORD = 'jfC8Uj9u6eQKoD3S'
DB = 'kr126'
PORT = 3306
CHARSET = 'utf8'
CATIDDICT = {}

class zixunspider(CrawlSpider):
    name = 'zixun'
    allowed_domains = ['xiazaiba.com']
    
    start_urls = [
        'http://www.xiazaiba.com/gonglue/list_282.html',
        'http://www.xiazaiba.com/gonglue/list_208.html',
        'http://www.xiazaiba.com/gonglue/list_209.html',
        #'http://www.xiazaiba.com/news/',  #设置开始爬取页面
    ]

    #rules = (
    #    Rule(LinkExtractor(allow=('news/index_\d+.html', ),),callback='parse_item',follow=True),
    #)

    def parse(self, response):
        '''将所有内页交给parse_content处理,然后判断是否有下一页,如果有回调自己继续搜索下一页'''
        url1 = re.compile(r'http://www.xiazaiba.com/gonglue/list_282')
        url2 = re.compile(r'http://www.xiazaiba.com/gonglue/list_208')
        url3 = re.compile(r'http://www.xiazaiba.com/gonglue/list_209')
        url4 = re.compile(r'http://www.xiazaiba.com/news/')
        if url1.match(response.url):
            catid = 114
        elif url2.match(response.url):
            catid = 115
        elif url3.match(response.url):
            catid = 116
        elif url4.match(response.url):
            catid = 110
        else:
            catid = 11111111
        urls = response.xpath('//li/div[@class="title"]/a/@href').extract()
        for url in urls:
            CATIDDICT[url] = catid
            yield Request(url, callback=self.parse_content)
        next_page = response.xpath('//div[@class="ylmf-page"]/a[contains(./text(), "下一页")]/@href').extract()[0]
        if next_page:
            yield Request(next_page, callback=self.parse)

        
    def parse_content(self, response):
        '''判断最新资讯是否抓取过,如果抓取过结束爬虫,如果没抓取过,抓取相应资讯,交给管道进一步处理'''
        item = ZixunItem()
        item['status'] = 0
        item['catid'] = CATIDDICT.pop(response.url)
        if item.get('catid') == 11111111:
            item['status'] = 1
            return item
        try:
            contentdiv = response.xpath('//div[contains(@class, "tmd-content")]')
            copyinfo = response.xpath('//div[@class="art-top-ext ext"]/span/text()')
            ldate = copyinfo.re(r'时间.\s*(\d{4})-(\d{2})-(\d{2})\s*(\d{2}):(\d{2}):?(\d{2})?')
            item['title'] = response.xpath('/html/head/title/text()').extract()[0].rsplit('-',maxsplit=1)[0]
            item['keywords'] = response.xpath('/html/head/meta[@name="Keywords"]/@content').extract()[0]
            item['description'] = response.xpath('/html/head/meta[@name="Description"]/@content').extract()[0]
            item['views'] = response.xpath('//div[@class="art-top-ext ext"]/span[@id="ihits"]').re(r'.*?(\d+).*')[0]
            item['username'] = copyinfo.re(r'编辑.\s*(.*)')[0]
            item['copyfrom'] = copyinfo.re(r'来源.\s*(.*)')[0]
            item['content'] = contentdiv.extract()[0]
            item['images'] = contentdiv.xpath('.//img/@src').extract()
            #item['hashtitle'] = base64.b64encode(hashlib.md5(item.get('title').encode('utf8')).digest())
        except:
            print('some errors in {0}'.format(response.url))
        #if datetime.date(2016,1,1) < datetime.date(int(ldate[0]), int(ldate[1]), int(ldate[2])) <= datetime.date.today():
        if datetime.date(int(ldate[0]), int(ldate[1]), int(ldate[2])) <= datetime.date.today():
            sql = 'select %s from v9_news where title = %s'
            conn = pymysql.connect(host=HOST, user=USER, password=PASSWORD, db=DB, port=PORT, charset=CHARSET)
            with conn.cursor() as cursor:
                cursor.execute(sql, ('id', item.get('title') ))
                if cursor.fetchone():
                    item['status'] = 1
            conn.commit()
            conn.close()
            return item
        else:
            raise CloseSpider('资讯抓取完毕！')

        
