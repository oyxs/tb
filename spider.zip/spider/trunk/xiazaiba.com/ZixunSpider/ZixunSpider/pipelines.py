# -*- coding: utf-8 -*-
__author__ = 'chenjianbin'
import requests
import datetime
import pathlib
import pymysql
import time
import re
import oss2

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html
HOST = '127.0.0.1'
USER = 'remote'
PASSWORD = 'jfC8Uj9u6eQKoD3S'
DB = 'kr126'
PORT = 3306
CHARSET = 'utf8'
AccessKeyId = 'LTAImuMNiS1jtmHy'
AccessKeySecret = 'NLImG3mBwBTOC2gzNLITBv9zjIf2Kr'
#ENPOINT = 'oss-cn-hangzhou.aliyuncs.com'
ENPOINT = 'oss-cn-hangzhou-internal.aliyuncs.com'
BUCKET = 'oss-kr126-com'

class ZixunSpiderPipeline(object):
    def process_item(self, item, spider):
        return item

class ImagePipeline(object):
    '''1. 下载图片,存至对应的日期目录,并修改content内的img src'''
    def process_item(self, item, spider):
        if item.get('status', 1):
            return item
        if item.get('images', ''):
            prefix = 'http://www.xiazaiba.com/news/'
            count = 0
            auth = oss2.Auth(AccessKeyId, AccessKeySecret)
            bucket = oss2.Bucket(auth, ENPOINT, BUCKET)
            for image in item.get('images'):
                image = image.split('?')[0].split('-')[0].split('!')[0]
                imageurl = prefix + image
                suffix = pathlib.PurePath(image).suffix
                if not suffix:
                    item['status'] = 1
                    return item
                now = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')[0:17]
                objectname = 'www/uploadfile/' + now[0:4] + '/' + now[4:8] + '/' + now + suffix
                try:
                    image_data = requests.get(imageurl, stream=True, timeout=60)
                    bucket.put_object(objectname, image_data)
                except:
                    item['status'] = 1
                newimageurl = 'http://oss.kr126.com/' +  objectname
                item['content'] = re.sub(image, newimageurl, item.get('content'))
                if count == 0:
                    item['thumb'] = newimageurl
                count += 1 
        else:
            item['status'] = 1
        return item

class ProcessDataPipeline(object):
    '''1. 除去content的div标签
       2. 判断keywords是否查出40字节,如果超出,则截取一部分; '''
    def process_item(self, item, spider):
        if item.get('status', 1):
            return item
        item['content'] = re.sub(r'(^<div.*?>\s*|</div>$)', '', item.get('content')) 
        count = 5
        while count:
            count -= 1
            if len(item.get('keywords')) > 40:
                item['keywords'] = item.get('keywords').rsplit(',',maxsplit=1)[0]
            else:
                break
        return item
            
class DBPipeline(object):
    '''将抓取并处理后的数据插入数据库'''
    def process_item(self, item, spider):
        if item.get('status', 1):
            return item
        sql1 = 'insert into v9_news (`catid`,`title`,`keywords`,`updatetime`,`thumb`,`inputtime`,`username`,`description`) value (%s,%s,%s,%s,%s,%s,%s,%s)'
        sql2 = 'insert into v9_news_data (`id`,`copyfrom`,`content`) value (%s,%s,%s)'
        sql3 = 'insert into v9_hits (`hitsid`,`catid`,`views`) value (%s,%s,%s)'
        itime = int(time.time())
        catid = item.get('catid')
        conn = pymysql.connect(host=HOST, user=USER, password=PASSWORD, db=DB, port=PORT, charset=CHARSET)
        with conn.cursor() as cursor:
            cursor.execute(sql1, (catid, item.get('title'), item.get('keywords'), itime, item.get('thumb'), itime, item.get('username'), item.get('description')))
            iid = int(cursor.lastrowid)
            hitsid = 'c-1-' + str(iid)
            cursor.execute(sql2, (iid, item.get('copyfrom'), item.get('content')))
            print(item.get('content'))
            cursor.execute(sql3, (hitsid, catid, item.get('views')))
        conn.commit()
        conn.close()
        return item
        

