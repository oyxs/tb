#!/usr/bin/env python
import pymysql

DBCONFIG = { 'host': '127.0.0.1',
             'port': 3306,
             'user': 'remote',
             'password': 'jfC8Uj9u6eQKoD3S',
             'db': 'kr126',
             'charset': 'utf8' }
sql1 = 'select id,title from v9_app limit %s,1000'
sql2 = 'update v9_app set title=%s  where id=%s'
LIMIT = 0
while True:
    conn = pymysql.connect(**DBCONFIG)
    with conn.cursor() as cursor:
        cursor.execute(sql1, (LIMIT))
        res = cursor.fetchall()
        if not res:
            print(res)
            break
        for tid, title in res:
            print(tid, title)
            cursor.execute(sql2, (title.rstrip('_'), tid))
    conn.commit()
    conn.close()     
    LIMIT += 1000
