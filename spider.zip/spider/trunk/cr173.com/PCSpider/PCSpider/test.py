#!/usr/bin/env python
import zipfile
import pathlib
import sys
import re
import config
import os

#PDIR = '{}/package'.format(pathlib.PurePath(sys.path[0]))
PDIR = pathlib.PurePath('.')
TDIR = str(PDIR.joinpath('temp'))
print(TDIR)
FILENAME = 'test.zip'
os.chdir(PDIR)

#with zipfile.ZipFile('{}/{}'.format(PDIR, FILENAME)) as zf:
#    files = zf.infolist()
#    uzfiles = ( f.filename for f in files if not re.match(r'西西软件园', f.filename.encode('cp437').decode('gbk')) )
#    zf.extractall(TDIR, uzfiles)
    
#pathlib.Path('{}/{}'.format(PDIR, FILENAME)).unlink()

with zipfile.ZipFile('{}/{}'.format(PDIR, 'aa.zip'), mode='w', zipfile.ZIP_DEFLATED) as zf:
    d = pathlib.Path(TDIR)
    zfiles = d.glob('*/**')
    #print(list(d.glob('*/**')))
    [ zf.write(pathlib.Path(z).name) for z in zfiles if pathlib.Path(z).is_file() ]
    #    print(pathlib.Path(z).name)
    #    zf.write(pathlib.Path(z).name)
    zf.close()
