# -*- coding: utf-8 -*-
__author__ = 'chenjianbin'
import scrapy
from scrapy.spiders import CrawlSpider
from PCSpider.items import PCItem
from scrapy.exceptions import CloseSpider
import datetime
import re

ITEMDICT = {}

class PcSpider(scrapy.Spider):
    name = 'pc'
    allowed_domains = ['cr173.com']
    start_urls = [
        'http://www.cr173.com/list/s_2_1.html',
        'http://www.cr173.com/list/s_6_1.html',
        'http://www.cr173.com/list/s_78_1.html',
        'http://www.cr173.com/list/s_107_1.html',
        'http://www.cr173.com/list/s_120_1.html',
        'http://www.cr173.com/list/s_126_1.html',
        'http://www.cr173.com/list/s_12_1.html',
        'http://www.cr173.com/list/s_111_1.html',
        'http://www.cr173.com/list/s_17_1.html',
        'http://www.cr173.com/list/s_19_1.html',
        'http://www.cr173.com/list/s_24_1.html',
        'http://www.cr173.com/list/s_117_1.html',
        'http://www.cr173.com/list/s_121_1.html',
        'http://www.cr173.com/list/s_128_1.html',
        'http://www.cr173.com/list/s_137_1.html',
        'http://www.cr173.com/list/s_50_1.html',
        'http://www.cr173.com/list/s_52_1.html',
        'http://www.cr173.com/list/s_56_1.html',
        'http://www.cr173.com/list/s_57_1.html',
        'http://www.cr173.com/list/s_59_1.html',
        'http://www.cr173.com/list/s_89_1.html',
        'http://www.cr173.com/list/s_93_1.html',
        'http://www.cr173.com/list/s_96_1.html',
        'http://www.cr173.com/list/s_102_1.html',
        'http://www.cr173.com/list/s_104_1.html',
        'http://www.cr173.com/list/s_140_1.html',
        'http://www.cr173.com/list/s_155_1.html',
        'http://www.cr173.com/list/s_68_1.html',
        'http://www.cr173.com/list/s_69_1.html',
        'http://www.cr173.com/list/s_73_1.html',
        'http://www.cr173.com/list/s_72_1.html',
        'http://www.cr173.com/list/s_74_1.html',
        'http://www.cr173.com/list/s_87_1.html',
        'http://www.cr173.com/list/s_123_1.html',
        'http://www.cr173.com/list/s_129_1.html',
        'http://www.cr173.com/list/s_36_1.html',
        'http://www.cr173.com/list/s_35_1.html',
        'http://www.cr173.com/list/s_3_1.html',
        'http://www.cr173.com/list/s_110_1.html',
        'http://www.cr173.com/list/s_9_1.html',
        'http://www.cr173.com/list/s_112_1.html',
        'http://www.cr173.com/list/s_26_1.html',
        'http://www.cr173.com/list/s_117_1.html',
        'http://www.cr173.com/list/s_67_1.html',
        'http://www.cr173.com/list/s_70_1.html',
        'http://www.cr173.com/list/s_107_1.html',
        'http://www.cr173.com/list/s_77_1.html',
    ]

    def parse(self, response):
        '''获取分类地址'''
        catname = response.xpath('//div[@id="list_wrap"]/div[@class="list_main"]/div[@class="mod"]/h2[@class="hd"]/span/text()').extract()[0].replace(' ', '')
        softs = response.xpath('//div[@id="list_wrap"]/div[@class="list_main"]/div[@class="mod"]/div[@id="list_content"]/div[@class="item"]')
        r = re.compile(r'\s[vV]?([0-9\.]+)')
        for soft in softs:
            itemdict = {}
            itemdict['catname'] = catname
            try:
                url = 'http://www.cr173.com' + soft.xpath('./div[@class="ico"]/a/@href').extract()[0]
                itemdict['size'] = soft.xpath('./ul/li[1]/span/text()').extract()[0]
                itemdict['ldate'] = soft.xpath('./ul/li[@class="update"]/span/text()').re(r'(\d{4})-(\d{2})-(\d{2})')
                itemdict['thumb'] = soft.xpath('./div[@class="ico"]/a/img/@src').extract()[0]
                softinfo = soft.xpath('./div[@class="des"]/h3/a/text()').extract()[0]
                version = r.search(softinfo)
                itemdict['version'] = version.group(1) if version else ''
                itemdict['shorttitle'] = r.split(softinfo)[0].strip()
            except Exception as e:
                print('{0}: {1}'.format(response.url, e))
            ITEMDICT[url] = itemdict
            yield scrapy.Request(url, callback=self.parse_content, priority=1)
        try:
            next_page = 'http://www.cr173.com' + response.xpath('//div[@class="pg_pcl"]/div[@class="tspage"]/div[@class="tsp_nav"]/a[@class="tsp_next"]/@href').extract()[0]
        except Exception:
            next_page = ''
        if next_page:
            yield scrapy.Request(next_page, callback=self.parse)
                    

    def parse_content(self, response):
        '''抓取相应软件内容信息,交给管道进一步处理'''
        item = PCItem()
        itemdict = ITEMDICT.pop(response.url)
        for k, v in itemdict.items():
            item[k] = v
        item['platform'] = '4'
        item['hot'] = 'number3'
        item['appauth'] = '免费版'
        try:
            item['title'] = response.xpath('//html/head/title/text()').extract()[0][0:-6]
            item['keywords'] = response.xpath('/html/head/meta[@name="keywords"]/@content').extract()[0]
            item['description'] = response.xpath('/html/head/meta[@name="description"]/@content').extract()[0][0:-11]
            item['content'] = ''.join(response.xpath('//div[@id="content"]/h3|//div[@id="content"]/p').extract())
            item['images'] = response.xpath('//div[@id="content"]/p/img/@src').extract()
            tags = response.xpath('//div[@id="content"]/p//a').extract()
            tags_text = response.xpath('//div[@id="content"]/p//a/text()').extract()
            item['tags'] = zip(tags, tags_text)
            item['bdownload'] = response.xpath('//div[@class="c_soft_info m-soft-introd"]/div[@class="maindown_w4"]/a[1]/@href').extract()[0]
            return item
        except Exception as e:
            print('{0}: {1}'.format(response.url, e))



