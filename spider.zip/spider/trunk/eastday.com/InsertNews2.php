<?php
//修改最大执行时间[秒数]
ini_set('max_execution_time', '300');
//修改此次最大运行内存
ini_set('memory_limit','64M');

class InsertNews{

    public static function connectDb(){
        $serverName = "127.0.0.1";
        $username = "news_66note";
        $password = "PRDEw0cM1IsVBWX6";
        $dbName = "news_66note";
        $db = new mysqli($serverName, $username, $password, $dbName);
        return $db;
    }

    public static function getApiData($url){
        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch,CURLOPT_HEADER,0);
        curl_setopt($ch, CURLOPT_TIMEOUT,60);
        $output = curl_exec($ch);
        if($output === FALSE ){
            return false;
        }
        curl_close($ch);
        $str = substr($output, 5,-1);
        $arrayData = json_decode($str,true);

        return $arrayData;
    }

    public static function getStartKey($catid){
        $startKeySql = "SELECT rowkey,inputtime FROM v9_news_list WHERE catid = $catid ORDER BY inputtime DESC LIMIT 1";//inputtime ASC
        $result = InsertNews::connectDb()->query($startKeySql)->fetch_all();
        if ($result){
            $startkey = $result[0][0];
            return $startkey;
        }else{
            return false;
        }
    }

    public static function getLastTime($catid){
        $startKeySql = "SELECT inputtime FROM v9_news_list WHERE catid = $catid ORDER BY inputtime DESC LIMIT 1";//inputtime ASC
        $result = InsertNews::connectDb()->query($startKeySql)->fetch_all();
        if ($result){
            $inputtime = $result[0][0];
            return $inputtime;
        }else{
            return 0;
        }
    }

    public static function addNews($types){
        $CATE = [
        '国内'=>['0010','7'],
        '国际'=>['0011','8'],
        '图片'=>['','9'],
        '社会'=>['0003','10'],
        '娱乐'=>['0002','11'],
        '科技'=>['0008','12'],
        '财经'=>['0004','13'],
        '时尚'=>['0015','14'],
//        '体育'=>['0006','15'],
        'NBA'=>['5009','24','15'],
        'CBA'=>['5010','25','15'],
        '英超'=>['5016','26','15'],
        '西甲'=>['5015','27','15'],
        '意甲'=>['5012','28','15'],
        '德甲'=>['5011','29','15'],
        '中超'=>['5014','30','15'],
        '网球'=>['5013','31','15'],
        '羽毛球'=>['5021','32','15'],
        '高尔夫'=>['5019','33','15'],
        '排球'=>['5020','34','15'],
        '棋牌'=>['5017','36','15'],

        '汽车'=>['0012','16'],
        '军事'=>['0005','37'],
        '搞笑'=>['0017','19'],
        '星座'=>['0020','17'],
        '游戏'=>['0007','18']
        ];

        $return = array();
        $type[0] = $CATE[$types][0];
        $type[1] = $CATE[$types][1];
        //$startkey = InsertNews::getStartKey($type[1]);
        $lastTime = InsertNews::getLastTime($type[1]);
        $catid = $type[1];//分类ID
        $num = 20;//最多20条

//        echo $lastTime;

        //获得接口数据 refresh
        if ($types == '图片'){
            $refreshUrl = 'http://picpcapi.dftoutiao.com/EastdayminisitepicView/pcrefreshall';
        }else{
            $refreshUrl = 'http://ttpc.dftoutiao.com/jsonpc/refresh?type='.$type[0];
        }

        //获取头20条数据
        $refreshArrayData = InsertNews::getApiData($refreshUrl);

        //链接数据库
        $db = InsertNews::connectDb();

        //循序插入sql insert语句
        $last_key = '';

        if ($types != '图片'){
            foreach ($refreshArrayData['data'] as $key => $value){
                if (strstr($value['brief'],"'")){
                    $value['brief'] = str_replace("'","“",$value['brief']);
                }
                if (strstr($value['topic'],"'")){
                    $value['topic'] = str_replace("'","“",$value['topic']);
                }
                if (strtotime($value['date']) > $lastTime){
                     $insert_sql = "INSERT INTO v9_news_list (
                         catid,
                         rowkey,
                         title,
                         url,
                         description,
                         status,
                         inputtime
                     ) VALUES (
                         $catid,
                         '".$value['rowkey']."',
                         '".$value['topic']."',
                         'https://mini.eastday.com/a/".$value['url']."',
                         '".$value['brief']."',
                         0,
                         ".strtotime($value['date'])."
                     );";

                     //插入数据库
                     $db->query($insert_sql);

                    if($key == count($refreshArrayData['data']) - 1){
                        $last_key = $value['rowkey'];
                    }
                    $return['status'] = 1;
                }else{
                    $return['status'] = 1;
                    return $return;
                }
            }
        }else{
            foreach ($refreshArrayData['data'] as $key => $value){
                if (strstr($value['title'],"'")){
                    $value['title'] = str_replace("'","“",$value['title']);
                }
                if (strtotime($value['vdt']) > $lastTime){
                     $insert_sql = "INSERT INTO v9_news_list (catid, rowkey, title, url, description, status, inputtime
                         ) VALUES (
                             $catid, '".$value['rowkey']."', '".$value['title']."', 'https://miniimg.eastday.com/detail/".$value['htmlname']."',
                             '".$value['title']."', 0, ".strtotime($value['vdt'])."
                         );";

                     //插入数据库
                     $db->query($insert_sql);
                    if($key == count($refreshArrayData['data']) - 1){
                        $last_key = $value['rowkey'];
                    }
                    $return['status'] = 1;
                }else{
                    $return['status'] = 1;
                    return $return;
                }
            }

        }

        $refreshStartKey = $last_key;

        for ($i=0; $i < 5; $i++) {
            if ($types == '图片'){
                $nextUrl = 'http://picpcapi.dftoutiao.com/EastdayminisitepicView/pcnextall?num='.$num.'&startkey='.$refreshStartKey;
            }else{
                $nextUrl = 'http://ttpc.dftoutiao.com/jsonpc/next?type='.$type[0].'&startkey='.$refreshStartKey.'&newsnum='.$num;
            }
            //获取接下去20条数据
            $nextArrayData = InsertNews::getApiData($nextUrl);

            if ($types != '图片'){
                foreach ($nextArrayData['data'] as $key => $value){
                    if (strstr($value['brief'],"'")){
                        $value['brief'] = str_replace("'","“",$value['brief']);
                    }
                    if (strstr($value['topic'],"'")){
                        $value['topic'] = str_replace("'","“",$value['topic']);
                    }
                    if (strtotime($value['date']) > $lastTime){
                         $insert_sql = "INSERT INTO v9_news_list (
                             catid,
                             rowkey,
                             title,
                             url,
                             description,
                             status,
                             inputtime
                         ) VALUES (
                             $catid,
                             '".$value['rowkey']."',
                             '".$value['topic']."',
                             'https://mini.eastday.com/a/".$value['url']."',
                             '".$value['brief']."',
                             0,
                             ".strtotime($value['date'])."
                         );";

                         //插入数据库
                         $db->query($insert_sql);

                        if($key == count($nextArrayData['data']) - 1){
                            $last_key = $value['rowkey'];
                        }
                        $return['status'] = 1;
                    }else{
                        $return['status'] = 1;
                        return $return;
                    }
                }
            }else{
                foreach ($nextArrayData['data'] as $key => $value){
                    if (strstr($value['title'],"'")){
                        $value['title'] = str_replace("'","“",$value['title']);
                    }
                    if (strtotime($value['vdt']) > $lastTime){
                         $insert_sql = "INSERT INTO v9_news_list (catid, rowkey, title, url, description, status, inputtime
                             ) VALUES (
                                 $catid, '".$value['rowkey']."', '".$value['title']."', 'https://miniimg.eastday.com/detail/".$value['htmlname']."',
                                 '".$value['title']."', 0, ".strtotime($value['vdt'])."
                             );";

                         //插入数据库
                         $db->query($insert_sql);

                        if($key == count($nextArrayData['data']) - 1){
                            $last_key = $value['rowkey'];
                        }
                        $return['status'] = 1;
                    }else{
                        $return['status'] = 1;
                        return $return;
                    }
                }

            }

            $refreshStartKey = $last_key;
        }
        $return['status'] = 1;
        return $return;
    }

    public static function getInsertNewsStatus($type){
        $result = InsertNews::addNews($type);
        if ($result['status']){
            echo 'status:【'.$type.'】新闻新增<span style="color:green;">成功</span><br>';
        }else{
            echo 'status:【'.$type.'】新闻新增<span style="color:red;">失败</span><br>';
        }
    }

}

//$arr=['国内','国际','图片','社会','娱乐','科技','财经','时尚',
//    'NBA','CBA','英超','西甲','意甲','德甲','中超','网球','羽毛球','高尔夫','排球','棋牌',
//    '汽车','星座','游戏'];
//foreach($arr as $key => $value){
//    InsertNews::getInsertNewsStatus($value);
//}

//for ($i=1;$i<=19;$i++){
//    InsertNews::getInsertNewsStatus('高尔夫');
//}


InsertNews::getInsertNewsStatus('国内');
InsertNews::getInsertNewsStatus('国际');
// InsertNews::getInsertNewsStatus('图片');
InsertNews::getInsertNewsStatus('社会');
InsertNews::getInsertNewsStatus('娱乐');
InsertNews::getInsertNewsStatus('科技');
InsertNews::getInsertNewsStatus('财经');
InsertNews::getInsertNewsStatus('时尚');

InsertNews::getInsertNewsStatus('NBA');
InsertNews::getInsertNewsStatus('CBA');
InsertNews::getInsertNewsStatus('英超');
InsertNews::getInsertNewsStatus('西甲');
InsertNews::getInsertNewsStatus('意甲');
InsertNews::getInsertNewsStatus('德甲');
InsertNews::getInsertNewsStatus('中超');
InsertNews::getInsertNewsStatus('网球');
InsertNews::getInsertNewsStatus('羽毛球');
InsertNews::getInsertNewsStatus('高尔夫');
InsertNews::getInsertNewsStatus('排球');
InsertNews::getInsertNewsStatus('棋牌');

InsertNews::getInsertNewsStatus('汽车');
InsertNews::getInsertNewsStatus('星座');
InsertNews::getInsertNewsStatus('游戏');
InsertNews::getInsertNewsStatus('军事');
InsertNews::getInsertNewsStatus('搞笑');







?>
