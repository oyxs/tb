# -*- coding: utf-8 -*-
__author__ = 'chenjianbin'
import requests
import datetime
import pathlib
import pymysql
import time
import re
import json
import oss2

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html
# HOST = '114.215.243.11'
# USER = 'xiexiakai'
# PASSWORD = '9XGYWzq+yHJRGe2U'
HOST = '127.0.0.1'
USER = 'news_66note'
PASSWORD = 'PRDEw0cM1IsVBWX6'
DB = 'news_66note'
PORT = 3306
CHARSET = 'utf8'
AccessKeyId = 'LTAI5qu9YnQzIK2I'
AccessKeySecret = 'kINow8mDTgCOb0uhi747gTdEy76fYC'
#ENPOINT = 'oss-cn-hangzhou.aliyuncs.com'
ENPOINT = 'oss-cn-hangzhou-internal.aliyuncs.com'
BUCKET = 'oss-66note-cn'

class ZixunSpiderPipeline(object):
    def process_item(self, item, spider):
        return item

class ImagePipeline(object):
    '''1. 下载图片,存至oss对应的日期目录,并修改content内的img src'''
    def process_item(self, item, spider):
        print('图片处理')
        if item.get('images', ''):
            auth = oss2.Auth(AccessKeyId, AccessKeySecret)
            bucket = oss2.Bucket(auth, ENPOINT, BUCKET)
            if item['status'] == 3:  #图集
                prefix = 'http:'
                count = 0
                imglist = {}
                for image in item.get('images'):
                    image = image.split('?')[0].split('-')[0].split('!')[0]
                    imageurl = prefix + image
                    suffix = pathlib.PurePath(image).suffix
                    if not suffix:
                        return item
                    now = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')[0:17]
                    objectname = 'www/uploadfile/' + now[0:4] + '/' + now[4:8] + '/' + now + suffix
                    try:
                        image_data = requests.get(imageurl, stream=True, timeout=60)
                        bucket.put_object(objectname, image_data)
                    except:
                        print('put_object error')

                    newimageurl = 'http://oss.66note.cn/' +  objectname
                    img_data = {}
                    img_data["url"] = newimageurl
                    img_data["alt"] = ""
                    imglist[count] = img_data
                    count += 1 

                item['thumb'] = imglist[0]['url']
                item['images'] = json.dumps(imglist)
            else:       #新闻资讯
                prefix = 'http:'
                count = 0
                for image in item.get('images'):
                    image = image.split('?')[0].split('-')[0].split('!')[0]
                    imageurl = prefix + image
                    suffix = pathlib.PurePath(image).suffix
                    if not suffix:
                        return item
                    now = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')[0:17]
                    objectname = 'www/uploadfile/' + now[0:4] + '/' + now[4:8] + '/' + now + suffix
                    try:
                        image_data = requests.get(imageurl, stream=True, timeout=60)
                        bucket.put_object(objectname, image_data)
                    except:
                        print('put_object error')

                    newimageurl = 'http://oss.66note.cn/' +  objectname
                    item['content'] = re.sub(image, newimageurl, item.get('content'))
                    if count == 0:
                        item['thumb'] = newimageurl
                    count += 1 
        else:
            item['thumb'] = 'http://www.66note.cn/noimg.gif';

        return item

class ProcessDataPipeline(object):
    '''1. 除去content的div标签'''
    def process_item(self, item, spider):
        print('内容处理')
        if item['status'] == 1:
            # item['thumb'] = ''
            item['content'] = re.sub(r'(^<div.*?>\s*|</div>$)', '', item.get('content')) 
            item['content'] = item['content'].replace('<script type="text/javascript">goBackHome(page_num);</script>', '')
            item['content'] = item['content'].replace('</div><div class="J-contain_detail_cnt contain_detail_cnt" id="J-contain_detail_cnt">', '[page]')
        return item
            
class SetStatusPipeline(object):
    '''更新状态'''
    def process_item(self, item, spider):
        print('更新状态')
        conn = pymysql.connect(host=HOST, user=USER, password=PASSWORD, db=DB, port=PORT, charset=CHARSET)
        with conn.cursor() as cursor:
            sql = 'update v9_news_list set status=2 where `id` = %s'
            newsid = str(item.get('newsid'))
            cursor.execute(sql, (newsid))
        conn.commit()
        conn.close()
        return item

class DBPipeline(object):
    '''将抓取并处理后的数据插入数据库'''
    def process_item(self, item, spider):
        print('插入数据库')
        # itime = int(time.time())
        itime = item.get('datetime')
        catid = item.get('catid')
        # url = 'http://news.66note.cn/index.php?m=content&c=index&a=show&catid=' + str(catid) + '&id='
        url = 'http://www.66note.cn/a/' + str(catid) + '-'
        conn = pymysql.connect(host=HOST, user=USER, password=PASSWORD, db=DB, port=PORT, charset=CHARSET)
        if item['status']==3:
            sql1 = 'insert into v9_picture (`catid`,`title`,`updatetime`,`thumb`,`inputtime`,`status`,`sysadd`,`username`) value (%s,%s,%s,%s,%s,%s,%s,%s)'
            sql2 = 'insert into v9_picture_data (`id`,`pictureurls`,`copyfrom`) value (%s,%s,%s)'
            sql3 = 'insert into v9_hits (`hitsid`,`catid`,`views`) value (%s,%s,%s)'
            sql4 = 'update v9_picture set url=%s where id=%s'
            with conn.cursor() as cursor:
                cursor.execute(sql1, (catid, item.get('title'), itime, item.get('thumb'), itime,99,1,item.get('username')))
                iid = int(cursor.lastrowid)
                hitsid = 'c-3-' + str(iid)
                url = url + str(iid) + '.html'
                cursor.execute(sql2, (iid, str(item.get('images')), item.get('copyfrom')))
                cursor.execute(sql3, (hitsid, catid, item.get('views')))
                cursor.execute(sql4, (url,str(iid)))
        else:
            sql1 = 'insert into v9_news (`catid`,`title`,`keywords`,`updatetime`,`thumb`,`inputtime`,`status`,`sysadd`,`username`,`description`) value (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
            sql2 = 'insert into v9_news_data (`id`,`copyfrom`,`content`,`paginationtype`) value (%s,%s,%s,%s)'
            sql3 = 'insert into v9_hits (`hitsid`,`catid`,`views`) value (%s,%s,%s)'
            sql4 = 'update v9_news set url=%s where id=%s'
            with conn.cursor() as cursor:
                cursor.execute(sql1, (catid, item.get('title'), item.get('keywords'), itime, item.get('thumb'), itime,99,1,item.get('username'), item.get('description')))
                iid = int(cursor.lastrowid)
                hitsid = 'c-1-' + str(iid)
                url = url + str(iid) + '.html'
                cursor.execute(sql2, (iid, item.get('copyfrom'), item.get('content'), 2))
                cursor.execute(sql3, (hitsid, catid, item.get('views')))
                cursor.execute(sql4, (url,str(iid)))
            
        conn.commit()
        conn.close()

        return item
        

