#coding:utf-8
__author__ = 'chenjianbin'
from scrapy import Request
#from scrapy.spiders import Spider, Rule
#from scrapy.selector import Selector
from scrapy.spiders import CrawlSpider
#from scrapy.linkextractors import LinkExtractor
from ZixunSpider.items import ZixunItem
from scrapy.exceptions import CloseSpider
import datetime
import time
import pymysql
import re

# HOST = '114.215.243.11'
# USER = 'xiexiakai'
# PASSWORD = '9XGYWzq+yHJRGe2U'
HOST = '127.0.0.1'
USER = 'news_66note'
PASSWORD = 'PRDEw0cM1IsVBWX6'
DB = 'news_66note'
PORT = 3306
CHARSET = 'utf8'
CATIDDICT = {}
NEWSTIME = {}
IDSET = {}

class zixunspider(CrawlSpider):
    name = "zixun"

    allowed_domains = [
        'mini.eastday.com',
        'miniimg.eastday.com'
    ]
    
    start_urls = [
        'http://mini.eastday.com',
    ]

    #rules = (
    #    Rule(LinkExtractor(allow=('news/index_\d+.html', ),),callback='parse_item',follow=True),
    #)

    def parse(self, response):
        '''将获取数据库中待采集的内容页列表，区分交给parse_content或者parse_images处理'''

        sql = 'select id,catid,url,inputtime from v9_news_list where status=0'
        conn = pymysql.connect(host=HOST, user=USER, password=PASSWORD, db=DB, port=PORT, charset=CHARSET)
        with conn.cursor() as cursor:
            cursor.execute(sql)
            row = cursor.fetchall()
            cursor.execute('update v9_news_list set status=1 where status=0')
            for row_id in row:
                CATIDDICT[row_id[2]] = row_id[1]
                NEWSTIME[row_id[2]] = row_id[3]
                IDSET[row_id[2]] = row_id[0]
                if row_id[1]==9:    #如果是图集内容，走图集采集
                    yield Request(row_id[2], callback=self.parse_image)
                else:               #不然走资讯新闻采集
                    yield Request(row_id[2], callback=self.parse_content)
        conn.commit()
        conn.close()

        print("列表采集完成")


    def parse_image(self, response):
        '''图集类别采集'''
        print('开始抓取图集！')
        item = ZixunItem()
        item['status'] = 3
        item['catid'] = CATIDDICT.pop(response.url)
        item['datetime'] = NEWSTIME.pop(response.url)
        item['newsid'] = IDSET.pop(response.url)
        try:
            contentdiv = response.xpath('//div[@class="sliderContentCnt"]')
            copyinfo = response.xpath('//div[@class="laiyuan"]/i/text()')
            ldate = copyinfo.extract()[0]
            item['title'] = response.xpath('//div[@class="titlecnt"]/h1/text()').extract()[0]
            item['keywords'] = ''
            item['description'] = ''
            item['username'] = '奇点资讯'
            item['views'] = 0
            item['copyfrom'] = copyinfo.extract()[1]
            item['content'] = ''
            item['images'] = contentdiv.xpath('.//img/@src').extract()
        except:
            print('some errors in {0}'.format(response.url))

        print("图集抓取完毕！")

        return item

        
    def parse_content(self, response):
        '''抓取相应资讯,并修改new_list表里已采集的新闻状态，提交管道进一步处理'''
        item = ZixunItem()
        item['status'] = 1
        item['catid'] = CATIDDICT.pop(response.url)
        item['datetime'] = NEWSTIME.pop(response.url)
        item['newsid'] = IDSET.pop(response.url)
        try:
            contentdiv = response.xpath('//div[@class="J-contain_detail_cnt contain_detail_cnt"]')
            descriptiondiv = response.xpath('//div[@class="J-contain_detail_cnt contain_detail_cnt"]/p/text()')
            copyinfo = response.xpath('//div[@class="fl"]/i/text()')
            pages = response.xpath('//div[@class="pagination"]/a/text()')
            ldate = copyinfo.extract()[0]
            # ldate = copyinfo.re(r'时间.\s*(\d{4})-(\d{2})-(\d{2})\s*(\d{2}):(\d{2}):?(\d{2})?')
            item['title'] = response.xpath('//div[@class="J-title_detail title_detail"]/h1/span/text()').extract()[0]
            item['keywords'] = ''
            if descriptiondiv.extract():
                item['description'] = descriptiondiv.extract()[0]
            else:
                item['description'] = ''
            item['copyfrom'] = copyinfo.extract()[1]
            item['content'] = contentdiv.extract()[0]
            item['images'] = contentdiv.xpath('.//img/@src').extract()
            item['username'] = '奇点资讯'
            item['views'] = 0
        except:
            print('some errors in {0}'.format(response.url))

        pagelen = len(pages.extract())
        if int(pagelen)>0:
            item['pages'] = int(pages.extract()[int(pagelen)-2])
            item['nextpages'] = 2
            url = response.url[:-5]
            item['url'] = url
            url = url + '-' +  str(item['nextpages']) + '.html'
            yield Request(url, callback=self.parse_pages,meta={'item': item})
        else:
            yield item

    def parse_pages(self, response):
        item = response.meta['item']

        url = item['url']
        pages = item['nextpages']
        print('第' + str(pages) +'页')
        try:
            contentdiv = response.xpath('//div[@class="J-contain_detail_cnt contain_detail_cnt"]')
            item['content'] = item['content'] + contentdiv.extract()[0]
            item['images'] = item['images'] + contentdiv.xpath('.//img/@src').extract()
        except:
            print('some errors in {0}'.format(response.url))
        if int(pages) == int(item['pages']):
            yield item
        else:
            item['nextpages'] = int(pages) + 1
            nexturl = url + '-' + str(item['nextpages']) + '.html'
            yield Request(nexturl, callback=self.parse_pages,meta={'item': item})