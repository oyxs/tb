# -*- coding: utf-8 -*-
__author__ = 'chenjianbin'

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class ZixunSpiderItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    pass

class ZixunItem(scrapy.Item):
    title = scrapy.Field()
    catid = scrapy.Field()
    keywords = scrapy.Field()
    description = scrapy.Field()
    username = scrapy.Field()
    copyfrom = scrapy.Field()
    views = scrapy.Field()
    datetime = scrapy.Field()
    images = scrapy.Field()
    content = scrapy.Field()
    thumb = scrapy.Field()
    status = scrapy.Field()
    pages = scrapy.Field()
    nextpages = scrapy.Field()
    url = scrapy.Field()
    newsid = scrapy.Field()

