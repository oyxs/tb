# -*- coding: utf-8 -*-
__author__ = 'chenjianbin'
import scrapy
from scrapy.spiders import CrawlSpider
from PCSpider.items import PCItem
from scrapy.exceptions import CloseSpider
import datetime
import pymysql
import time
import re

class PCSpider(scrapy.Spider):
    name = "pc"
    allowed_domains = ["pc6.com"]
    start_urls = ['http://www.pc6.com/']

    def parse(self, response):
        '''获取更新软件的地址,并yield到下一层处理'''
        apps = response.xpath('//div[@class="content clearfix"]/div[@class="cont clearfix"][1]/ul/li')
        for app in apps:
            istoday = app.xpath('./em/font[@color="red"]/text()').re(r'.*?(\d*).*')
            url = 'http://www.pc6.com' + app.xpath('./a/@href').extract()[0]
            if istoday:
                yield scrapy.Request(url, callback=self.parse_content)

    def parse_content(self, response):
        '''抓取相应软件内容信息,交给管道进一步处理'''
        item = PCItem()
        try:
            item['size'] = response.xpath('//div/ul[@class="param-ul bluea"]/li/span[@itemprop="fileSize"]/text()').extract()[0]
            item['shorttitle'] = response.xpath('//div[@id="mainBody"]/dl/dt[@id="main"]/h1/text()').extract()[0]
            item['version'] = response.xpath('//div[@id="mainBody"]/dl/dt[@id="main"]/h1/span/text()').re('\s*[vV]?([0-9\.]+).*')[0]
            item['thumb'] = response.xpath('//div[@id="mainBody"]/dl[@id="param"]/dt[@id="main"]/img/@src').extract()[0]
            item['catname'] = response.xpath('//div/ul[@class="param-ul bluea"]/li[text()="软件类别："]/span/text()').extract()[0].strip()
            item['title'] = response.xpath('//html/head/title/text()').extract()[0]
            item['keywords'] = ''
            item['description'] = response.xpath('/html/head/meta[@name="description"]/@content').extract()[0].replace('pc6', 'kr126')
            item['content'] = ''.join(response.xpath('//div[@id="soft-intro"]/p').extract())
            item['images'] = response.xpath('//div[@id="soft-intro"]/p/img/@src').extract()
            tags = response.xpath('//div[@id="soft-intro"]/p/a').extract()
            tags_text = response.xpath('//div[@id="soft-intro"]/p/a/text()').extract()
            item['tags'] = zip(tags, tags_text)
            item['bdownload'] = response.xpath('//dl[@id="content"]/dd[@id="download"]/ul[@class="content greena clearfix"]/li[@class="address-wrap on"]//a/@href').extract()[0]
        except Exception as e:
            print('{0}: {1}'.format(response.url, e))
        return item
        


