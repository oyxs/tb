#!/usr/bin/env python
DB = {
      'host': '127.0.0.1',
      #'HOST': '120.26.234.213',
      'user': 'remote',
      'password': 'jfC8Uj9u6eQKoD3S',
      'db': 'kr126',
      'port': 3306,
      'charset': 'utf8',
     }

OSS = {
       'AccessKeyId': 'LTAImuMNiS1jtmHy',
       'AccessKeySecret': 'NLImG3mBwBTOC2gzNLITBv9zjIf2Kr',
       'ENPOINT': 'oss-cn-hangzhou-internal.aliyuncs.com',
       #'ENPOINT': 'oss-cn-hangzhou.aliyuncs.com',
       'BUCKET': 'oss-kr126-com',
       'DIRECTORY': 'www/uploadfile/'
      }

ADFILE = '酷睿软件园下载说明.htm'

COMMENT = '''
                ┏━━━━━━━━━━━━━━━━━┓
                ┃          ★酷睿软件园★          ┃
┏━━━━━━━┫       Http://Www.Kr126.Com       ┣━━━━━━━┓
┃              ┃       →最安全的绿色下载站←       ┃              ┃
┃              ┗━━━━━━━━━━━━━━━━━┛              ┃
┃                                                                  ┃
┃    酷睿软件园是一个专业软件下载网站，经过多年的发展已成为国内    ┃
┃                                                                  ┃
┃  最具影响力的下载站之一，提供最新最全的免费软件、手机软件、单机  ┃
┃                                                                  ┃
┃      游戏下载，深受广大用户的喜爱！安全下载，从下载吧开始！      ┃
┃                                                                  ┃
┃                                                                  ┃
┃                  电脑软件：http://www.kr126.com                  ┃
┃                                                                  ┃
┃                                                                  ┃
┃                                                                  ┃
┃                                                                  ┃
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃                                                                  ┃
┃           ☆ 绿色软件，安全下载，精品分享绿色下载吧！☆          ┃
┃                                                                  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
'''

