/**
 * Unicorn Admin Template
 * Diablo9983 -> diablo9983@gmail.com
**/
$(document).ready(function(){

	var speed = 400;
    var apiUrl = "/login";
    var recover = $('#recoverform'),
        login = $('#loginform'),
        loginAlert = $(".loginAlert"),
        loginEmail = $(".loginEmail"),
        loginPassword = $(".loginPassword");

	$('#to-recover').click(function(){
		login.fadeTo(speed,0.01).css('z-index','100');
		recover.fadeTo(speed,1).css('z-index','200');
	});

	$('#to-login').click(function(){
		recover.fadeTo(speed,0.01).css('z-index','100');
		login.fadeTo(speed,1).css('z-index','200');
	});
    
    if($.browser.msie == true && $.browser.version.slice(0,3) < 10) {
        alert("为了更好的使用体验，我们强烈建议您使用Chrome或Firefox浏览器访问本网站！");
        $('input[placeholder]').each(function(){
            var input = $(this);       
           
            $(input).val(input.attr('placeholder'));
                   
            $(input).focus(function(){
                 if (input.val() == input.attr('placeholder')) {
                     input.val('');
                 }
            });
           
            $(input).blur(function(){
                if (input.val() == '' || input.val() == input.attr('placeholder')) {
                    input.val(input.attr('placeholder'));
                }
            });
        });   
    }

    // 显示登录提示
    function showloginAlert(msg, type){
        if(type == "success"){
            loginAlert.css("color", "green");
        }else{
            loginAlert.css("color", "red");
        }
        loginAlert.text(msg);
        loginAlert.show();
        setTimeout(function(){
            loginAlert.fadeOut(speed);
        }, 2000);
    }

    function isValidEmail(email) {
        var re = /\S+@\S+\.\S+/;
        return re.test(email);
    }
    // 验证登录参数
    function validateLogin(){
        var email = loginEmail.val();
        var password = loginPassword.val();
        if(email == '' || !isValidEmail(email)){
            return false;
        }
        if(password == ''){
            return false;
        }
        return true;
    }

    // 登陆事件
    function loginSubmit(event){
        event.preventDefault();
        if(!validateLogin()){
            showloginAlert("请正确填写Email和密码！");
            return;
        }
        $.getJSON(apiUrl, {
            'email' : loginEmail.val(),
            'password' : loginPassword.val()
        }).done(function(data){
            if(data.code == undefined || data.code < 0){
                if(data.msg != ""){
                    showloginAlert(data.msg);
                    return;
                }
                showloginAlert("登陆失败！");
                return;
            }
            showloginAlert(data.msg, "success");
            window.location = "/index";
            return;
        }).fail(function(){
            showloginAlert("登陆失败！");
            return;
        });
    }

    $("#loginBtn").click(loginSubmit);

    if(top !== self){
        top.location.reload();
    }
});