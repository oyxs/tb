/**
 *|---------------------------------------------------------------------
 *| 渲染JS模板
 *|---------------------------------------------------------------------
 */
(function(){
	Mustache.tags = ["<%", "%>"];
	var Temp = {};
	var modal_temp = $("#modalTemp").html();
	Mustache.parse(modal_temp);
	var sel_temp = $("#selTemp").html();
	Mustache.parse(sel_temp);
	var item_temp = $("#itemTemp").html();
	Mustache.parse(item_temp);
	var page_temp = $("#pageTemp").html();
	Mustache.parse(page_temp);
	var move_temp = $("#moveTemp").html();
	Mustache.parse(move_temp);

	Temp.modal = modal_temp;
	Temp.sel  = sel_temp;
	Temp.item = item_temp;
	Temp.page = page_temp;
	Temp.move = move_temp;

	window['Temp'] = Temp;
})();

/**
 * 初始化物料悬浮窗
 */
function initMaterialModal(pageId, itemId, data, pagename) {
	var isCreate = true;
	if(data != undefined && data != []){
		isCreate = false;
	}

	var header = isCreate ? "添加条目" : "编辑条目";
	var rendered = Mustache.render(Temp.modal, {
		header : header
	});
	$('#editModal').empty();
	$("#editModal").append($(rendered));
	$('#editModal select').select2({
		width : '200px'
	});
	// 根据模板渲染广告物料选择区域
	var versionSelect = $("select[name=downVersion]").select2("data");
	var selData = $(versionSelect.element).attr("sel-data");
	if(selData == undefined){
		return;
	}

	selData = $.parseJSON(selData);
	$.each(selData, function(k, v){
		if(pagename == "顶部广告" && v.place == 1){
			var rendered = Mustache.render(Temp.sel, {
				selval : v.id,
				selname :v.name
			});
			$("#editModal select[name=materialId],#editModal select[name=altmaterialId]").append($(rendered));
		}else if(pagename == "侧边广告" && v.place == 2){
			var rendered = Mustache.render(Temp.sel, {
				selval : v.id,
				selname :v.name
			});
			$("#editModal  select[name=materialId],#editModal select[name=altmaterialId]").append($(rendered));
		}else if(pagename !='侧边广告'&&pagename!='顶部广告'&& v.place==0){
			var rendered = Mustache.render(Temp.sel, {
				selval : v.id,
				selname :v.name
			});
			$("#editModal  select[name=materialId],#editModal select[name=altmaterialId]").append($(rendered));
		}
	});

	// 注入内容区域ID到Modal
	$("#editModal input[name=pageId]").val(pageId);
	$("#editModal input[name=itemId]").val(itemId);

	// 如果是编辑模式 注入数据
	if(!isCreate){
		fillMaterialModal(data);
	}

	// 如果是备选区，禁止设置备选
	if(pageId == 'alternative') {
		$("#editModal select[name=altmaterialId]").select2("readonly", true);
		$("#editModal input[name=detectItem]").attr('disabled', 'disabled');
	}

	// 绑定事件
	$("#editModal select[name=materialId]").change(EventHandler.materialChange);
	$("#editModal .saveMaterialBtn").click(EventHandler.saveMaterialBtnClick);
	$("#editModal .colorpicker").colorpicker();
	$("#editModal").modal('show');
}

function fillMaterialModal (material) {
	if($("#editModal select[name=materialId]").val() == 0){
		$("#editModal select[name=materialId]").select2("val", material.id);
	}
	$(".startpage").hide();
	$(".install").hide();
	$(".createlink").hide();
	$("#editModal input[name=name]").val(material.name);
	$("#editModal input[name=link]").val(material.link);
	$("#editModal input[name=mlinkName]").val(material.mlinkName);
	$("#editModal input[name=savePath]").val(material.savePath);
	$("#editModal input[name=cmdLine]").val(material.cmdLine);
	$("#editModal input[name=linkName]").val(material.linkName);
	$("#editModal input[name=linkColor]").val(material.linkColor);
	$("#editModal input[name=logoUrl]").val(material.logoUrl);
	$("#editModal input[name=img]").val(material.img);
	$("#editModal input[name=showTime]").val(material.showTime);
	$("#editModal input[name=place]").val(material.place);

	$("#editModal input[name=materialContent]").val(JSON.stringify(material));
	if(material.detectItem != undefined){
		$("#editModal input[name=detectItem]").val(material.detectItem);
	}
	if(material.altid != undefined){
		$("#editModal select[name=altmaterialId]").select2("val", material.altid);
	}
	if(material.cssilent != undefined){
		$("#editModal select[name=cssilent]").select2("val", material.cssilent);
	}
	if(material.sdSoft != undefined) {
		$.each(material.sdSoft, function(key, value){
			$("input[type=checkbox][name=sdSoft[]][value=" + value + "]").attr('checked','true');
		});
	}
	$("." + material.type).show();
}


/**
 * 移动位置
 */
function moveMaterialModal(itemId) {
	var tclass = '';
	var items = '';
	var itemLength = '';
	var itemAll = '';
	var itemPageId = '';
	var header = "移动条目";
	var rendered = Mustache.render(Temp.move, {
		header : header
	});
	$('#moveModal').empty();
	$("#moveModal").append($(rendered));
	tclass = $("#"+itemId).attr("class");
	items = $("."+tclass+" td input[type=hidden]");
	itemLength = items.length;
	for(i=0;i<itemLength;i++){
		movePageId = items.eq(i).siblings("a").eq(0).attr('page-id');
		if(items.eq(i).val() == ''){
			moveItemId = items.eq(i).siblings("a").eq(0).attr('item-id');
			$("#move"+movePageId).show();
			$("#move"+movePageId+" input[name=moveItemId]").val(moveItemId);
		}
	}
	// 注入内容区域ID到Modal
	$("#moveModal select[name=altmaterialId]").val(itemId);

	// 绑定事件
	$("#moveModal input[name=moveItemId]").change(EventHandler.moveChange);
	$('#moveModal').modal('show');
}

/**
 *|---------------------------------------------------------------------
 *| 事件句柄
 *|---------------------------------------------------------------------
 */
var EventHandler = {
	// 下载器版本改变事件
	downVersionChange : function(event) {
		// 警告编辑过的数据会丢失
		if($('#collapse-group').find("div").length != 0){
			if(!confirm("确定要更改版本吗？之前编辑的数据将丢失！")){
				return;
			}
		}

		// 隐藏、清空内容区域
		$(".adContent").hide();
		$('#collapse-group').empty();

		// 获取页数
		var versionSelect = $(this).select2("data");
		var pageData = $(versionSelect.element).attr("page-data");
		if(pageData == undefined){
			return;
		}
		pageData = $.parseJSON(pageData);

		// 根据模板渲染内容编辑区域
		$.each(pageData, function(k, v){
			// 渲染广告页面
			var rendered = Mustache.render(Temp.page, {
				contentid : k,
				pagename : v.name
			});
			$('#collapse-group').append($(rendered));
			// 渲染广告页面条目
			for(var i = 0; i < parseInt(v.num); i++) {
				var rendered = Mustache.render(Temp.item, {
					itemId : "1_"+k + "_" + i,
					pageId : "0]["+k
				});
				$("#collapse-group #" + k + " table").eq(0).children("tbody").append($(rendered));
				
				var rendered2 = Mustache.render(Temp.item, {
					itemId : "2_"+k + "_" + i,
					pageId : "1]["+k
				});
				$("#collapse-group #" + k + " table").eq(1).children("tbody").append($(rendered2));
			}
		});


		// 添加条目按钮事件
		$(".adContent").show();
		// 显示条目的tip提示
		$('.tip-top').tooltip({ placement: 'top' });
		// 绑定编辑按钮事件
		$(".itemEditBtn").click(EventHandler.itemEditBtnClick);
	},

	itemEditBtnClick : function(event) {
		var mval = "",dataInput = $(this).siblings("input[type=hidden]");
		if(dataInput.val() != ""){
			mval = $.parseJSON(dataInput.val());
		}
		var pageId = $(this).attr("page-id");
		var itemId = $(this).attr("item-id");
		var pagename = $(this).parents(".accordion-group").find("h5").text();
		initMaterialModal(pageId, itemId, mval,pagename);
	},
	
	
	//物料移动位置 
	itemMoveBtnClick : function(event) {
		var itemId=$(this).attr("item-id");
		moveMaterialModal(itemId);
	},
	
	// 移动改变事件
	moveChange :function(event){
		var itemId='';
		var moveItemId='';
		var mval = "",
		itemId=$("#moveModal input[name=itemId]").val();
		moveItemId=$(this).val();
		dataInput = $("#" + itemId + " input[type=hidden]");
		if(dataInput.val() != ""){
			mval = $.parseJSON(dataInput.val());
		}
		if(mval != undefined) {
			$("#" + moveItemId + " input[type=hidden]").val(JSON.stringify(mval));
			$("#" + moveItemId + " .materName span").html(mval.name);
			if(mval.altname != undefined){
				$("#" + moveItemId + " .altMaterName span").html(mval.altname);
			}
			$("#" + itemId + " input[type=hidden]").val('');
			$("#" + itemId + " .materName span").html('');
			$("#" + itemId + " .altMaterName span").html('');
		}
		
		$("#moveModal").modal('hide');
	},
	//上移
	itemUpBtnClick : function(event){
		var itemId = $(this).attr('item-id');
		var upId = $("#"+itemId).prev().attr("id");
		if(upId==undefined){
			alert("已经是第一个了，不能往上移了");
		}else{
			if($("#"+itemId+" input[type=hidden]").val() != ""){
				mval = $.parseJSON($("#"+itemId+" input[type=hidden]").val());
			}else{
				mval = '';
			}
			if($("#"+upId+" input[type=hidden]").val() != ""){
				mvalUp = $.parseJSON($("#"+upId+" input[type=hidden]").val());
			}else{
				mvalUp = '';
			}
			if(mval==''){
				$("#" + upId + " input[type=hidden]").val('');
				$("#" + upId + " .materName span").html('');
				$("#" + upId + " .altMaterName span").html('');
			}else{
				$("#" + upId + " input[type=hidden]").val(JSON.stringify(mval));
				$("#" + upId + " .materName span").html(mval.name);
				$("#" + upId + " .altMaterName span").html(mval.altname);
			}
			if(mvalUp==''){
				$("#" + itemId + " input[type=hidden]").val('');
				$("#" + itemId + " .materName span").html('');
				$("#" + itemId + " .altMaterName span").html('');
			}else{
				$("#" + itemId + " input[type=hidden]").val(JSON.stringify(mvalUp));
				$("#" + itemId + " .materName span").html(mvalUp.name);
				$("#" + itemId + " .altMaterName span").html(mvalUp.altname);
			}
		}
	},
	//下移
	itemDownBtnClick : function(event){
		var itemId = $(this).attr('item-id');
		var downId = $("#"+itemId).next().attr("id");
		if(downId==undefined){
			alert("已经是最后一个了，不能往下移了");
		}else{
			if($("#"+itemId+" input[type=hidden]").val() != ""){
				mval = $.parseJSON($("#"+itemId+" input[type=hidden]").val());
			}else{
				mval = '';
			}
			if($("#"+downId+" input[type=hidden]").val() != ""){
				mvalDown = $.parseJSON($("#"+downId+" input[type=hidden]").val());
			}else{
				mvalDown = '';
			}
			if(mval==''){
				$("#" + downId + " input[type=hidden]").val('');
				$("#" + downId + " .materName span").html('');
				$("#" + downId + " .altMaterName span").html('');
			}else{
				$("#" + downId + " input[type=hidden]").val(JSON.stringify(mval));
				$("#" + downId + " .materName span").html(mval.name);
				$("#" + downId + " .altMaterName span").html(mval.altname);
			}
			if(mvalDown==''){
				$("#" + itemId + " input[type=hidden]").val('');
				$("#" + itemId + " .materName span").html('');
				$("#" + itemId + " .altMaterName span").html('');
			}else{
				$("#" + itemId + " input[type=hidden]").val(JSON.stringify(mvalDown));
				$("#" + itemId + " .materName span").html(mvalDown.name);
				$("#" + itemId + " .altMaterName span").html(mvalDown.altname);
			}
		}
	},

	// 物料包改变事件
	materialChange : function(event) {
		var material = null;
		if($(this).val() == "0"){
			$("#materialForm")[0].reset();
			return;
		}
		for(var i in materials) {
			if(materials[i].id == $(this).val()){
				material = materials[i];
			}
		}
		if(material == null){
			return;
		}
		fillMaterialModal(material);
	},

	// 保存物料按钮事件
	saveMaterialBtnClick : function(event) {
		// 获取表单数据
		if($("#editModal select[name=materialId]").val() != 0){
			var content = $("#editModal input[name=materialContent]").val();
			var mval = $.parseJSON(content);
			mval.name = $("#editModal input[name=name]").val();
			mval.link = $("#editModal input[name=link]").val();
			mval.mlinkName = $("#editModal input[name=mlinkName]").val();
			mval.savePath = $("#editModal input[name=savePath]").val();
			mval.cmdLine = $("#editModal input[name=cmdLine]").val();
			mval.linkName = $("#editModal input[name=linkName]").val();
			mval.cssilent = $("#editModal select[name=cssilent]").val();
			mval.linkColor = $("#editModal input[name=linkColor]").val();
			mval.logoUrl = $("#editModal input[name=logoUrl]").val();
			mval.showTime = $("#editModal input[name=showTime]").val();
			mval.place = $("#editModal input[name=place]").val();
			mval.img = $("#editModal input[name=img]").val();
			mval.sdSoft = [];
			$("input[type=checkbox][name=sdSoft[]]:checked").each(function(index){
				mval.sdSoft.push($(this).val());
			});
			if($("#editModal input[name=detectItem]").val() != undefined){
				mval.detectItem = $("#editModal input[name=detectItem]").val();
			}
			// 获取备选条目信息
			if($("#editModal select[name=altmaterialId]").val() != 0){
				mval.altid = $("#editModal select[name=altmaterialId]").val();
				if(mval.id == mval.altid){
					alert("备选物料与主物料相同！请重新选择！");
					return;
				}
				mval.altname = $("#editModal select[name=altmaterialId]").select2("data");
				mval.altname = mval.altname.text;
			} else {
				mval.altname = undefined;
				mval.altid = undefined;
			}
		}

		// 保存数据到标签
		var pageId = $("#editModal input[name=pageId]").val();
		var itemId = $("#editModal input[name=itemId]").val();
		$("#" + itemId + " input[type=hidden]").val("");
		$("#" + itemId + " .materName span").html("");
		$("#" + itemId + " .altMaterName span").html("");
		if(mval != undefined) {
			$("#" + itemId + " input[type=hidden]").val(JSON.stringify(mval));
			$("#" + itemId + " .materName span").html(mval.name);
			if(mval.altname != undefined){
				$("#" + itemId + " .altMaterName span").html(mval.altname);
			}
		} 
		$("#editModal").modal('hide');
	}
};