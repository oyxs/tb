/**
 *|---------------------------------------------------------------------
 *| 渲染JS模板
 *|---------------------------------------------------------------------
 */
(function(){
	Mustache.tags = ["<%", "%>"];
	var Temp = {};
	var modal_temp = $("#modalTemp").html();
	Mustache.parse(modal_temp);
	var item_temp = $("#itemTemp").html();
	Mustache.parse(item_temp);
	var page_temp = $("#pageTemp").html();
	Mustache.parse(page_temp);

	Temp.modal = modal_temp;
	Temp.item = item_temp;
	Temp.page = page_temp;

	window['Temp'] = Temp;
})();

/**
 * 初始化物料悬浮窗
 */
function initMaterialModal(pageId, itemId, data) {
	var isCreate = true;
	if(data != undefined && data != []){
		isCreate = false;
	}

	var header = isCreate ? "添加条目" : "编辑条目";
	var rendered = Mustache.render(Temp.modal, {
		header : header
	});
	$('#editModal').empty();
	$("#editModal").append($(rendered));
	$('#editModal select').select2({
		width : '200px'
	});

	// 注入内容区域ID到Modal
	$("#editModal input[name=pageId]").val(pageId);
	$("#editModal input[name=itemId]").val(itemId);

	// 如果是编辑模式 注入数据
	if(!isCreate){
		fillMaterialModal(data);
	}

	// 如果是备选区，禁止设置备选
	if(pageId == 'alternative') {
		$("#editModal select[name=altmaterialId]").select2("readonly", true);
	}

	// 绑定事件
	$("#editModal select[name=materialId]").change(EventHandler.materialChange);
	$("#editModal .saveMaterialBtn").click(EventHandler.saveMaterialBtnClick);
	$('#editModal').modal('show');
}

function fillMaterialModal (material) {
	if($("#editModal select[name=materialId]").val() == 0){
		$("#editModal select[name=materialId]").select2("val", material.id);
	}
	$(".startpage").hide();
	$(".install").hide();
	$(".createlink").hide();
	$("#editModal input[name=name]").val(material.name);
	$("#editModal input[name=link]").val(material.link);
	$("#editModal input[name=savePath]").val(material.savePath);
	$("#editModal input[name=cmdLine]").val(material.cmdLine);
	$("#editModal input[name=linkName]").val(material.linkName);
	$("#editModal input[name=materialContent]").val(JSON.stringify(material));
	if(material.altid != undefined){
		$("#editModal select[name=altmaterialId]").select2("val", material.altid);
	}
	$("." + material.type).show();
}

/**
 *|---------------------------------------------------------------------
 *| 事件句柄
 *|---------------------------------------------------------------------
 */
var EventHandler = {
	// 下载器版本改变事件
	downVersionChange : function(event) {
		// 警告编辑过的数据会丢失
		if($('#collapse-group').find("div").length != 0){
			if(!confirm("确定要更改版本吗？之前编辑的数据将丢失！")){
				return;
			}
		}

		// 隐藏、清空内容区域
		$(".adContent").hide();
		$('#collapse-group').empty();

		// 获取页数
		var versionSelect = $(this).select2("data");
		var pageData = $(versionSelect.element).attr("page-data");
		if(pageData == undefined){
			return;
		}
		pageData = $.parseJSON(pageData);

		// 根据模板渲染内容编辑区域
		$.each(pageData, function(k, v){
			// 渲染广告页面
			var rendered = Mustache.render(Temp.page, {
				contentid : k,
				pagename : v.name
			});
			$('#collapse-group').append($(rendered));
			// 渲染广告页面条目
			for(var i = 0; i < parseInt(v.num); i++) {
				var rendered = Mustache.render(Temp.item, {
					itemId : k + "_" + i,
					pageId : k
				});
				$("#collapse-group #" + k + " tbody").append($(rendered));
			}
		});

		// 添加条目按钮事件
		$(".adContent").show();
		// 显示条目的tip提示
		$('.tip-top').tooltip({ placement: 'top' });
		// 绑定编辑按钮事件
		$(".itemEditBtn").click(EventHandler.itemEditBtnClick);
	},

	itemEditBtnClick : function(event) {
		var mval = "",dataInput = $(this).siblings("input[type=hidden]");
		if(dataInput.val() != ""){
			mval = $.parseJSON(dataInput.val());
		}
		var pageId = $(this).attr("page-id");
		var itemId = $(this).attr("item-id");
		initMaterialModal(pageId, itemId, mval);
	},

	// 物料包改变事件
	materialChange : function(event) {
		var material;
		for(var i in materials) {
			if(materials[i].id == $(this).val()){
				material = materials[i];
			}
		}
		if(material == undefined){
			return;
		}
		fillMaterialModal(material);
	},

	// 保存物料按钮事件
	saveMaterialBtnClick : function(event) {
		// 获取表单数据
		var content = $("#editModal input[name=materialContent]").val();
		var mval = $.parseJSON(content);
		mval.name = $("#editModal input[name=name]").val();
		mval.link = $("#editModal input[name=link]").val();
		mval.savePath = $("#editModal input[name=savePath]").val();
		mval.cmdLine = $("#editModal input[name=cmdLine]").val();
		mval.linkName = $("#editModal input[name=linkName]").val();
		var altname = null;
		// 获取备选条目信息
		if($("#editModal select[name=altmaterialId]").val() != 0){
			mval.altid = $("#editModal select[name=altmaterialId]").val();
			if(mval.id == mval.altid){
				alert("备选物料与主物料相同！请重新选择！");
				return;
			}
			altname = $("#editModal select[name=altmaterialId]").select2("data");
			altname = altname.text;
		}
		// 保存数据到标签
		var pageId = $("#editModal input[name=pageId]").val();
		var itemId = $("#editModal input[name=itemId]").val();
		$("#" + itemId + " input[type=hidden]").val(JSON.stringify(mval));
		$("#" + itemId + " .materName span").html(mval.name);
		// 保存备选数据
		if(altname != null){
			$("#" + itemId + " .altMaterName span").html(altname);
		}
		$("#editModal").modal('hide');
	}
};

/**
 *|---------------------------------------------------------------------
 *| JS入口函数
 *|---------------------------------------------------------------------
 */
$(document).ready(function(){
	$('input[type=checkbox],input[type=radio],input[type=file]').uniform();
	$('select').select2({
		width : '200px'
	});

	// 绑定下载器版本改变事件
	$("select[name=downVersion]").change(EventHandler.downVersionChange);
});