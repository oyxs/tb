(function($){

	function Rest(baseUrl){
		this.baseUrl = baseUrl;

		$.ajaxSetup({
			async : true,
			dataType : "json",
			beforeSend : function(){
				
			},
			error : function(){
				alert("服务器连接异常！");
			}
		});

		if(typeof Rest._initialized == "undefined"){

			Rest.prototype.show = function(id){
				if(!id){
					return false;
				}
				return $.ajax({
					type : "GET",
					url : baseUrl + "/" + id
				});
			}

			Rest.prototype.store = function(data){
				return $.ajax({
					type : "POST",
					url : baseUrl,
					data : data
				});
			}

			Rest.prototype.update = function(id, data){
				return $.ajax({
					type : "PUT",
					url : baseUrl + "/" + id,
					data : data
				});
			}

			Rest.prototype.destroy = function(id){
				return $.ajax({
					type : "DELETE",
					url : baseUrl + "/" + id
				});
			}

			Rest._initialized = true;
		}
	}

	if(!window['Rest']){
		window.Rest = Rest;
	}
})(jQuery);