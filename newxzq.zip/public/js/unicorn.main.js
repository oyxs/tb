$(document).ready(function(){

	$('.submenu > a').click(function(e){
		e.preventDefault();
		var submenu = $(this).siblings('ul');
		var li = $(this).parents('li');
		var submenus = $('#sidebar li.submenu ul');
		var submenus_parents = $('#sidebar li.submenu');

		if(li.hasClass('open')) {
			if(($(window).width() > 768) || ($(window).width() < 479)) {
				submenu.slideUp();
			} else {
				submenu.fadeOut(250);
			}
			li.removeClass('open');
		} else {
			if(($(window).width() > 768) || ($(window).width() < 479)) {
				submenus.slideUp();			
				submenu.slideDown();
			} else {
				submenus.fadeOut(250);			
				submenu.fadeIn(250);
			}
			submenus_parents.removeClass('open');		
			li.addClass('open');
		}
	});
	$('.primarymenu > a').click(function(e){
		e.preventDefault();
		var primaryLis = $("#sidebar ul li");
		var li = $(this).parents("li");
		var url = $(this).attr("href");
		primaryLis.removeClass("active");
		primaryLis.removeClass("open");
		li.addClass('active');
		li.addClass('open');
		$("iframe[name=contentPage]").attr("src", url);
	});
	$(".submenu > ul > li > a").click(function(e){
		e.preventDefault();
		var primaryLis = $("#sidebar ul li");
		var li = $(this).parents("li");
		var url = $(this).attr("href");
		primaryLis.removeClass("active");
		primaryLis.removeClass("open");
		li.addClass('active');
		li.addClass('open');
		$("iframe[name=contentPage]").attr("src", url);
	});

	function setIframeHeight() {
		var iframeHeight = $(window).height() - 77;
		$("iframe[name=contentPage]").css('height', iframeHeight);
		$("body").css("height", $(window).height());
	}
	setIframeHeight();
	$(window).resize(setIframeHeight);
	
	// === Style switcher === //
	$('#style-switcher i').click(function() {
		if($(this).hasClass('open')) {
			$(this).parent().animate({marginRight:'-=190'});
			$(this).removeClass('open');
		} else  {
			$(this).parent().animate({marginRight:'+=190'});
			$(this).addClass('open');
		}
		$(this).toggleClass('icon-arrow-left');
		$(this).toggleClass('icon-arrow-right');
	});
	$('#style-switcher a').click(function() {
		var style = $(this).attr('href').replace('#','');
		$('.skin-color').attr('href','/css/unicorn.'+style+'.css');
		$(this).siblings('a').css({'border-color':'transparent'});
		$(this).css({'border-color':'#aaaaaa'});
	});
	
	$('#style-sidebar i').click(function(){
		if($(this).hasClass('open')) {
			$('#sidebar').animate({marginLeft:'+=220'});
			$('#content').animate({marginLeft:'+=220'});
			$(this).animate({Left:'+=220'});
			$(this).removeClass('open');
		} else  {
			$('#sidebar').animate({marginLeft:'-=220'});
			$('#content').animate({marginLeft:'-=220'});
			$(this).animate({Left:'-=220'});
			$(this).addClass('open');
		}
		$(this).toggleClass('icon-arrow-right');
		$(this).toggleClass('icon-arrow-left');
	});
});
