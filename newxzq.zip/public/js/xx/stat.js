(function(){
    var chartsOptions = {
        title: {
            text: ''
        },
        xAxis: {
            title: '',
            lineWidth: 1,
            gridLineWidth: 0,
            gridLineColor: '#EEE',
            lineColor: '#DDD',
            type: 'datetime',
            maxPadding:0,
            minPadding:0,
            showFirstLabel:true,
            showLastLabel:true,
            dateTimeLabelFormats: {
                second: '%H:%M:%S',
                minute: '%H:%M',
                hour: '%H:%M',
                day: '%m - %e',
                week: '%m - %e',
                month: '%b \'%y',
                year: '%Y'
            },
            labels:{
                overflow: 'justify',
                y:20,
                style:{
                    'color':'#999'
                }
            }
        },
        yAxis: {
            title: {
                text: 'UV (次数)'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: '次'
        },
        credits: {
            enabled: false
        },
        legend: {
            layout: 'horizontal',
            align: 'center',
            verticalAlign: 'bottom',
            borderWidth: 0
        }
    };

    window["chartsOptions"] = chartsOptions;
})();

function getDurationTime(timeType){
    var result = {};
    switch(timeType) {
        case 'day':
            result.start = moment().format("YY-MM-DD");
            result.end = moment().format("YY-MM-DD");
            break;
        case 'week':
            result.start = moment().subtract(7, 'days').format("YY-MM-DD");
            result.end = moment().format("YY-MM-DD");
            break;
        case 'month':
            result.start = moment().format("YYYY-MM-01");
            result.end = moment().format("YYYY-MM-DD");
            break;
        case 'time':
            result.start = $("#time-start").val();
            result.end = $("#time-end").val();
            break;
        default:
            result.start = moment().format("YY-MM-DD");
            result.end = moment().format("YY-MM-DD");
    }
    return result;
}

function showAlert(msg,type){
    var alertSpan = $(".alertSpan");
    if(type == "success"){
        alertSpan.css("color", "green");
    }else{
        alertSpan.css("color", "red");
    }
    alertSpan.text("提示：" + msg);
    alertSpan.show();
    setTimeout(function(){
        alertSpan.fadeOut(1000);
    }, 2000);
}


$(document).ready(function(){
    // 按钮组控件
    $(".btn-group>.btn").click(function(event){
        event.preventDefault();
        $(this).siblings().removeClass("active");
        $(this).addClass("active");
        $(this).parent(".btn-group").attr("data-value", $(this).attr("data-value"));
    });

    $("#dateChooser>.btn").click(function(event){
        if($(this).attr("data-value") == "time"){
            $(".timeSpan").show();
        }else{
            $(".timeSpan").hide();
        }
    });

    // 时间选择控件
    $(".form_datetime").datetimepicker({
        format: "yy-mm-dd hh:ii",
        language:  'zh-CN',
        autoclose: true,
        todayBtn: true,
        todayHighlight: true,
        minView: 1
    });
	
    $(".form_date").datetimepicker({
        format: "yyyy-mm-dd",
        language:  'zh-CN',
        autoclose: true,
        todayBtn: true,
        todayHighlight: true,
        minView: 2
    });

    // 选择框、多选、单选、文件上传框装饰
    $('input[type=checkbox],input[type=radio],input[type=file]').uniform();
    $('select').select2();
});