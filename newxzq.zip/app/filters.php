<?php

/*
|--------------------------------------------------------------------------
| Application & Route Filters
|--------------------------------------------------------------------------
|
| Below you will find the "before" and "after" events for the application
| which may be used to do any work before or after a request into your
| application. Here you may also register your custom route filters.
|
*/
App::before(function($request)
{
});


App::after(function($request, $response)
{
});

/*
|--------------------------------------------------------------------------
| Authentication Filters
|--------------------------------------------------------------------------
|
| The following filters are used to verify that the user of the current
| session is logged into this application. The "basic" filter easily
| integrates HTTP Basic authentication for quick, simple checking.
|
*/
Route::filter('isLogin', function(){
	if (Sentry::check()){
	    return Redirect::route('admin.main');
	}
});
Route::filter('isNotLogin', function(){
	if (!Sentry::check()){
	    return Redirect::route('admin.index');
	}
});
Route::filter('auth', function($route, $request){
	// Get the current active/logged in user
	try{
	    $user = Sentry::getUser();
	}catch (Cartalyst\Sentry\Users\UserNotFoundException $e){
		Sentry::logout();
	    return Redirect::route('admin.index');
	}
	// get this route's name
	$route_name = $route->getName();
	// get this user's permissions
	$permissions = $user->getMergedPermissions();
	// whether this user has permission
	if (!array_key_exists($route_name, $permissions) || !$permissions[$route_name]) {
		return Redirect::route('admin.default')->withErrors(array('message' => '您无权访问该页！'));
	}
});
Route::filter('authAndMenu', function($route, $request){
	// Get the current active/logged in user
	try{
	    $user = Sentry::getUser();
	}catch (Cartalyst\Sentry\Users\UserNotFoundException $e){
		Sentry::logout();
	    return Redirect::route('admin.index');
	}
	// get this route's name
	$route_name = $route->getName();
	// get this user's permissions
	$permissions = $user->getMergedPermissions();
	// whether this user has permission
	if (!array_key_exists($route_name, $permissions) || !$permissions[$route_name]) {
		return Redirect::route('admin.default')->withErrors(array('message' => '您无权访问该页！'));
	}
	// get menus
	$menus = MenuHelper::getAuthorizedMenus($permissions, $route_name);
	View::share('menus', $menus);
	$user_arr = $user->toArray();
	View::share('currentUser', $user_arr['first_name']);
});

/*
|--------------------------------------------------------------------------
| CSRF Protection Filter
|--------------------------------------------------------------------------
|
| The CSRF filter is responsible for protecting your application against
| cross-site request forgery attacks. If this special token in a user
| session does not match the one given in this request, we'll bail.
|
*/
Route::filter('csrf', function()
{
	if (Session::token() !== Input::get('_token'))
	{
		throw new Illuminate\Session\TokenMismatchException;
	}
});

/*
|--------------------------------------------------------------------------
| Debug sql 
|--------------------------------------------------------------------------
|
*/
Route::filter('debugSQL', function()
{
	Event::listen('illuminate.query', function($sql) {
		var_dump($sql);
	});
});