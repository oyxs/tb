<?php
class MaterialLink extends BaseModel {

	// 数据表名
	protected $table = 'material_link';

	public static $cacheName = 'mlinkCache';
	
	protected $fillable = [
		'name',
		'link',
		'materialId',
		'enabled',
		'pname',
		'cmdLine',
		'remarks'
	];
	
	public static $rules = [
		'materialId' =>['required', 'integer'],
	    'name' => ['required','max:255','regex:/^[\w|\x{4e00}-\x{9fa5}|.()]+$/u'],
	    'link' => ['required','max:255'],
	    'enabled' => ['in:0,1'],
	    'pname' => ['max:255','regex:/^[\w|\x{4e00}-\x{9fa5}|.()]+$/u'],
	    'cmdLine' => ['max:255']
	];
	
	public function material(){
		return $this->hasOne('Material','id','materialId');
	}
	public function chargedata()
    {
        return $this->hasManyThrough('ChargeData', 'ChargeItems','mlinkId','chargeId');
    }
}