<?php
class ProductData extends BaseModel {

	// 数据表名
	protected $table = 'product_data';
	
	
	protected $fillable = [
		'day',
		'chargeId',
		'chargeData',
		'income'
	];
	
	public static $rules = array( 
		'day' => ['required','max:10'],
		'chargeId' => ['required', 'integer'], 
		'chargeData' => ['required', 'integer'], 
		'income' => ['required', 'integer']
	);
	
	public function productcharge(){
		return $this->hasOne("ProductCharge","id",'chargeId');
	}
	
}