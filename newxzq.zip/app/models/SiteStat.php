<?php
class SiteStat extends Eloquent {

	// 数据表名
	protected $table = 'site_stat';

	// 填充白名单
	protected $fillable = [
		'siteId', 
		'sourceId', 
		'open', 
		'one', 
		'two', 
		'three',
		'four',
	    	'error'
	];

	// 验证规则
	public static $rules = array(
		'siteId' => ['required', 'integer'], 
		'open' => ['required', 'integer'], 
		'one' => ['required', 'integer'], 
		'two' => ['required', 'integer'], 
		'three' => ['required', 'integer'],
		'four' => ['required', 'integer'],
	    'error' => ['required', 'integer']
	);

	public static function getList($siteId, $start, $end, $display = 'day') {
		// 查询
		$params = array('created_at','open','one','two','three','four','error');
		$stats = self::queryDb($start, $end, $siteId, $params);
		if(empty($stats)){
			return false;
		}

		// 按照时间处理
		$ostats = array();
		foreach ($stats as $value) {
			if($display == 'day') {
				$time = TimeHelper::getIntegralDay($value->created_at);
				$value->created_at = date('Y-m-d', $time);
			} else {
				$time = TimeHelper::getIntegralHour($value->created_at);
				$value->created_at = date('Y-m-d H:00', $time);
			}
			if(isset($ostats[$time])){
				$ostats[$time]->open += $value->open;
				$ostats[$time]->one += $value->one;
				$ostats[$time]->two += $value->two;
				$ostats[$time]->three += $value->three;
				$ostats[$time]->four += $value->four;
				$ostats[$time]->error += $value->error;
			} else {
				$ostats[$time] = $value;
			}
		}
		foreach ($ostats as $key => $value) {
			$ostats[$key]->rate = $value->open>0?round($value->four*100/$value->open).'%':0;
			$ostats[$key]->errrate = $value->open>0?round($value->error*100/$value->open).'%':0;
		}
		return $ostats;
	}

	private static function queryDb($start, $end, $siteId=0, 
		$params=array(), $groupby='', $orderby=array(), $leftjoin=array()) {
		try {
			$sqlBuilder = DB::table('site_stat');
			if(intval($siteId) != 0){
				$sqlBuilder = $sqlBuilder->where('siteId', '=', $siteId);
			}
			if($groupby != ''){
				$sqlBuilder = $sqlBuilder->groupBy($groupby);
			}
			if($leftjoin != array()){
				$sqlBuilder = $sqlBuilder->leftJoin($leftjoin);
			}
			if($orderby != array() && sizeof($orderby) == 2){
				$sqlBuilder = $sqlBuilder->orderBy($orderby[0], $orderby[1]);
			}
			$stats = $sqlBuilder->whereBetween('created_at', array($start, $end))->get($params);
		} catch (Exception $e) {
			return false;
		}
		return $stats;
	}
}
