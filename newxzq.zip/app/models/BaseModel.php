<?php
class BaseModel extends Eloquent {
	protected static $cache = array();

	public static function getNameById($id) {
		if(intval($id) <= 0){
			return false;
		}
		$isRefreshed = false;
		if(empty(static::$cache)){
			if(Cache::has(static::$cacheName)) {
				static::$cache = Cache::get(static::$cacheName);
			} else {
				static::refreshCache();
				$isRefreshed = true;
			}
		}
		if(!isset(static::$cache[$id])) {
			if(!$isRefreshed){
				static::refreshCache();
			}
			if(!isset(static::$cache[$id])) {
				return false;
			}
		}
		return static::$cache[$id]['name'];
	}

	protected static function refreshCache() {
		$materials = static::all();
		foreach ($materials as $key => $value) {
			static::$cache[$value['id']] = $value->toArray();
		}
		$expiresAt = Carbon::now()->addHours(3);
		Cache::put(static::$cacheName, static::$cache, $expiresAt);
	}
}