<?php

class NewAd extends Eloquent {
	protected $table = 'newads';

	// 填充白名单
	protected $fillable = [
			'name',
			'defCheck',
			'type',
			'link',
			'linkName',
			'showTime',
			'place',
			'img',
			'msg'
	];

	public static $rules = array(
			'name' => ['required'],
			'defCheck' => ['required', 'integer'],
			'type' => ['required'],
			'link' => ['required'],
			'linkName' => ['required'],
			'showTime' => ['required'],
			'place' => ['required', 'integer'],

	);
}