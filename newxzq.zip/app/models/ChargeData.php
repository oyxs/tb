<?php
class ChargeData extends BaseModel {

	// 数据表名
	protected $table = 'charge_data';
	
	
	protected $fillable = [
		'materialId',
		'day',
		'chargeId',
		'chargeData',
		'income'
	];
	
	public static $rules = array(
		'materialId' => ['required', 'integer'], 
		'day' => ['required','max:10'],
		'chargeId' => ['required', 'integer'], 
		'chargeData' => ['required', 'integer'], 
		'income' => ['required', 'integer']
	);
	
	public static function getList($materialId,$start,$end,$orderby=array('id','desc')){
		$params= array(
			"materialId" =>$materialId,
			"start" => $start,
			"end" => $end,
			"orderby" => $orderby
			
		);
		$data = self::queryDb($params);
		if(empty($data)){
			return false;
		}
		return $data;
	}
	
	public function chargeitems(){
		return $this->hasOne("ChargeItems","id",'ChargeId');
	}
	
	private static function queryDb($params=array()) {
		try {
			$sqlBuilder = DB::table('charge_data');
			if(isset($params['siteId']) && intval($params['siteId']) > 0){
				$sqlBuilder = $sqlBuilder->where('siteId', '=', $params['siteId']);
			}
			if(isset($params['materialId']) && intval($params['materialId']) > 0){
				$sqlBuilder = $sqlBuilder->where('materialId', '=', $params['materialId']);
			}
			if(isset($params['mlinkId']) && intval($params['mlinkId']) > 0){
				$sqlBuilder = $sqlBuilder->where('mlinkId', '=', $params['mlinkId']);
			}
			if(isset($params['chargeId']) && intval($params['chargeId']) > 0){
				$sqlBuilder = $sqlBuilder->where('chargeId', '=', $params['chargeId']);
			}
			if(isset($params['groupby']) && $params['groupby'] !=''){
				$sqlBuilder = $sqlBuilder->groupBy($params['groupby']);
			}
			if(isset($params['leftjoin']) && count($params['leftjoin']) > 0){
				$sqlBuilder = $sqlBuilder->leftJoin($params['leftjoin']);
			}
			if(isset($params['orderby']) && sizeof($params['orderby']) == 2){
				$sqlBuilder = $sqlBuilder->orderBy($params['orderby'][0], $params['orderby'][1]);
			}
			$stats = $sqlBuilder->whereBetween('day', array($params['start'], $params['end']))->get();
		} catch (Exception $e) {
			return false;
		}
		return $stats;
	}
}