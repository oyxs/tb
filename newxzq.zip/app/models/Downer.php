<?php
class Downer extends BaseModel {

	// 数据表名
	protected $table = 'downer';

	public static $cacheName = 'downerCache';

	// 填充白名单
	protected $fillable = [
		'name', 
		'path', 
		'size', 
		'content'
	];

	// 验证规则
	public static $rules = [
		'name'     => ['required','max:255','regex:/^[\w|\x{4e00}-\x{9fa5}|.()]+$/u'],
		'path'  => ['max:255'],
		'size'   => ['digits_between:0,10'],
	];
}