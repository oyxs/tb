<?php
class MaterialStat extends Eloquent {

	// 数据表名
	protected $table = 'material_stat';

	// 填充白名单
	protected $fillable = [
		'siteId', 
		'sourceId', 
		'materialId',
		'show', 
		'check', 
		'uncheck',
		'repeat',
		'ok',
		'error'
	];

	// 验证规则
	public static $rules = array(
		'siteId' => ['required', 'integer'], 
		'materialId' => ['required', 'integer'],
		'show' => ['required', 'integer'],
		'check' => ['required', 'integer'],
		'uncheck' => ['required', 'integer'],
		'repeat' => ['required', 'integer'],
		'ok' => ['required', 'integer'],
		'error' => ['required', 'integer']
	);

	public static function getList($siteId, $materialId, $start, $end, $display = 'day') {
		// 查询
		$params = array('created_at','show','check','uncheck','repeat','ok','error');
		$stats = self::queryDb($start, $end, $siteId, $materialId, $params);
		if(empty($stats)){
			return false;
		}
		// 按照时间处理
		$ostats = array();
		foreach ($stats as $value) {
			if($display == 'day') {
				$time = TimeHelper::getIntegralDay($value->created_at);
				$value->created_at = date('Y-m-d', $time);
			} else {
				$time = TimeHelper::getIntegralHour($value->created_at);
				$value->created_at = date('Y-m-d H:00', $time);
			}
			if(isset($ostats[$time])){
				$ostats[$time]->show += $value->show;
				$ostats[$time]->check += $value->check;
				$ostats[$time]->uncheck += $value->uncheck;
				$ostats[$time]->repeat += $value->repeat;
				$ostats[$time]->ok += $value->ok;
				$ostats[$time]->error += $value->error;
			} else {
				$ostats[$time] = $value;
			}
		}
		foreach ($ostats as $key => $value) {
			$ostats[$key]->checkrate = $value->show>0?round($value->check*100/$value->show).'%':0;
			$ostats[$key]->okrate = $value->show>0?round($value->ok*100/$value->show).'%':0;
		}
		return $ostats;
	}

	public static function getSumList($siteId, $materialId, $start, $end) {
		// 查询
		$params = array(
			'created_at',
			DB::raw('sum(`show`) as `show`'),
			DB::raw('sum(`check`) as `check`'),
			DB::raw('sum(`uncheck`) as `uncheck`'),
			DB::raw('sum(`repeat`) as `repeat`'),
			DB::raw('sum(`ok`) as `ok`'),
			DB::raw('sum(`error`) as `error`')
		);

		if($siteId == 0){
			$params[] = 'siteId';
			$stats = self::queryDb($start, $end, 0, $materialId, $params, 'siteId');
		} elseif($materialId == 0){
			$params[] = 'materialId';
			$stats = self::queryDb($start, $end, $siteId, 0, $params, 'materialId');
		} else {
			return false;
		}

		if(empty($stats)) {
			return false;
		}

		$ostats = array();
		foreach ($stats as $key => $value) {
			if($siteId == 0){
				$value->site = Site::getNameById($value->siteId);
			} else {
				$value->material = Material::getNameById($value->materialId);
			}
			$value->checkrate = $value->show>0?round($value->check*100/$value->show).'%':'0';
			$value->okrate = $value->show>0?round($value->ok*100/$value->show).'%':'0';
			$ostats[] = $value;
		}
		return $ostats;
	}

	//站点详细数据
	public static function getDetailList($siteId, $materialId, $start, $end) {
		$params = array(
			'materialId',
			DB::raw('left(created_at,10) as day'),
			DB::raw('sum(`show`) as `show`'),
			DB::raw('sum(`check`) as `check`'),
			DB::raw('sum(`ok`) as `ok`'),
		);
		if($materialId==0){
			$detail = DB::select("SELECT materialId, left(created_at,10) as day,sum(`show`) as `show`,sum(`check`) as `check`,sum(`ok`) as `ok` FROM down_material_stat WHERE siteId='$siteId' AND created_at between '$start' AND '$end' GROUP BY day,materialId ");
		}else{
			$detail = self::queryDb($start,$end,$siteId,$materialId,$params,'day');
		}
		if(empty($detail) || !is_array($detail)) {
			return false;
		}
		$data =array();
		foreach($detail as $val){
			$data[$val->day][$val->materialId]=$val;
		}
		
		return $data;
	}
	
	private static function queryDb($start, $end, $siteId=0,
		$materialId=0, $params=array(), $groupby='', $orderby=array(), $leftjoin=array()) {
		try {
			$sqlBuilder = DB::table('material_stat');
			if(intval($siteId) > 0){
				$sqlBuilder = $sqlBuilder->where('siteId', '=', $siteId);
			}
			if(intval($materialId) > 0){
				$sqlBuilder = $sqlBuilder->where('materialId', '=', $materialId);
			}
			if($groupby != ''){
				$sqlBuilder = $sqlBuilder->groupBy($groupby);
			}
			if($leftjoin != array()){
				$sqlBuilder = $sqlBuilder->leftJoin($leftjoin);
			}
			if($orderby != array() && sizeof($orderby) == 2){
				$sqlBuilder = $sqlBuilder->orderBy($orderby[0], $orderby[1]);
			}
			$stats = $sqlBuilder->whereBetween('created_at', array($start, $end))->get($params);
		} catch (Exception $e) {
			return false;
		}
		return $stats;
	}

}
