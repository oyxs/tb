<?php
use Illuminate\Database\Eloquent\SoftDeletingTrait;
class Site extends BaseModel {

	use SoftDeletingTrait;
	
	// 数据表名
	protected $table = 'site';
	
	//软删
    protected $dates = ['deleted_at'];

	public static $cacheName = 'siteCache';

	// 填充白名单
	protected $fillable = [
		'name', 
		'siteUrl', 
		'apiUrl', 
		'siteIcon', 
		'apiTag', 
		'userId',
		'search',
		'activated',
		'customArea',
	];

	// 验证规则
	public static $rules = [
		'name'     => ['required','max:255','regex:/^[\w|\x{4e00}-\x{9fa5}|.()]+$/u'],
		'siteUrl'  => ['url', 'max:255'],
		'siteIcon' => ['url', 'max:255'],
		'apiTag'   => ['max:16', 'regex:/^\w+$/u'],
		'userId'   => ['required', 'integer', 'min:1'],
		'search'   => ['url', 'max:255']
	];

	// 外键关联
	public function user() {
		return $this->hasOne('User', 'id', 'userId');
	}
}
