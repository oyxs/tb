<?php
class RelMaterialLink extends BaseModel {

	// 数据表名
	protected $table = 'rel_material_link';

	public static $cacheName = 'relateCache';
	public $timestamps = false;
	
	protected $fillable = [
		'siteId',
		'materialId',
		'mlinkId',
		'starttime',
		'endtime'
	];
	
	public static function preprocess($siteId,$content){
		$data=$mlinks=$oldrel=$newrel=array();
		$datetime=date("Y-m-d H:i:s");
		$rel = RelMaterialLink::with("mlink")->where('siteId',$siteId)->where('endtime',NULL)->get();
		foreach($rel as $val){
			$oldrel[$val->materialId]=json_decode($val,true);
		}
		$content=unserialize($content);
		foreach($content as $val){
			foreach($val as $v){
				$mlinks=array_merge($mlinks,$v);
			}
		}
		$mlinks=array_filter($mlinks);
		foreach($mlinks as $key=>$val){
			if(isset($oldrel[$val['id']])){
				if($oldrel[$val['id']]['mlink']['link']==$val['link']){
					unset($oldrel[$val['id']]);
					continue;
				}else{
					$data['close'][$oldrel[$val['id']]['id']]=$datetime;
					$data['create'][$val['id']]=$val;
				}
				unset($oldrel[$val['id']]);
			}else{
				$data['create'][$val['id']]=$val;
			}
		}
		foreach($oldrel as $key=>$val){
			$data['close'][$val['id']]=$datetime;
		}
		return $data;
	}
	
	public static function editpreprocess($siteId,$content){
		$data=$mlinks=$oldrel=$newrel=array();
		$datetime=date("Y-m-d H:i:s");
		$rel = RelMaterialLink::with("mlink")->where('siteId',$siteId)->where('endtime',NULL)->get();
		foreach($rel as $val){
			$oldrel[$val->materialId]=json_decode($val,true);
		}
		$content=unserialize($content);
		foreach($content as $val){
			foreach($val as $v){
				$mlinks=array_merge($mlinks,$v);
			}
		}
		$mlinks=array_filter($mlinks);
		foreach($mlinks as $key=>$val){
			if(isset($oldrel[$val['id']])){
				if(!isset($oldrel[$val['id']]['mlink'])){
					return false;
				}
				if($oldrel[$val['id']]['mlink']['link']==$val['link']){
					unset($oldrel[$val['id']]);
					continue;
				}else{
					$data['close'][$oldrel[$val['id']]['id']]=$datetime;
					$data['create'][$val['id']]=$val;
				}
				unset($oldrel[$val['id']]);
			}else{
				$data['create'][$val['id']]=$val;
			}
		}
		foreach($oldrel as $key=>$val){
			$data['close'][$val['id']]=$datetime;
		}
		return $data;
	}
	
	public function mlink(){
		return $this->hasOne('MaterialLink','id','mlinkId');
	}
}