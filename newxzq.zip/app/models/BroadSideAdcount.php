<?php
class BroadSideAdcount extends Eloquent {

    // 数据表名
    protected $table = 'broad_side_adcount';

    // 填充白名单
    protected $fillable = [
        'material_id',
        'click_1',
        'click_2',
        'click_3',
        'click_4',
        'click_5',
        'ip',
        'city_name',
        'material_id',
        'show_1',
        'show_2',
        'show_3',
        'show_4',
        'show_5',
        'time',
        'siteId'


    ];

    // 验证规则
    public static $rules = array(
        'materialId' => ['required', 'integer'],
    );

    public static function getList($siteId, $materialId, $start, $end) {
        $params = array(
            'create_time',
            'material_id',
            'click_1',
            'click_2',
            'click_3',
            'click_4',
            'click_5',
            'ip',
            'city_name',
            'show_1',
            'show_2',
            'show_3',
            'show_4',
            'show_5',
            'time',
            'siteId',
            DB::raw('sum(`show_1`) as `show_1`'),
            DB::raw('sum(`show_2`) as `show_2`'),
            DB::raw('sum(`show_3`) as `show_3`'),
            DB::raw('sum(`show_4`) as `show_4`'),
            DB::raw('sum(`show_5`) as `show_5`'),

            DB::raw('sum(`click_1`) as `click_1`'),
            DB::raw('sum(`click_2`) as `click_2`'),
            DB::raw('sum(`click_3`) as `click_3`'),
            DB::raw('sum(`click_4`) as `click_4`'),
            DB::raw('sum(`click_5`) as `click_5`'),



        );
        if($siteId == 0){
            $params[] = 'siteId';
            $stats = self::queryDb($start, $end, 0, $materialId, $params,'create_time');
        } elseif($materialId == 0){
            $params[] = 'material_id';
            $stats = self::queryDb($start, $end, $siteId, 0, $params, 'create_time');
        }elseif($materialId != 0&&$siteId!=0){
            //$params[] =array('siteId');
            $stats = self::queryDb($start, $end, $siteId, $materialId, $params, 'create_time');
        }
        else {
            return false;
        }


        if(empty($stats)) {
            return false;
        }




        $ostats = array();
        foreach ($stats as $key => $value) {
            /* if($siteId == 0){
                 $value->site = Site::getNameById($value->siteId);
             } else {
                 $value->material = Material::getNameById($value->materialId);
             }*/
            $value->show = $value->show_1;
            $value->click = $value->click_1+$value->click_2+$value->click_3+$value->click_4+$value->click_5;
            $value->clickrate1 = $value->show_1>0?round($value->click_1*100/$value->show_1).'%':'0';
            $value->clickrate2 = $value->show_2>0?round($value->click_2*100/$value->show_2).'%':'0';
            $value->clickrate3 = $value->show_3>0?round($value->click_3*100/$value->show_3).'%':'0';
            $value->clickrate4 = $value->show_4>0?round($value->click_4*100/$value->show_4).'%':'0';
            $value->clickrate5 = $value->show_5>0?round($value->click_5*100/$value->show_5).'%':'0';
            $ostats[] = $value;
        }
        return $ostats;
    }





    private static function queryDb($start, $end, $siteId=0,
                                    $materialId=0, $params=array(), $groupby='', $orderby=array(), $leftjoin=array()) {
        try {
            $sqlBuilder = DB::table('broad_side_adcount');
            if(intval($siteId) > 0){
                $sqlBuilder = $sqlBuilder->where('siteId', '=', $siteId);
            }

            if(intval($materialId) > 0){
                $sqlBuilder = $sqlBuilder->where('material_id', 'like','%'.$materialId.',%');
            }

            if($groupby != ''){
                $sqlBuilder = $sqlBuilder->groupBy($groupby);
            }
            if($leftjoin != array()){
                $sqlBuilder = $sqlBuilder->leftJoin($leftjoin);
            }
            if($orderby != array() && sizeof($orderby) == 2){
                $sqlBuilder = $sqlBuilder->orderBy($orderby[0], $orderby[1]);
            }

            $stats = $sqlBuilder->whereBetween('create_time', array($start, $end))->get($params);
        } catch (Exception $e) {

            echo $e->getMessage();
            return false;
        }
        return $stats;
    }

}
