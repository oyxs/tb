<?php
class Product extends BaseModel {

	// 数据表名
	protected $table = 'product';

	public static $cacheName = 'productCache';
	
	protected $fillable = [
		'name',
		'type',
	];
	
	public static $rules = [
	    'name' => ['required','max:255','regex:/^[\w|\x{4e00}-\x{9fa5}|.()]+$/u'],
	    'type' => ['required','max:255','regex:/^[\w|\x{4e00}-\x{9fa5}|.()]+$/u']
	];
	
	public function productdata()
    {
        return $this->hasManyThrough('ProductData', 'ProductCharge','productId','chargeId');
    }
}