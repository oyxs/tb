<?php
class ProductCharge extends BaseModel {

	// 数据表名
	protected $table = 'product_charge';

	public static $cacheName = 'productChargeCache';
	
	protected $fillable = [
		'item',
		'price',
		'productId',
	];
	
	public static $rules = [
		'item' => ['required','max:255'],
		'price' => ['required','integer']
	];
	
	public function product(){
		$this->hasOne('Product','id','productId');
	}
	
}