<?php
class TopAdCount extends Eloquent {

    // 数据表名
    protected $table = 'top_ad_count';

    // 填充白名单
    protected $fillable = [
        'material_id',
        'created_at',
        'ip',
        'city_name',
        'time',
        'show',
        'click',
    ];

    // 验证规则
    public static $rules = array(
        'materialId' => ['required', 'integer'],
    );

    public static function getList($siteId, $materialId, $start, $end) {
        $params = array(
            'created_at',
            'material_id',
            'create_time',
            'ip',
            'city_name',
            DB::raw('sum(`show`) as `show`'),
            DB::raw('sum(`click`) as `click`'),

        );
        if($siteId == 0){
            $params[] = 'siteId';
            $stats = self::queryDb($start, $end, 0, $materialId, $params,'create_time');
        } elseif($materialId == 0){
            $params[] = 'material_id';
            $stats = self::queryDb($start, $end, $siteId, 0, $params, ['create_time']);
        } elseif($siteId != 0&&$materialId != 0){
            $stats = self::queryDb($start, $end, $siteId, $materialId, $params, 'create_time');

        }else {
            return false;
        }


        if(empty($stats)) {
            return false;
        }



        $ostats = array();
        foreach ($stats as $key => $value) {
           /* if($siteId == 0){
                $value->site = Site::getNameById($value->siteId);
            } else {
                $value->material = Material::getNameById($value->materialId);
            }*/
            $value->clickrate = $value->show>0?round($value->click*100/$value->show).'%':'0';
            $ostats[] = $value;
        }

        return $ostats;
    }





    private static function queryDb($start, $end, $siteId=0,
                                    $materialId=0, $params=array(), $groupby='', $orderby=array(), $leftjoin=array()) {
        try {
            $sqlBuilder = DB::table('top_ad_count');
            if(intval($siteId) > 0){
                $sqlBuilder = $sqlBuilder->where('siteId', '=', $siteId);
            }
            if(intval($materialId) > 0){
                $sqlBuilder = $sqlBuilder->where('material_id', '=', $materialId);
            }

            if($groupby != ''){
                $sqlBuilder = $sqlBuilder->groupBy($groupby);
            }
            if($leftjoin != array()){
                $sqlBuilder = $sqlBuilder->leftJoin($leftjoin);
            }
            if($orderby != array() && sizeof($orderby) == 2){
                $sqlBuilder = $sqlBuilder->orderBy($orderby[0], $orderby[1]);
            }

            $stats = $sqlBuilder->whereBetween('create_time', array($start, $end))->get($params);
        } catch (Exception $e) {
            echo $e->getMessage();
            return false;
        }
        return $stats;
    }

}
