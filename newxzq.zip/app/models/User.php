<?php

class User extends Eloquent {
	protected $fillable = [];

	protected $table = 'users';

	// 验证规则
	public static $rules = [
		'email'     => ['required','email'],
		'password'  => ['required','min:6','max:16'],
		'password2'   => ['required','min:6','max:16','same:password'],
		'first_name' => ['required','regex:/^[\w|\x{4e00}-\x{9fa5}|.()]+$/u'],
		'group'   => ['required', 'integer']
	];
}