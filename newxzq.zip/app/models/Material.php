<?php
class Material extends BaseModel {

	// 数据表名
	protected $table = 'material';

	public static $cacheName = 'materialCache';

	// 填充白名单
	protected $fillable = [
		'name', 
		'type', 
		'silent', 
		'defCheck', 
		'tip', 
		'link',
		'savePath',
	    'rootKey',
	    'keyName',
	    'regExt',
	    'cmdLine',
	    'linkName',
	    'linkIcon',
		'logoUrl',
		'adminUrl',
		'userAndPwd',
		'contId',
		'enabled',
		'showTime',
		'place',
		'img',
	];

	// 验证规则
	public static $rules = array(
	    'name' => ['required','max:255','regex:/^[\w|\x{4e00}-\x{9fa5}|.()]+$/u'],
	    'type' => ['in:startpage,install,createlink,textlink,imglink,giflink,swflink'],
	    'silent' => ['required','in:0,1'],
	    'defCheck' => ['required','in:0,1'],
	    'tip' => ['max:255','regex:/^[\w|\x{4e00}-\x{9fa5}|.()]+$/u'],
	    'link' => ['max:255'],
	    'savePath' => ['max:255'],
	    'rootKey' => ['max:255'],
	    'keyName' => ['max:255'],
	    'regExt' => ['max:5','regex:/^[\w|.]+$/u'],
	    'cmdLine' => ['max:255'],
	    'linkName' => ['max:255'],
	    'linkIcon' => ['max:255'],
	    'logoUrl' => ['max:255'],
		'contId' => ['integer', 'min:0'],
		'enabled' => ['in:0,1'],
		'showTime' => ['max:20'],
		'place' => ['max:1'],
		'img' => ['max:255'],
	);
	
	public function materialCharge(){
		return $this->hasMany('MaterialCharge', 'materialId', 'id');
	}
}