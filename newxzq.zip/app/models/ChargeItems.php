<?php
use Illuminate\Database\Eloquent\SoftDeletingTrait;
class ChargeItems extends BaseModel {
	use SoftDeletingTrait;

	// 数据表名
	protected $table = 'charge_items';
	protected $dates = ['deleted_at'];

	public static $cacheName = 'chargeItemsCache';
	
	public $timestamps = false;
	
	protected $fillable = [
		'item',
		'price',
		'mlinkId',
		'create_time'
	];
	
	public static $rules = [
		'item' => ['required','max:255'],
		'price' => ['required','integer']
	];
	
}