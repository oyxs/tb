<?php
use Illuminate\Database\Eloquent\SoftDeletingTrait;
class AdCache extends Eloquent {

	use SoftDeletingTrait;
	
	// 数据表名
	protected $table = 'ad_cache';

	//软删
    protected $dates = ['deleted_at'];
	
	// 填充白名单
	protected $fillable = [
		'id',
		'content'
	];
}