<?php
class ChargeStat extends BaseModel {

	// 数据表名
	protected $table = 'charge_stat';
	
	
	protected $fillable = [
		'siteId',
		'materialId',
		'mlinkId',
		'day',
		'chargeId',
		'chargeData',
		'income'
	];
	
	public static $rules = array(
		'siteId' => ['required', 'integer'], 
		'materialId' => ['required', 'integer'], 
		'mlinkId' => ['required', 'integer'], 
		'day' => ['required','max:10'],
		'chargeId' => ['required', 'integer'], 
		'chargeData' => ['required', 'integer'], 
		'income' => ['required', 'integer']
	);
}