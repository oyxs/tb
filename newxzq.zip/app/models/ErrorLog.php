<?php
class ErrorLog extends Eloquent {

	// 数据表名
	protected $table = 'error_log';

	// 填充白名单
	protected $fillable = [
		'created_at',
		'updated_at',
		'ip', 
		'ver',
		'webid',
		'softid',
		'errcode',
		'winver'
	];

	// 验证规则
	public static $rules = array(
		'ip' => ['string'], 
		'ver' => ['string'], 
		'webid' => ['integer'], 
		'softid' => ['string'], 
		'errcode' => ['integer'],
		'winver' => ['string']
	);
}