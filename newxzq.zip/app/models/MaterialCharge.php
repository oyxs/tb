<?php
use Illuminate\Database\Eloquent\SoftDeletingTrait;
class MaterialCharge extends BaseModel {
	use SoftDeletingTrait;
	// 数据表名
	protected $table = 'material_charge';
	protected $dates = ['deleted_at'];
	public static $cacheName = 'materialChargeCache';
	
	protected $fillable = [
		'item',
		'price',
		'materialId',
	];
	
	public static $rules = [
		'item' => ['required','max:255'],
		'price' => ['required','integer']
	];
	
	public function material(){
		$this->hasOne('Materials','id','MaterialId');
	}
	
}