<?php
class Contract extends BaseModel {

	// 数据表名
	protected $table = 'contract';

	public static $cacheName = 'contractCache';
	
	protected $fillable = [
		'id',
		'start_at',
		'end_at'
	];
	
	public static $rules = [
		'id' => ['required','integer', 'min:2'],
		'start_at' => ['required','max:10'],
		'end_at' =>  ['required','max:10']
	];
	
	public function productdata()
    {
        return $this->hasManyThrough('ProductData', 'ProductCharge','productId','chargeId');
    }
}