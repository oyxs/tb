<?php

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;

class CheckCommand extends Command {

	/**
	 * The console command name.
	 *
	 * @var string
	 */
	protected $name = 'command:check';

	/**
	 * The console command description.
	 *
	 * @var string
	 */
	protected $description = 'Check  Downloader data interface AND update it!';

	/**
	 * Create a new command instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * Execute the console command.
	 *
	 * @return mixed
	 */
	public function fire()
	{
		$curl = APP::make('CurlHelper');
		$site = Site::all();
		foreach($site as $key=>$val){
			$apiUrl=unserialize($val->apiUrl);
			$num = count($apiUrl['checkUrl']);
			if($num>0){
				for($i=0;$i<$num;$i++){
					if(!empty($apiUrl['checkUrl'][$i])){
						$code=$curl->getHttpCode($apiUrl['checkUrl'][$i]);
						if($apiUrl['status'][$i]==0){
							if($code==200){
								continue;
							}else{
								$apiUrl['status'][$i]=1;
							}
						}else{
							if($code!=200){
								continue;
							}else{
								$apiUrl['status'][$i]=0;
							}
						}
						$site[$key]->apiUrl=serialize($apiUrl);
						$site[$key]->save();
						if(!Ad::cache(Ad::where('siteId',$val->id)->get()->toArray()[0])){
							Log::error("[CheckCommand]:���»���ʧ�ܣ�");
							exit();
						}
					}else{
						break;
					}
				}
			}
		}
	}

	/**
	 * Get the console command arguments.
	 *
	 * @return array
	 */
	protected function getArguments()
	{
		return array(
			// array('example', InputArgument::REQUIRED, 'An example argument.'),
		);
	}

	/**
	 * Get the console command options.
	 *
	 * @return array
	 */
	protected function getOptions()
	{
		return array(
			// array('example', null, InputOption::VALUE_OPTIONAL, 'An example option.', null),
		);
	}

}
