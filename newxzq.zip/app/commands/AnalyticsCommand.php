<?php
/**
 * @author zyx
 * @version 20150723
 */

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;

class AnalyticsCommand extends Command {

	/**
	 * The console command name.
	 *
	 * @var string
	 */
	protected $name = 'command:analytics';

	/**
	 * The console command description.
	 *
	 * @var string
	 */
	protected $description = 'Analytics downloader\'s access logs!';

	/**
	 * Create a new command instance.
	 *
	 * @return void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Laravel 命令的入口函数.
	 * @return mixed
	 */
	public function fire() {
		// 日志路径
		$dir = Config::get('path.ACCESS_LOG_PATH') . '/' . date("Ymd");
		$access_name = $dir . '/access_' . date("YmdH") . '.log';
		if(!file_exists($access_name) || 0 == filesize($access_name)){
			Log::error("[AnalyticsCommand]:日志不存在或为空！");
			exit(0);
		}

		// 解析日志文件
		$logObj = new LogHelper();
		$logObj->parseAccess($access_name);
		$site_data = $logObj->site_stat;
		$material_data = $logObj->material_stat;

		// 解析失败
		if(empty($site_data) || empty($material_data)){
			Log::error("[AnalyticsCommand]:解析日志失败！");
			exit(0);
		}

		$siteids = array_pluck(Site::where('activated',1)->get(),'id');
		// 站点数据入库
		foreach ($site_data as $k => $v) {
			// 整合站点概况并入库
			$arr=explode('_',$k);
			if(in_array($arr[0],$siteids)) {
				continue;
			}
			$v['siteId'] = $arr[0];
			$v['sourceId'] = $arr[1];
			SiteStat::create($v);
			unset($arr);
		}

		// 物料数据入库
		foreach ($material_data as $webid => $list) {
			$arr=explode('_',$webid);
			if(in_array($arr[0],$siteids)) {
				continue;
			}
			foreach ($list as $mid => $v) {
				$v['siteId'] = $arr[0];
				$v['sourceId'] = $arr[1];
				$v['materialId'] = $mid;
				MaterialStat::create($v);
			}
			unset($arr);
		}
		Log::info("[AnalyticsCommand]:解析日志成功！");	
	}

	/**
	 * Get the console command arguments.
	 *
	 * @return array
	 */
	protected function getArguments() {
		return array(
			//array('log_name', InputArgument::OPTIONAL),
		);
	}

	/**
	 * Get the console command options.
	 *
	 * @return array
	 */
	protected function getOptions() {
		return array(
			//array('log_name', null, InputOption::VALUE_OPTIONAL, 'Analytics log name.', null),
		);
	}

}
