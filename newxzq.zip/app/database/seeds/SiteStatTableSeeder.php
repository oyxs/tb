<?php
class SiteStatTableSeeder extends Seeder {

	public function run()
	{
		DB::table('site_stat')->delete();
		foreach(range(1, 10) as $index)
		{
			SiteStat::create([
				'siteId' => 3,
				'created_at' => mktime($index,0,0),
				'open' => rand(0,getrandmax()),
				'one' => rand(0,getrandmax()),
				'two' => rand(0,getrandmax()),
				'three' => rand(0,getrandmax()),
				'four' => rand(0,getrandmax()),
			    'success' => rand(0,getrandmax())
			]);
		}
	}

}