<?php
class MaterialStatTableSeeder extends Seeder {

	public function run()
	{
		DB::table('material_stat')->delete();
		foreach(range(1, 10) as $index)
		{
			MaterialStat::create([
				'siteId' => 3, 
				'materialId' => 1, 
				'created_at' => mktime($index,0,0),
				'show' => rand(0,getrandmax()), 
				'check' => rand(0,getrandmax()),
				'uncheck' => rand(0,getrandmax()),
				'repeat' => rand(0,getrandmax())
				'ok' => rand(0,getrandmax()),
				'error' => rand(0,getrandmax()),
			    
			]);
		}
	}

}