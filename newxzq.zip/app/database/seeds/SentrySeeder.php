<?php
class SentrySeeder extends Seeder {
//  /app/cofig/menu.php        /app/routes.php         php artisan db:seed
	public function run()
	{
		DB::table('users')->delete();
		DB::table('groups')->delete();
		DB::table('users_groups')->delete();
 
		Sentry::getGroupProvider()->create(array(
			'name'        => '管理员',
			'permissions' => [
				'admin' => 1,
				'admin.main' => 1,
				'admin.default' => 1,
				'admin.password' => 1,
				'admin.chpsw' => 1,
				'admin.ad' => 1,
				'admin.ad.index' => 1,
				'admin.ad.create' => 1,
				'admin.ad.store' => 1,
				'admin.ad.destroy' => 1,
				'admin.ad.edit' => 1,
				'admin.ad.update' => 1,
				'admin.ad.refresh' => 1,
				'admin.newad' => 1,
				'admin.newad.index' => 1,
				'admin.newad.create' => 1,
				'admin.newad.store' => 1,
				'admin.newad.destroy' => 1,
				'admin.newad.edit' => 1,
				'admin.newad.update' => 1,
				'admin.newad.refresh' => 1,
				'admin.material' => 1,
				'admin.material.index' => 1,
				'admin.material.create' => 1,
				'admin.material.store' => 1,
				'admin.material.destroy' => 1,
				'admin.material.edit' => 1,
				'admin.material.update' => 1,
				'admin.site' => 1,
				'admin.site.index' => 1,
				'admin.site.create' => 1,
				'admin.site.store' => 1,
				'admin.site.destroy' => 1,
				'admin.site.edit' => 1,
				'admin.site.update' => 1,
				'admin.downer' => 1,
				'admin.downer.index' => 1,
				'admin.downer.create' => 1,
				'admin.downer.store' => 1,
				'admin.downer.destroy' => 1,
				'admin.downer.edit' => 1,
				'admin.downer.update' => 1,
				'admin.stat' => 1,
				'admin.stat.site' => 1,
				'admin.stat.material' => 1,
				'admin.stat.newmaterial' => 1,
				'admin.stat.broadsidematerial' => 1,
				'admin.stat.materialSum' => 1,
				'admin.stat.siteSum' => 1,
				'admin.stat.data' => 1,
				'admin.stat.topdata' => 1,
				'admin.stat.broadsidedata' => 1,

				'admin.user' => 1,
				'admin.user.index' => 1,
				'admin.user.create' => 1,
				'admin.user.store' => 1,
				'admin.user.destroy' => 1,
				'admin.user.edit' => 1,
				'admin.user.update' => 1,
				'admin.user.resetpsw' => 1
			],
		));

		/*Sentry::getGroupProvider()->create(array(
			'name'        => '合作站点',
			'permissions' => [
				'admin' => 1,
				'admin.main' => 1,
				'admin.default' => 1,
				'admin.stat' => 1,
				'admin.stat.site' => 1,
				'admin.stat.material' => 1,
				'admin.password' => 1,
				'admin.chpsw' => 1
			],
		));*/

		Sentry::getUserProvider()->create(array(
			'email'      => 'liadmin@qq.com',
			'password'   => "lijieadmin",
			'first_name' => '李杰',
			'last_name'  => '',
			'activated'  => 1,
		));

		/*Sentry::getUserProvider()->create(array(
			'email'      => 'zyx8869@qq.com',
			'password'   => "123456",
			'first_name' => 'pconline',
			'last_name'  => '',
			'activated'  => 1,
		));*/
 
		// 将用户加入用户组
		$adminUser  = Sentry::getUserProvider()->findByLogin('liadmin@qq.com');
		$adminGroup = Sentry::getGroupProvider()->findByName('管理员');
		$adminUser->addGroup($adminGroup);
		/*$adminUser  = Sentry::getUserProvider()->findByLogin('zyx8869@qq.com');
		$adminGroup = Sentry::getGroupProvider()->findByName('合作站点');
		$adminUser->addGroup($adminGroup);*/
	}
}