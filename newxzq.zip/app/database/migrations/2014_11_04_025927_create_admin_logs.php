<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
/*
	-- -----------------------------------------------------
	-- Table `downloader`.`pb_admin_logs`
	-- -----------------------------------------------------
	CREATE TABLE IF NOT EXISTS `downloader`.`pb_admin_logs` (
	  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	  `adminId` INT UNSIGNED NOT NULL,
	  `time` TIMESTAMP NOT NULL,
	  `url` VARCHAR(255) NOT NULL,
	  `msg` VARCHAR(255) NULL,
	  `data` VARCHAR(500) NULL,
	  PRIMARY KEY (`id`))
	ENGINE = InnoDB;
*/
class CreateAdminLogs extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		if (Schema::hasTable('admin_logs'))
		{
			Schema::drop('admin_logs');
		}
		Schema::create('admin_logs', function(Blueprint $table)
		{
			$table->engine = 'InnoDB';
			$table->increments('id')->unsigned();
			$table->integer('adminId')->unsigned();
			$table->nullableTimestamps();
			$table->string('url', 255);
			$table->string('msg', 255)->nullable();
			$table->string('data', 500)->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('admin_logs');
	}

}
