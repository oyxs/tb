<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
/*
	-- -----------------------------------------------------
	-- Table `downloader`.`pb_material_stat`
	-- -----------------------------------------------------
	CREATE TABLE IF NOT EXISTS `downloader`.`pb_material_stat` (
	  `id` INT NOT NULL AUTO_INCREMENT,
	  `siteId` INT UNSIGNED NOT NULL,
	  `materialId` INT UNSIGNED NOT NULL,
	  `time` TIMESTAMP NOT NULL,
	  `show` INT UNSIGNED NOT NULL,
	  `check` INT UNSIGNED NOT NULL,
	  `success` INT UNSIGNED NOT NULL,
	  `fail` INT UNSIGNED NOT NULL,
	  `repeat` INT UNSIGNED NOT NULL,
	  PRIMARY KEY (`id`))
	ENGINE = InnoDB;
*/
class CreateMaterialStat extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		if (Schema::hasTable('material_stat'))
		{
			Schema::drop('material_stat');
		}
		Schema::create('material_stat', function(Blueprint $table)
		{
			$table->engine = 'InnoDB';
			$table->increments('id')->unsigned();
			$table->integer('siteId')->unsigned();
			$table->integer('materialId')->unsigned();
			$table->nullableTimestamps();
			$table->integer('show')->unsigned();
			$table->integer('check')->unsigned();
			$table->integer('uncheck')->unsigned();
			$table->integer('repeat')->unsigned();
			$table->integer('ok')->unsigned();
			$table->integer('error')->unsigned();
			
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('material_stat');
	}

}
