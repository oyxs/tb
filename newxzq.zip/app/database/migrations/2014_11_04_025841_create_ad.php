<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

/*
	-- -----------------------------------------------------
	-- Table `downloader`.`pb_ad`
	-- -----------------------------------------------------
	CREATE TABLE IF NOT EXISTS `downloader`.`pb_ad` (
	  `id` INT NOT NULL AUTO_INCREMENT,
	  `siteId` INT NOT NULL,
	  `downVersion` VARCHAR(45) NOT NULL,
	  `content` TEXT NOT NULL,
	  `createTime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	  `updateTime` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
	  `isPost` BIT NOT NULL DEFAULT 0,
	  PRIMARY KEY (`id`))
	ENGINE = InnoDB;
*/
class CreateAd extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		if (Schema::hasTable('ad'))
		{
			Schema::drop('ad');
		}
		Schema::create('ad', function(Blueprint $table)
		{
			$table->engine = 'InnoDB';
			$table->increments('id')->unsigned();
			$table->integer('siteId')->unsigned();
			$table->string('downVersion', 45);
			$table->string('template', 45);
			$table->text('content');
			$table->nullableTimestamps();
			$table->boolean('isPost');
			$table->unique('siteId');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('ad');
	}

}
