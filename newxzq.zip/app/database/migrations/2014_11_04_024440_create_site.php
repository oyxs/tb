<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

/*
	-- -----------------------------------------------------
	-- Table `downloader`.`pb_site`
	-- -----------------------------------------------------
	CREATE TABLE IF NOT EXISTS `downloader`.`pb_site` (
	  `id` INT NOT NULL,
	  `name` VARCHAR(255) NOT NULL,
	  `siteUrl` VARCHAR(255) NULL,
	  `apiUrl` VARCHAR(255) NOT NULL,
	  `siteIcon` VARCHAR(255) NOT NULL,
	  `apiTag` CHAR(16) NOT NULL,
	  `userId` INTEGER NOT NULL,
	  PRIMARY KEY (`id`))
	ENGINE = InnoDB;
*/
class CreateSite extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		if (Schema::hasTable('site'))
		{
			Schema::drop('site');
		}
		Schema::create('site', function(Blueprint $table)
		{
			$table->engine = 'InnoDB';
			$table->increments('id')->unsigned();
			$table->string('name', 255);
			$table->nullableTimestamps();
			$table->string('siteUrl', 255)->nullable();
			$table->string('apiUrl', 255);
			$table->string('siteIcon', 255)->nullable();
			$table->char('apiTag', 16)->nullable();
			$table->integer('userId')->unsigned();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('site');
	}

}
