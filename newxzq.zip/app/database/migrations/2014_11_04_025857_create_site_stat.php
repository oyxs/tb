<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

/*
	-- -----------------------------------------------------
	-- Table `downloader`.`pb_site_stat`
	-- -----------------------------------------------------
	CREATE TABLE IF NOT EXISTS `downloader`.`pb_site_stat` (
	  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	  `siteId` INT UNSIGNED NOT NULL,
	  `time` TIMESTAMP NOT NULL,
	  `open` INT UNSIGNED NOT NULL,
	  `one` INT UNSIGNED NOT NULL,
	  `two` INT UNSIGNED NOT NULL,
	  `three` INT UNSIGNED NOT NULL,
	  `four` INT UNSIGNED NOT NULL,
	  `success` INT UNSIGNED NOT NULL,
	  PRIMARY KEY (`id`))
	ENGINE = InnoDB;
*/
class CreateSiteStat extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		if (Schema::hasTable('site_stat'))
		{
			Schema::drop('site_stat');
		}
		Schema::create('site_stat', function(Blueprint $table)
		{
			$table->engine = 'InnoDB';
			$table->increments('id')->unsigned();
			$table->integer('siteId')->unsigned();
			$table->nullableTimestamps();
			$table->integer('open')->unsigned();
			$table->integer('one')->unsigned();
			$table->integer('two')->unsigned();
			$table->integer('three')->unsigned();
			$table->integer('four')->unsigned();
			$table->integer('error')->unsigned();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('site_stat');
	}

}
