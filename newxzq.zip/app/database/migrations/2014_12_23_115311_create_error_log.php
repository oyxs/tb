<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateErrorLog extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		if (Schema::hasTable('error_log'))
		{
			Schema::drop('error_log');
		}
		Schema::create('error_log', function(Blueprint $table)
		{
			$table->engine = 'InnoDB';
			$table->increments('id')->unsigned();
			$table->nullableTimestamps();
			$table->string('ip', 15)->nullable();
			$table->string('ver', 10)->nullable();
			$table->integer('webid')->unsigned()->nullable();
			$table->string('softid', 20)->nullable();
			$table->integer('errcode')->unsigned()->nullable();
			$table->string('winver', 10)->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('error_log');
	}

}
