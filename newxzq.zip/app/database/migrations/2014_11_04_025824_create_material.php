<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

/*
	-- -----------------------------------------------------
	-- Table `downloader`.`pb_material`
	-- -----------------------------------------------------
	CREATE TABLE IF NOT EXISTS `downloader`.`pb_material` (
	  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	  `name` VARCHAR(255) NOT NULL,
	  `type` ENUM('startpage','install','createlink') NOT NULL,
	  `createTime` TIMESTAMP NOT NULL,
	  `updateTime` TIMESTAMP NULL,
	  `silent` BIT NOT NULL DEFAULT 0,
	  `tip` VARCHAR(255) NULL,
	  `defCheck` BIT NOT NULL DEFAULT 1,
	  `link` VARCHAR(255) NOT NULL,
	  `savePath` VARCHAR(255) NULL,
	  `rootKey` VARCHAR(255) NULL,
	  `keyName` VARCHAR(255) NULL,
	  `regExt` CHAR(5) NULL,
	  `cmdLine` VARCHAR(255) NULL,
	  `linkName` VARCHAR(255) NULL,
	  `linkIcon` VARCHAR(255) NULL,
	  UNIQUE INDEX `name_UNIQUE` (`name` ASC),
	  PRIMARY KEY (`id`))
	ENGINE = InnoDB;
*/
class CreateMaterial extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		if (Schema::hasTable('material'))
		{
			Schema::drop('material');
		}
		Schema::create('material', function(Blueprint $table)
		{
			$table->engine = 'InnoDB';
			$table->increments('id')->unsigned();
			$table->string('name', 255);
			$table->enum('type', array('startpage','install','createlink'));
			$table->nullableTimestamps();
			$table->boolean('silent');
			$table->string('tip', 255)->nullable();
			$table->boolean('defCheck');
			$table->string('link', 255);
			$table->string('savePath', 255)->nullable();
			$table->string('rootKey', 255)->nullable();
			$table->string('keyName', 255)->nullable();
			$table->char('regExt', 5)->nullable();
			$table->string('cmdLine', 255)->nullable();
			$table->string('linkName', 255)->nullable();
			$table->string('linkIcon', 255)->nullable();
			$table->unique('name');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('material');
	}

}
