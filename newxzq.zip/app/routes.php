<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
*/
Route::get('/', array(
	'as' => 'admin.index',
	'uses' => 'PassportController@index',
	'before' => 'isLogin'
));
Route::get('/login', array(
	'as' => 'admin.login',
	'uses' => 'PassportController@login',
	'before' => 'isLogin'
));
Route::get('/logout', array(
	'as' => 'admin.logout', 
	'uses' => 'PassportController@logout'
));
Route::get('/index', array(
	'as' => 'admin.main',
	'uses' => 'PassportController@main',
	'before' => 'isNotLogin|authAndMenu'
));
Route::get('/default', array(
	'as' => 'admin.default',
	'uses' => 'PassportController@def',
	'before' => 'isNotLogin|auth'
));
Route::get('/password', array(
	'as' => 'admin.password',
	'uses' => 'PassportController@password',
	'before' => 'isNotLogin|auth'
));
Route::post('/password', array(
	'as' => 'admin.chpsw',
	'uses' => 'PassportController@chpsw',
	'before' => 'isNotLogin|auth'
));


/*
|--------------------------------------------------------------------------
| Ad Routes
|--------------------------------------------------------------------------
*/
Route::get('/ad', array(
	'as' => 'admin.ad.index',
	'uses' => 'AdsController@index'
));
Route::get('/ad/create', array(
	'as' => 'admin.ad.create',
	'uses' => 'AdsController@create'
));
Route::post('/ad', array(
	'as' => 'admin.ad.store',
	'uses' => 'AdsController@store'
));
Route::get('/ad/{id}/edit', array(
	'as' => 'admin.ad.edit',
	'uses' => 'AdsController@edit'
));
Route::post('/ad/{id}', array(
	'as' => 'admin.ad.update',
	'uses' => 'AdsController@update'
));
Route::get('/ad/{id}/destroy', array(
	'as' => 'admin.ad.destroy',
	'uses' => 'AdsController@destroy'
));
Route::get('/ad/{id}/refresh', array(
	'as' => 'admin.ad.refresh',
	'uses' => 'AdsController@refresh'
));

/*
|--------------------------------------------------------------------------
| NewAd Routes
|--------------------------------------------------------------------------
*/
Route::get('/newad', array(
		'as' => 'admin.newad.index',
		'uses' => 'NewAdController@index'
));

Route::get('/newad/{id}/enabled', array(
		'as' => 'admin.newad.enabled',
		'uses' => 'NewAdController@enabled'
));

Route::get('/newad/product', array(
		'as' => 'admin.newad.product',
		'uses' => 'NewAdController@product'
));

Route::get('/newad/create', array(
		'as' => 'admin.newad.create',
		'uses' => 'NewAdController@create'
));

Route::get('/newad/createproduct', array(
		'as' => 'admin.newad.createproduct',
		'uses' => 'NewAdController@createProduct'
));

Route::post('/newad', array(
		'as' => 'admin.newad.store',
		'uses' => 'NewAdController@store'
));

Route::post('/newad/add', array(
		'as' => 'admin.newad.add',
		'uses' => 'NewAdController@add'
));

Route::get('/newad/{id}/edit', array(
		'as' => 'admin.newad.edit',
		'uses' => 'NewAdController@edit'
));

Route::get('/newad/{id}/editproduct', array(
		'as' => 'admin.newad.editproduct',
		'uses' => 'NewAdController@editproduct'
));

Route::post('/newad/{id}', array(
		'as' => 'admin.newad.update',
		'uses' => 'NewAdController@update'
));

Route::post('/newad/{id}/updateproduct', array(
		'as' => 'admin.newad.updateproduct',
		'uses' => 'NewAdController@updateproduct'
));

Route::get('/newad/{id}/info', array(
		'as' => 'admin.newad.info',
		'uses' => 'NewAdController@info'
));

Route::get('/newad/{id}/destroy', array(
		'as' => 'admin.newad.destroy',
		'uses' => 'NewAdController@destroy'
));
/*
|--------------------------------------------------------------------------
| Material Routes
|--------------------------------------------------------------------------
*/
Route::get('/material', array(
	'as' => 'admin.material.index',
	'uses' => 'MaterialsController@index'
));

Route::get('/material/{id}/enabled', array(
	'as' => 'admin.material.enabled',
	'uses' => 'MaterialsController@enabled'
));

Route::get('/material/product', array(
	'as' => 'admin.material.product',
	'uses' => 'MaterialsController@product'
));

Route::get('/material/create', array(
	'as' => 'admin.material.create',
	'uses' => 'MaterialsController@create'
));

Route::get('/material/createproduct', array(
	'as' => 'admin.material.createproduct',
	'uses' => 'MaterialsController@createProduct'
));

Route::post('/material', array(
	'as' => 'admin.material.store',
	'uses' => 'MaterialsController@store'
));

Route::post('/material/add', array(
	'as' => 'admin.material.add',
	'uses' => 'MaterialsController@add'
));

Route::get('/material/{id}/edit', array(
	'as' => 'admin.material.edit',
	'uses' => 'MaterialsController@edit'
));

Route::get('/material/{id}/editproduct', array(
	'as' => 'admin.material.editproduct',
	'uses' => 'MaterialsController@editproduct'
));

Route::post('/material/{id}', array(
	'as' => 'admin.material.update',
	'uses' => 'MaterialsController@update'
));

Route::post('/material/{id}/updateproduct', array(
	'as' => 'admin.material.updateproduct',
	'uses' => 'MaterialsController@updateproduct'
));

Route::get('/material/{id}/info', array(
	'as' => 'admin.material.info',
	'uses' => 'MaterialsController@info'
));

Route::get('/material/{id}/destroy', array(
	'as' => 'admin.material.destroy',
	'uses' => 'MaterialsController@destroy'
));


/*
|--------------------------------------------------------------------------
| Material_LINK Routes
|--------------------------------------------------------------------------
*/

Route::get('/link/{id}/index', array(
	'as' => 'admin.link.index',
	'uses' => 'LinksController@index'
));

Route::get('/link/{id}/create', array(
	'as' => 'admin.link.create',
	'uses' => 'LinksController@create'
));

Route::get('/link/{id}/edit', array(
	'as' => 'admin.link.edit',
	'uses' => 'LinksController@edit'
));

Route::post('/link/{id}', array(
	'as' => 'admin.link.update',
	'uses' => 'LinksController@update'
));

Route::get('/link/{id}/enabled', array(
	'as' => 'admin.link.enabled',
	'uses' => 'LinksController@enabled'
));

Route::post('/link', array(
	'as' => 'admin.link.store',
	'uses' => 'LinksController@store'
));
Route::get('/link/{id}/destroy', array(
	'as' => 'admin.link.destroy',
	'uses' => 'LinksController@destroy'
));

/*
|--------------------------------------------------------------------------
| Site Routes
|--------------------------------------------------------------------------
*/
Route::get('/site', array(
	'as' => 'admin.site.index',
	'uses' => 'SitesController@index'
));
Route::get('/site/create', array(
	'as' => 'admin.site.create',
	'uses' => 'SitesController@create'
));
Route::post('/site', array(
	'as' => 'admin.site.store',
	'uses' => 'SitesController@store'
));
Route::get('/site/{id}/edit', array(
	'as' => 'admin.site.edit',
	'uses' => 'SitesController@edit'
));

Route::get('/site/batchextra', [
        'as' => 'admin.site.batchextra',
        'uses' => 'SitesController@batchextra',
] );
Route::post('/site/updbatch', [
        'as' => 'admin.site.updbatch',
        'uses' => 'SitesController@updbatch',
] );

Route::post('/site/{id}', array(
	'as' => 'admin.site.update',
	'uses' => 'SitesController@update'
));

Route::get('/site/{id}/destroy', array(
	'as' => 'admin.site.destroy',
	'uses' => 'SitesController@destroy'
));

/*
|--------------------------------------------------------------------------
| Charger Routes
|--------------------------------------------------------------------------
*/

Route::get('/charge/material', array(
	'as' => 'admin.charge.material',
	'uses' => 'ChargeController@material'
));
Route::get('/charge/site', array(
	'as' => 'admin.charge.site',
	'uses' => 'ChargeController@site'
));
Route::get('/charge/add', array(
	'as' => 'admin.charge.add',
	'uses' => 'ChargeController@add'
));
Route::any('/charge/data', array(
	'as' => 'admin.charge.data',
	'uses' => 'ChargeController@data'
));
Route::any('/charge/mouthlist', array(
	'as' => 'admin.charge.mouthlist',
	'uses' => 'ChargeController@mouthlist'
));
Route::any('/charge/store', array(
	'as' => 'admin.charge.store',
	'uses' => 'ChargeController@store'
));
Route::any('/charge/update', array(
	'as' => 'admin.charge.update',
	'uses' => 'ChargeController@update'
));

Route::get('/chargestat/index', array(
	'as' => 'admin.charge.chargestat',
	'uses' => 'ChargeStatController@index'
));
Route::any('/chargestat/data', array(
	'as' => 'admin.charge.chargedata',
	'uses' => 'ChargeStatController@data'
));

/*
|--------------------------------------------------------------------------
| Downer Routes
|--------------------------------------------------------------------------
*/
Route::get('/downer', array(
	'as' => 'admin.downer.index',
	'uses' => 'DownerController@index'
));
Route::get('/downer/create', array(
	'as' => 'admin.downer.create',
	'uses' => 'DownerController@create'
));
Route::post('/downer', array(
	'as' => 'admin.downer.store',
	'uses' => 'DownerController@store'
));
Route::get('/downer/{id}/edit', array(
	'as' => 'admin.downer.edit',
	'uses' => 'DownerController@edit'
));
Route::post('/downer/{id}', array(
	'as' => 'admin.downer.update',
	'uses' => 'DownerController@update'
));
Route::get('/downer/{id}/destroy', array(
	'as' => 'admin.downer.destroy',
	'uses' => 'DownerController@destroy'
));

/*
|--------------------------------------------------------------------------
| User Routes
|--------------------------------------------------------------------------
*/
Route::get('/stat/site', array(
	'as' => 'admin.stat.site',
	'uses' => 'StatController@site'
));
Route::get('/stat/material', array(
	'as' => 'admin.stat.material',
	'uses' => 'StatController@material'
));
Route::get('/stat/newmaterial', array(
		'as' => 'admin.stat.newmaterial',
		'uses' => 'StatController@newmaterial'
));
Route::get('/stat/broadsidematerial', array(
		'as' => 'admin.stat.broadsidematerial',
		'uses' => 'StatController@broadsidematerial'
));

Route::get('/stat/materialsum', array(
	'as' => 'admin.stat.materialSum',
	'uses' => 'StatController@materialSum'
));
Route::get('/stat/sitesum', array(
	'as' => 'admin.stat.siteSum',
	'uses' => 'StatController@siteSum'
));
Route::any('/stat/data', array(
	//'before' => 'debugSQL',
	'as' => 'admin.stat.data',
	'uses' => 'StatController@data'
));
Route::any('/stat/topdata', array(
	//'before' => 'debugSQL',
		'as' => 'admin.stat.topdata',
		'uses' => 'StatController@topdata'
));
Route::any('/stat/broadsidedata', array(
	//'before' => 'debugSQL',
		'as' => 'admin.stat.broadsidedata',
		'uses' => 'StatController@broadsidedata'
));

Route::get('/sitestat/site', array(
	'as' => 'admin.stat.sitesite',
	'uses' => 'SiteStatController@site'
));
Route::get('/sitestat/material', array(
	'as' => 'admin.stat.sitematerial',
	'uses' => 'SiteStatController@material'
));
Route::any('/sitestat/data', array(
	'as' => 'admin.stat.sitedata',
	'uses' => 'SiteStatController@data'
));

/*
|--------------------------------------------------------------------------
| User Routes
|--------------------------------------------------------------------------
*/
Route::get('/user', array(
	'as' => 'admin.user.index',
	'uses' => 'UserController@index'
));
Route::get('/user/create', array(
	'as' => 'admin.user.create',
	'uses' => 'UserController@create'
));
Route::post('/user', array(
	'as' => 'admin.user.store',
	'uses' => 'UserController@store'
));
Route::get('/user/{id}/edit', array(
	'as' => 'admin.user.edit',
	'uses' => 'UserController@edit'
));
Route::post('/user/{id}', array(
	'as' => 'admin.user.update',
	'uses' => 'UserController@update'
));
Route::get('/user/{id}/destroy', array(
	'as' => 'admin.user.destroy',
	'uses' => 'UserController@destroy'
));
Route::get('/user/{id}/resetpsw', array(
	'as' => 'admin.user.resetpsw',
	'uses' => 'UserController@resetpsw'
));


/*
|--------------------------------------------------------------------------
| Upload Routes
|--------------------------------------------------------------------------
*/
Route::post('/upload/icon', array(
	'as' => 'admin.upload.icon',
	'uses' => 'UploadController@icon',
	'before' => 'isNotLogin'
));
