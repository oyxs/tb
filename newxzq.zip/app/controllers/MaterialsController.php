<?php

class MaterialsController extends BaseController {

	/**
	 * Display a listing of materials
	 *
	 * @return Response
	 */
	public function index() {
		$materials = Material::where('place','=','0')->get();
		return View::make('materials.index')->with('materials', $materials);
	}
	
	public function info($id) {
		$data['materials'] = Material::get();
		$data['material'] = Material::with('materialCharge')->find($id);
		if($data['material']['contId']>=2){
			$data['contract'] = Contract::find($data['material']['contId']);
		}
		return View::make('product.info')->with('data', $data);
	}
	
	public function product() {
		$materials = Material::get();
		return View::make('product.index')->with('materials', $materials);
	}

	/**
	 * Show the form for creating a new material
	 *
	 * @return Response
	 */
	public function create() {
		return View::make('materials.create');
	}
	
	/**
	 * Show the form for creating a new product
	 *
	 * @return Response
	 */
	 
	public function createProduct() {
		$materials = Material::with('materialCharge')->get();
		return View::make('product.create')->with('materials', $materials);
	}

	/**
	 * Store a newly created material in storage.
	 *
	 * @return Response
	 */
	public function store() {
		$validator = Validator::make($data = Input::all(), Material::$rules);

		if ($validator->fails()){
			return Redirect::back()->withErrors($validator);
		}
		try {
			Material::create(Input::all());
		} catch (Exception $e) {
			return Redirect::back()->withErrors(array('message' => '物料已存在，或添加失败！'));
		}
		
		return Redirect::route('admin.material.index')->with('complete', '添加广告物料成功！');
	}

	public function add() {
		$data = Input::only('charge');
		if(empty($data['charge'])){
			return Redirect::back()->withErrors(array('message' => '付费方式不能为空'));
		}
		$data['material'] = Input::only('name','silent','defCheck','adminUrl','userAndPwd');
		$contType = Input::only('contType');
		if($contType['contType']<2){
			$data['material']['contId'] = $contType['contType'];
		}else{
			$data['contract'] = Input::only('id','start_at','end_at');
			$data['material']['contId'] = 	$data['contract']['id'];
		}
		if(isset($data['contract'])){
			$validator = Validator::make($data['contract'], Contract::$rules);
			if ($validator->fails()){
				return Redirect::back()->withErrors($validator);
			}
		}
	
		$validator = Validator::make($data['material'], Material::$rules);

		if ($validator->fails()){
			return Redirect::back()->withErrors($validator);
		}
		foreach($data['charge'] as $key => $val){
			if($val['price']==''||$val['item']==''){
				unset($data['charge'][$key]);
				continue;
			}
			$data['charge'][$key]['price'] = $val['price'] = $val['price']*100;
			$validator = Validator::make($val, MaterialCharge::$rules);
			if ($validator->fails()){
				return Redirect::back()->withErrors($validator);
			}
		}
		try {
			$material = Material::create($data['material']);
			if(isset($data['contract'])){
				$contract = Contract::create($data['contract']);
			}
			foreach($data['charge'] as $key => $val){
				$val['materialId'] = $material->id;
				MaterialCharge::create($val);
			}
		} catch (Exception $e) {
			return Redirect::back()->withErrors(array('message' => '产品已存在，或添加失败！'));
		}
		
		return Redirect::route('admin.material.createproduct')->with('complete', '添加产品成功！');
	}
	
	/**
	 * Show the form for editing the specified material.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id) {
		$material = Material::find($id);
		if(empty($material)){
			return Redirect::route('admin.material.create');
		}
		return View::make('materials.edit')->with('material', $material);
	}
	
	public function editProduct($id) {
		$data['materials'] = Material::get();
		$data['material'] = Material::find($id);
		$materialcharge = MaterialCharge::where('materialId',$id)->get();
		foreach($materialcharge as $val){
			$data['materialcharge'][$val['item']]=round($val['price']/100,2);
		}
		
		if($data['material']['contId']>=2){
			$data['contract'] = Contract::find($data['material']['contId']);
		}
		if(empty($data['material'])){
			return Redirect::route('admin.material.createproduct');
		}
		return View::make('product.edit')->with('data', $data);
	}
	

	/**
	 * Update the specified material in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id) {
		try {
			$material = Material::findOrFail($id);
		} catch (Illuminate\Database\Eloquent\ModelNotFoundException $e) {
			return Redirect::route('admin.material.create');
		}
		
		$validator = Validator::make($data = Input::all(), Material::$rules);
		if ($validator->fails()){
			return Redirect::back()->withErrors($validator)->withInput();
		}
		try {
			$material->update($data);
		} catch (Exception $e) {
			return Redirect::back()->withErrors(array('message' => '编辑物料失败！'));
		}
		
		return Redirect::route('admin.material.index')->with('complete', '编辑广告物料成功！'); 
	}
	
	public function updateProduct($id){
		try {
			$material = Material::findOrFail($id);
		} catch (Illuminate\Database\Eloquent\ModelNotFoundException $e) {
			return Redirect::route('admin.material.createproduct');
		}
		$data = Input::only('charge');
		$data['material'] = Input::only('name','silent','defCheck','adminUrl','userAndPwd');
		$contType = Input::only('contType');
		if($contType<2){
			$data['material']['contId'] = $contType['contType'];
		}else{
			$data['contract'] = Input::only('id','start_at','end_at');
			$data['material']['contId'] = $data['contract']['id'];
		}
		if(isset($data['contract'])){
			$validator = Validator::make($data['contract'], Contract::$rules);
			if ($validator->fails()){
				return Redirect::back()->withErrors($validator);
			}
		}
		$validator = Validator::make($data['material'], Material::$rules);
		if ($validator->fails()){
			return Redirect::back()->withErrors($validator);
		}
		$materialCharge = MaterialCharge::withTrashed()->where('materialId',$id)->get();
		foreach($data['charge'] as $key => $val){
			if($val['price']==''||$val['item']==''){
				unset($data['charge'][$key]);
				continue;
			}
			$data['charge'][$key]['price'] = $val['price'] = $val['price']*100;
			$data['charge'][$key]['materialId'] = $id;
			$validator = Validator::make($val, MaterialCharge::$rules);
			if ($validator->fails()){
				return Redirect::back()->withErrors($validator);
			}
			foreach($materialCharge as $k=>$v){
				if($v['item']==$val['item']){
					$val['deleted_at'] = NULL;
					if($v['price']!=$val['price']){
						$charge['update'][]=$val;
					}
					unset($materialCharge[$k]);
					unset($data['charge'][$key]);
				}
			}
		}
		try {
			$material->update($data['material']);
			if(isset($data['contract'])){
				$contract = Contract::find($data['contract']['id']);
				if(count($contract)>0){
					$contract->update($data['contract']);
				}else{
					Contract::create($data['contract']);
				}
			}
			if(isset($charge['update'])){
				foreach($charge['update'] as $val){
					MaterialCharge::withTrashed()->where('materialId',$id)->where('item',$val['item'])->update($val);
				}
			}
			if(isset($data['charge'])){
				foreach($data['charge'] as $val){
					MaterialCharge::create($val);
				}
			}
			if(isset($materialCharge)){
				foreach($materialCharge as $val){
					MaterialCharge::where('materialId',$id)->where('item',$val['item'])->delete();
				}
			}
		} catch (Exception $e) {
			return Redirect::back()->withErrors(array('message' => '编辑产品失败！'));
		}
		return Redirect::route('admin.material.createproduct')->with('complete', '编辑产品成功！');
	}
	public function enabled($id){
		$material = Material::find($id);
		if(empty($material)){
			return Redirect::back()->withErrors(array('message' => '变更的链接不存在！'));
		}else{
			if($material->update(array('enabled'=>intval(!$material->enabled)))){
				return Redirect::route('admin.material.createproduct')->with('complete', '状态变更成功');
			}else{
				return Redirect::back()->withErrors(array('message' => '状态变更成功失败！'));
			}
		}
	}
	
	/**
	 * Remove the specified material from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id) {
		if(!Material::destroy($id)){
			return Redirect::route('admin.material.index');
		}
		return Redirect::route('admin.material.index')->with('complete', '删除广告物料成功！');
	}

}
