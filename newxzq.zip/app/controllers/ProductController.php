<?php

class ProductController extends BaseController {

	/**
	 * Display a listing of product
	 *
	 * @return Response
	 */
	public function index() {
		$product = Product::get();
		return View::make('product.index')->with('product', $product);
	}

	/**
	 * Show the form for creating a new product
	 *
	 * @return Response
	 */
	public function create() {
		return View::make('product.create');
	}

	/**
	 * Store a newly created product in storage.
	 *
	 * @return Response
	 */
	public function store() {
		$data = Input::only('charge');
		$data['product'] = Input::only('name','type');
	
		$validator = Validator::make($data['product'], Product::$rules);

		if ($validator->fails()){
			return Redirect::back()->withErrors($validator);
		}
		foreach($data['charge'] as $key => $val){
			if($val['price']==''||$val['item']==''){
				unset($data['charge'][$key]);
				continue;
			}
			$data['charge'][$key]['price'] = $val['price'] = $val['price']*100;
			$validator = Validator::make($val, ProductCharge::$rules);
			if ($validator->fails()){
				return Redirect::back()->withErrors($validator);
			}
		}
		try {
			$product = Product::create($data['product']);
			foreach($data['charge'] as $key => $val){
				$val['productId'] = $product->id;
				ProductCharge::create($val);
			}
			
		} catch (Exception $e) {
			return Redirect::back()->withErrors(array('message' => '产品已存在，或添加失败！'));
		}
		
		return Redirect::route('admin.product.index')->with('complete', '添加产品成功！');
	}

	/**
	 * Show the form for editing the specified product.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id) {
		$data['product'] = Product::find($id);
		$data['productcharge'] = ProductCharge::where('productId',$id)->get();
		if(empty($data['product'])){
			return Redirect::route('admin.product.create');
		}
		return View::make('product.edit')->with('data', $data);
	}

	/**
	 * Update the specified product in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id) {
		try {
			$product = Product::findOrFail($id);
		} catch (Illuminate\Database\Eloquent\ModelNotFoundException $e) {
			return Redirect::route('admin.product.create');
		}
		$data =  Input::only('name','type');
		$validator = Validator::make($data, Product::$rules);
		if ($validator->fails()){
			return Redirect::back()->withErrors($validator)->withInput();
		}
		
		$productcharge = Input::only('ccreate','cupdate');
		
		try {
			if(is_array($productcharge['ccreate'])){
				foreach($productcharge['ccreate'] as $key=>$val){
					if($val['price'] ==''|| $val['item'] =='') continue;
					$val['price']=$val['price']*100;
					$val['productId']=$id;
					ProductCharge::create($val);
				}
			}
			if(is_array($productcharge['cupdate'])){
				foreach($productcharge['cupdate'] as $key=>$val){
					if($val['price'] ==''|| $val['item'] =='') continue;
					$val['price']=$val['price']*100;
					ProductCharge::where('id',$key)->update($val);
				}
			}
			$product->update($data);
		} catch (Exception $e) {
			return Redirect::back()->withErrors(array('message' => '编辑产品失败！'));
		}
		
		return Redirect::route('admin.product.index')->with('complete', '编辑产品成功！');
	}

	/**
	 * Remove the specified product from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id) {
		if(!Product::destroy($id)){
			return Redirect::route('admin.product.index');
		}
		return Redirect::route('admin.product.index')->with('complete', '删除产品成功！');
	}

}
