<?php

class ProductChargeController extends BaseController {

	public function index() {
		$product = Product::all();
		$types = $this->getType($product);
		return View::make('productcharge.index')->with('types', $types);
	}

	public function add() {
		$product = Product::all();
		$types = $this->getType($product);
		return View::make('productcharge.add')->with('types', $types);
	}

	public function store() {
		$chargeData = Input::get("chargeData");
		$result = ProductCharge::all();
		foreach($result as $key=>$val){
			$product[$val->id]=$val->price;
		}
		if(isset($chargeData['create'])&&count($chargeData['create'])>0){
			foreach($chargeData['create'] as $key=>$val){
				foreach($val as $k=>$v){
					$data['day'] = $key;
					$data['chargeId'] = $k;
					$data['chargeData'] = $v;
					$data['income'] = $v*$product[$k];
					$validator = Validator::make($data,ProductData::$rules);
					if ($validator->fails()){
						return Redirect::back()->withErrors($validator);
					}
					try {
						ProductData::create($data);
					} catch (Exception $e) {
						return Redirect::back()->withErrors(array('message' => '数据已存在，或添加失败！'));
					}
					$data = array();
				}
			}
		}
		if(isset($chargeData['update'])&&count($chargeData['update'])>0){
			foreach($chargeData['update'] as $key=>$val){
				foreach($val as $k=>$v){
					$data['day'] = $key;
					$data['chargeId'] = $k;
					$data['chargeData'] = $v;
					$data['income'] = $v*$product[$k];
					$validator = Validator::make($data,ProductData::$rules);
					if ($validator->fails()){
						return Redirect::back()->withErrors($validator);
					}
					try {
						ProductData::where('day',$key)->where('chargeId',$k)->update($data);
					} catch (Exception $e) {
						return Redirect::back()->withErrors(array('message' => '数据更新失败！'));
					}
					$data = array();
				}
			}
		}
		return Redirect::route('admin.productcharge.index')->with('complete', '产品数据变更成功！'); 
	
	}
	
	public function data() {
		$type = Input::get('_t');
		$starttime = strtotime(Input::get('_s'));
		$endtime = strtotime(Input::get('_e'));
		if(!$starttime || !$endtime || $starttime>$endtime || $type == '' ){
			return $this->responseJson('-100','错误的参数');
		}
		
		$start = date('Y-m-d',$starttime);
		$end = date('Y-m-d',$endtime);
		
		$product = Product::with(array('productdata'=>function($query) use($start,$end){
			$query->with('productcharge')->where('day','>=',$start)->where('day','<=',$end)->orderby('day','asc');
		
		}))->where('type',$type)->get()->toArray();
		
		$column = $result = array();
		foreach($product as $key=>$val){
			$productcharge = ProductCharge::where('productId',$val['id'])->get();
			foreach($productcharge as $k=>$v){
				$column[$val['name']][$v['id']]=$v['item'];
			}
			foreach($val['productdata'] as $k=>$v){
				$result[$v['day']][$v['productcharge']['id']] = $v['chargeData'];
			}
		}
		for($i=$starttime;$i<$endtime;$i+=24*3600){
			$day=date("Y-m-d",$i);
			foreach($column as $key=>$val){
				foreach($val as $k=>$v){
					if(isset($result[$day][$k])){
						$data['data'][$day][$k] = $result[$day][$k];
					}else{
						$data['data'][$day][$k] = '';
					}
				}
			}
		}
		$data['column'] = $column;
		return $this->responseJson('0', '查询成功',$data);
	}
	
	public function lists() {
		
		$type = Input::get('_t');
		$starttime = strtotime(Input::get('_s'));
		$endtime = strtotime(Input::get('_e'));
		if(!$starttime || !$endtime || $starttime>$endtime || $type == '' ){
			return $this->responseJson('-100','错误的参数');
		}
		
		$start = date('Y-m-d',$starttime);
		$end = date('Y-m-d',$endtime);
		
		$product = Product::with(array('productdata'=>function($query) use($start,$end){
			$query->with('productcharge')->where('day','>=',$start)->where('day','<=',$end)->orderby('day','asc');
		
		}))->where('type',$type)->get()->toArray();
		$result = array();
		foreach($product as $key=>$val){
			foreach($val['productdata'] as $k=>$v){
				$data['column'][$val['name']][$v['productcharge']['id']]=$v['productcharge']['item'];
				$result[$v['day']][$v['productcharge']['id']]['chargeData'] = $v['chargeData'];
				$result[$v['day']][$v['productcharge']['id']]['income'] = $v['income']/100;
			}
		}
		foreach($result as $key=>$val){
			foreach($data['column'] as $k=>$v){
				foreach($v as $ks=>$vs){
					if(!$val[$ks]){
						$result[$key][$ks]['chargeData'] = '';
						$result[$key][$ks]['income'] = '';
					}
				}
			}
		}
		$data['data'] = $result;
		return $this->responseJson('0', '查询成功',$data);
	}
	
	public function getType($product){
		$type = array();
		foreach($product as $val){
			$type[] = $val->type;
		}
		
		return array_unique($type);
	}
}
