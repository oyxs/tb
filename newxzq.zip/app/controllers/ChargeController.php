<?php

class ChargeController extends BaseController {

	/**
	 * Display a listing of sites
	 */
	public function site()
	{
		return View::make('charge.site');
	}

	/**
	 * Display a listing of sites
	 */
	public function material()
	{
		$params['materials'] = Material::all();
		return View::make('charge.material',$params);
	}
	
	function add()
	{
		$params['materials'] = Material::all();
		return View::make('charge.add',$params);
	}
	
	public function store(){
		$chargeData = Input::get("chargeData");
		$materialId = Input::get("materialId");
		if(isset($chargeData['create'])&&count($chargeData['create'])>0){
			foreach($chargeData['create'] as $day => $value){
				foreach($value as $mlinkId => $val){
					$rmlink = RelMaterialLink::where("mlinkId",$mlinkId)->whereRaw("starttime<='$day' AND (endtime >= '$day' OR endtime is NULL)")->orderBy('starttime','desc')->get();
					foreach($val as $chargeId => $v){
						$chargeItems=ChargeItems::find($chargeId);
						$data['materialId']=$materialId;
						$data['day']=$day;
						$data['chargeId']=$chargeId;
						$data['chargeData']=$v;
						$data['income']=$v*($chargeItems->price);
						try{
							ChargeData::create($data);
							if(count($rmlink)==0) continue;
							foreach($rmlink as $ks => $vs){
								$siteid[]=$vs->siteId;
							}
							$strid=implode(",",$siteid);
							$tmparr= DB::select("SELECT siteId,SUM(ok)/(SELECT SUM(ok) FROM down_material_stat WHERE materialId=".$data['materialId']." AND LEFT(created_at,10)='".$day."' AND siteId in($strid)) as oks FROM down_material_stat WHERE materialId=".$data['materialId']." AND LEFT(created_at,10)='".$day."' AND siteId in($strid) group BY siteId");
							foreach($tmparr as $vs){
								$siteall[$vs->siteId]=$vs->oks;
							}
							
							foreach($rmlink as $ks => $vs){
								if(!isset($siteall[$vs->siteId])) continue;
								$data['siteId']=$vs->siteId;
								$data['mlinkId']=$mlinkId;
								$data['chargeData']=intval($v*$siteall[$vs->siteId]);
								$data['income']=$data['chargeData']*($chargeItems->price);
								ChargeStat::create($data);
							}
							unset($tmparr);
							unset($strid);
							$siteall = array();
							$siteid = array();
						}catch(Exception $e){
							return Redirect::back()->withErrors(array('message' => '添加数据失败！'));
						}
						unset($chargeItems);
						unset($data); 
					}
					unset($rmlink);
				}
			}
		}
		if(isset($chargeData['update'])&&count($chargeData['update'])>0){
			foreach($chargeData['update'] as $day => $value){
				foreach($value as $mlinkId => $val){
					foreach($val as $chargeId => $v){
						$chargeItems=ChargeItems::find($chargeId);
						$data2['chargeData']=$v;
						$data2['income']=intval($v)*($chargeItems->price);
						try{
							$tmparr = ChargeData::where("day",$day)->where("chargeId",$chargeId)->get();
							$tmpratio = $data2['chargeData']/($tmparr[0]->chargeData);
							ChargeData::where("day",$day)->where("chargeId",$chargeId)->update($data2);
							$chargestat = ChargeStat::where("day",$day)->where("chargeId",$chargeId)->get();
							foreach($chargestat as $ks => $vs){
								$data2['chargeData'] = ($vs->chargeData)*$tmpratio;
								$data2['income'] = ($vs->income)*$tmpratio;
								ChargeStat::where("id",$vs->id)->update($data2);
							}
						}catch(Exception $e){
							return Redirect::back()->withErrors(array('message' => '添加数据失败！'));
						}
						unset($chargeItems);
						unset($data2); 
					}
				}
			}
		}
		return Redirect::route('admin.charge.material')->with('complete', '产品数据变更成功！'); 
	}
	
	public function data()
	{
		$start = strtotime(Input::get("_s"));// 开始时间
		$end = strtotime(Input::get("_e"));// 结束时间
		$materialId = intval(Input::get("_mid"));// 物料ID

		// 验证参数
		if(!$start || !$end || $start>$end){
			return $this->responseJson('-100', '错误的参数');
		}
		$start = date("Y-m-d", $start);
		$end = date("Y-m-d", TimeHelper::getEndTime($end));
		if($materialId == 0 ){
			return $this->responseJson('-100', '错误的参数');
		}
		
		$materiallink = MaterialLink::where('materialId',$materialId)->where('enabled',1)->get();
		if(empty($materiallink)){
			return $this->responseJson('-200', '查询失败');
		}
		
		foreach($materiallink as $val){
			$mlarr[] = $val->id;
		}
		
		$items = ChargeItems::wherein('mlinkId',$mlarr)->get();
		
		if(empty($items))
		{
			return $this->responseJson('-2001', '查询失败');
		}
		else
		{
			foreach($items as $val )
			{
				$tmp[$val->mlinkId][]=$val;
			}
			if(isset($tmp)){
			$items=$tmp;
			unset($tmp);
			}else{
			return $this->responseJson('-2002', '查询失败');
			}
		}
		$data = ChargeData::getList($materialId,$start,$end,array("day","asc"));
		
		if(empty($data)){
			return $this->responseJson('-2003', '查询失败');
		}
		foreach($data as $key=>$val){
			$arr[$val->day][$val->chargeId]=$val->chargeData;
		}
		$num = 0;
		foreach($arr as $key=>$val){
			foreach($materiallink as $k => $v){
				if(!isset($items[$v->id])){
					unset($materiallink[$k]);continue;
				}
				$materiallink[$k]['count']=count($items[$v->id]);
				foreach($items[$v->id] as $value){
					if(isset($val[$value->id])){
						$ostats['data'][$key][$v->id][$value->id]=$val[$value->id];
					}else{
						$ostats['data'][$key][$v->id][$value->id]='';
					}
				}
			}
		}
		$ostats['items']=$items;
		$ostats['materiallink']=$materiallink;
		return $this->responseJson('0', '正确的查询', $ostats);
	}
	public function mouthlist()
	{
		$starttime = strtotime(Input::get("_s"));// 开始时间
		$endtime = strtotime(Input::get("_e"));// 结束时间
		$materialId = intval(Input::get("_mid"));// 物料ID

		// 验证参数
		if(!$starttime || !$endtime || $starttime>$endtime){
			return $this->responseJson('-100', '错误的参数');
		}
		$start = date("Y-m-d", $starttime);
		$end = date("Y-m-d", TimeHelper::getEndTime($endtime));
		if($materialId == 0 ){
			return $this->responseJson('-100', '错误的参数');
		}
		$materiallink = MaterialLink::where('materialId',$materialId)->where('enabled',1)->get();
		if(empty($materiallink)){
			return $this->responseJson('-200', '查询失败');
		}
		
		foreach($materiallink as $val){
			$mlarr[] = $val->id;
		}
		
		$items = ChargeItems::wherein('mlinkId',$mlarr)->get();
		
		if(empty($items))
		{
			return $this->responseJson('-2001', '查询失败');
		}
		else
		{
			foreach($items as $val )
			{
				$tmp[$val->mlinkId][]=$val;
			}
			if(isset($tmp)){
			$items=$tmp;
			unset($tmp);
			}else{
			return $this->responseJson('-2002', '查询失败');
			}
		}
		$data = ChargeData::getList($materialId,$start,$end,array("day","asc"));
		
		if(!empty($data)){
			foreach($data as $key=>$val){
				$arr[$val->day][$val->chargeId]=$val->chargeData;
			}
		}else{
			$arr = array();
		}
		$num = 0;
		for($i=$starttime;$i<=$endtime;$i+=24*3600){
			$day=date("Y-m-d",$i);
			foreach($materiallink as $k => $v){
				if(!isset($items[$v->id])){
					unset($materiallink[$k]);continue;
				}
				$materiallink[$k]['count']=count($items[$v->id]);
				foreach($items[$v->id] as $value){
					if(isset($arr[$day][$value->id])){
						$ostats['data'][$day][$v->id][$value->id]=$arr[$day][$value->id];
					}else{
						$ostats['data'][$day][$v->id][$value->id]='';
					}
				}
			}
		}
		
		$ostats['items']=$items;
		$ostats['materiallink']=$materiallink;
		return $this->responseJson('0', '正确的查询', $ostats);
	}

}
