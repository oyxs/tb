<?php
class BaseController extends Controller {

	private $user = null;

	public function __construct()
	{
		$this->beforeFilter('isNotLogin');
		$this->beforeFilter('auth');
	}

	/**
	 * Setup the layout used by the controller.
	 *
	 * @return void
	 */
	protected function setupLayout()
	{
		if ( ! is_null($this->layout))
		{
			$this->layout = View::make($this->layout);
		}
	}

	protected function responseJson($code, $msg, $data = array()) {
		header("Content-Type: application/json;charset=UTF-8");
		if($data == array()){
			return Response::json(['code' => $code, 'msg' => $msg]);
		}
		return Response::json(['code' => $code, 'msg' => $msg, 'data' => $data]);
	}

}
