<?php

class ChargeStatController extends BaseController {
	
	public function index(){
		$params['sites'] = Site::all();
		$params['materials'] = Material::all();
		return View::make('chargestat.index',$params);
	}
	
	public function data(){
	
		$start = strtotime(Input::get("_s"));// 开始时间
		$end = strtotime(Input::get("_e"));// 结束时间
		$siteId = intval(Input::get("_sid"));// 站点ID
		$materialId = intval(Input::get("_mid"));// 物料ID
		$is_xls = intval(Input::get("is_xls"));// 是否导入Excel
		
		if(!$start || !$end || $start>$end ){
			return $this->responseJson('-100','错误的参数');
		}
		
		$start = date('Y-m-d',$start);
		$end = date('Y-m-d',$end);
		if($is_xls){
			if($siteId==0){
				$site = Site::where('is_offline','N')->get();
			}else{
				$site[0] = Site::find($siteId);
			}
			foreach($site as $val){
				if($tmp = $this->getFormat($start,$end,$val->id,$materialId)){
					$cellData[$val->name]= $tmp;
					unset($tmp);
				}
			}
			if(!isset($cellData)){
				return $this->responseJson('-200', '查询失败');
			}
			Excel::create('站点数据',function($excel) use ($cellData){
			foreach($cellData as $key => $val){
			  $excel->sheet($key, function($sheet) use ($val){
				$sheet->rows($val['data']);
				foreach($val['mergecells'] as $v){
					$sheet->mergeCells($v);
				}
				if(isset($val['cname'])){
					foreach($val['cname'] as $v){
						$sheet->cells($v,function($cells){
							$cells->setFontColor('#ff0000');
						});
					}
				}
			  });
			}
			})->export('xls');
		}else{
			if($data = $this->getData($start,$end,$siteId,$materialId)){
				return $this->responseJson('0', '成功',$data);
			}else{
				return $this->responseJson('-200', '查询失败');
			}
		}
		
		
		
	}
	
	public function getData($start,$end,$siteId,$materialId){
		if($siteId == 0 ){
			return $this->responseJson('-100', '错误的参数');
		}
		
		if(!$materialId || $materialId<=0)
		{
			$detail = json_decode(json_encode(MaterialStat::getDetailList($siteId, 0, $start, $end)),true);
			$chargedata = ChargeStat::where("siteId",$siteId)->where('day','>=',$start)->where('day','<',$end)->orderby('day','asc')->orderby('materialId','asc')->get();
		}else
		{
			$detail = json_decode(json_encode(MaterialStat::getDetailList($siteId, $materialId, $start, $end)),true);
			$chargedata = ChargeStat::where("siteId",$siteId)->where('materialId',$materialId)->where('day','>=',$start)->where('day','<',$end)->orderby('day','asc')->get();
		}
		
		if(empty($detail) || empty($chargedata))
		{
			return false;
		}
		
		$materiallink = MaterialLink::with('material')->get();
		$chargeitems = ChargeItems::all();
		
		foreach($materiallink as $val){
			$mname[$val->id] = $val;
		}
		
		foreach($chargeitems as $val){
			$citems[$val->mlinkId][] = $val;
		}
		if(count($chargedata)>0){
			foreach($chargedata as $key=>$val){
				$material[$val->mlinkId]=$mname[$val->mlinkId]['material']->name.$mname[$val->mlinkId]->name;
				$data['data'][$val->day][$val->mlinkId][$val->chargeId]['chargedata']=$val->chargeData; 
				$data['data'][$val->day][$val->mlinkId][$val->chargeId]['income']=round($val->income/100,2); 
				if(isset($data['data'][$val->day][$val->mlinkId]['sumincome'])){
					$data['data'][$val->day][$val->mlinkId]['sumincome'] += round($val->income/100,2);
				}else{
					$data['data'][$val->day][$val->mlinkId]['sumincome'] = round($val->income/100,2);
				}
				$data['data'][$val->day][$val->mlinkId]['show'] = $detail[$val->day][$val->materialId]['show'];
				$data['data'][$val->day][$val->mlinkId]['check'] = $detail[$val->day][$val->materialId]['check'];
				$data['data'][$val->day][$val->mlinkId]['ok'] = $detail[$val->day][$val->materialId]['ok'];
				if(!isset($data['data'][$val->day][$val->mlinkId]['percent'])){
					$data['data'][$val->day][$val->mlinkId]['percent']=round($val->chargeData/$detail[$val->day][$val->materialId]['check']*100)."%";
				}
				$data['chargeitems'][$val->mlinkId]=$citems[$val->mlinkId];
			}
			foreach($chargedata as $key=>$val){
				if($val->chargeData<=0){
					$data['data'][$val->day][$val->mlinkId]['tincome']=0;
				}else{
					$data['data'][$val->day][$val->mlinkId]['tincome']=round($data['data'][$val->day][$val->mlinkId]['sumincome']*10000/$detail[$val->day][$val->materialId]['check'],2);
				}
			}
			$data['material']=$material;
			return $data;
		}else{
			return false;
		}
	}
	
	public function getFormat($start,$end,$siteId,$materialId){
		$letter=['A','B','C','D','E','F','G','H','I','G','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
		$data = $this->getData($start,$end,$siteId,$materialId);
		if(!$data){
			return false;
		}
		$num=1;
		$cellData['data'][0][] = '';
		$cellData['data'][1][] = '时间';
		foreach($data['material'] as $key=>$val){
			$cellData['data'][0][] = $val;
			$cellData['data'][0][] = '';
			$cellData['data'][0][] = '';
			$cellData['data'][0][] = '';
			$cellData['data'][0][] = '';
			$cellData['data'][0][] = '';
			$start = $end ='';
			if($num>26){
				$start .= $letter[floor($num/26)-1];
			}
			$start .= $letter[$num%26].'1';
			$cellData['data'][1][] = '展现';
			$cellData['data'][1][] = '勾选';
			$cellData['data'][1][] = '成功';
			foreach($data['chargeitems'][$key] as $k=>$v){
				$cellData['data'][0][] = '';
				$cellData['data'][1][] = $v->item;
				$num++;
			}
			$num += 5;
			$cellData['data'][1][] = '百分比';
			$cellData['data'][1][] = '收益';
			$cellData['data'][1][] = '万次收益';
			if($num>26){
				$end .= $letter[floor($num/26)-1];
			}
			$end .= $letter[$num%26].'1';
			$cellData['mergecells'][] = $start.':'.$end;
			$num++;
		}
		$row=2;
		foreach($data['data'] as $ks=>$vs){
			$cellData['data'][$row][] = $ks;
			$column =0;
			foreach($data['material'] as $key=>$val){
				$column += 3;
				if(!isset($vs[$key])){
					$cellData['data'][$row][] = '';
					$cellData['data'][$row][] = '';
					$cellData['data'][$row][] = '';
					foreach($data['chargeitems'][$key] as $k=>$v){
						$cellData['data'][$row][] = '';
						$column++;
					}
					$cellData['data'][$row][] = '';
					$cellData['data'][$row][] = '';
					$cellData['data'][$row][] = '';
					$column +=3;
				}else{
					$cellData['data'][$row][] = $vs[$key]['show'];
					$cellData['data'][$row][] = $vs[$key]['check'];
					$cellData['data'][$row][] = $vs[$key]['ok'];
					foreach($data['chargeitems'][$key] as $k=>$v){
						$cellData['data'][$row][] = $vs[$key][$v->id]['chargedata'];
						$column++;
					}
					$cellData['data'][$row][] = $vs[$key]['percent'];
					$cellData['data'][$row][] = $vs[$key]['sumincome'];
					$cellData['data'][$row][] = $vs[$key]['tincome'];
					$cname = '';
					$rows = $row+1;
					$column +=3;
					if($vs[$key]['tincome']<600){
						if($column>26){
							$cname .= $letter[floor($column/26)-1];
						}
						$cellData['cname'][] = $cname.$letter[$column%26].$rows;
					}
				}
			}
			$row++;
		}
		return $cellData;
	}
}
