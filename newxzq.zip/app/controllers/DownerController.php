<?php

class DownerController extends BaseController {

	/**
	 * Display a listing of downers
	 *
	 * @return Response
	 */
	public function index()
	{
		$downers = Downer::all();
		return View::make('downer.index')->with('downers', $downers);
	}

	/**
	 * Show the form for creating a new downer
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('downer.create');
	}

	/**
	 * Store a newly created downer in storage.
	 *
	 * @return Response
	 */
	public function store()
	{	
		$data = Input::all();
		$data['content'] = self::serializeContent($data);
		if(empty($data['content'])) {
			return Redirect::back()->withErrors(['错误：', '下载器广告位错误！']);
		}
		$validator = Validator::make($data, Downer::$rules);

		if ($validator->fails()) {
			return Redirect::back()->withErrors($validator);
		}

		Downer::create($data);
		return Redirect::route('admin.downer.index')->with('complete', '添加下载器成功！');
	}

	/**
	 * Show the form for editing the specified downer.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		try {
			$params['downer'] = Downer::findOrFail($id);
		} catch (Illuminate\Database\Eloquent\ModelNotFoundException $e) {
			return Redirect::back()->withErrors(['错误：', '编辑的下载器不存在！']);
		}
		$params['downer']['content'] = unserialize($params['downer']['content']);
		return View::make('downer.edit', $params);
	}

	/**
	 * Update the specified downer in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		try {
			$downer = Downer::findOrFail($id);
		} catch (Illuminate\Database\Eloquent\ModelNotFoundException $e) {
			return Redirect::back()->withErrors(['错误：', '编辑的下载器不存在！']);
		}

		$data = Input::all();
		$data['content'] = self::serializeContent($data);
		if(empty($data['content'])) {
			return Redirect::back()->withErrors(['错误：', '下载器广告位错误！']);
		}
		$validator = Validator::make($data, Downer::$rules);
		if ($validator->fails()) {
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$downer->update($data);
		return Redirect::route('admin.downer.index')->with('complete', '编辑下载器成功！');
	}

	/**
	 * Remove the specified downer from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		$ads = Ad::where('downerId', '=', $id)->get();
		if(!$ads->isEmpty()){
			return Redirect::back()->withErrors(['错误：', '该下载器正在投放广告，不可删除！']);
		}
		if(!Downer::destroy($id)){
			return Redirect::back()->withErrors(['错误：', '编辑下载器失败！']);
		}
		return Redirect::route('admin.downer.index')->with('complete', '删除下载器成功！');
	}

	public static function serializeContent($item) {
		$altNum = intval($item['altNum']) > 0 ? intval($item['altNum']) : 0;
		if(!is_array($item['pageName']) || !is_array($item['pageNum']) || 
			count($item['pageName']) != count($item['pageNum'])) {
			return false;
		}
		$pages = array();
		for ($i=0; $i < count($item['pageName']); $i++) {
			$key = 'page' . ($i + 1);
			$pages[$key]['name'] = $item['pageName'][$i];
			$pages[$key]['num'] = $item['pageNum'][$i];
		}
		$pages['alternative'] = array(
			'name' => '备选区',
			'num' => $altNum
		);
		return serialize($pages);
	}

}
