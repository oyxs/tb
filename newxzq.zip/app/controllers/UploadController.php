<?php

class UploadController extends Controller {

	public function icon()
	{
		//方法名不能和类名相同
		$result = array('status' => 0, 'desc' => '', 'imgurl' => '');
		if (empty($_FILES['uploadImg']['name'])) {
			$result['status'] = 1;
			//上传错误，未检测到文件
			$result['desc'] = '上传文件错误';
		} else if (!in_array($_FILES['uploadImg']['type'], Config::get('upload.ICON_MIME'))) {
			$result['status'] = 2;
			//上传文件类型错误
			$result['desc'] = '上传文件类型错误';
		} else if ($_FILES['uploadImg']['size'] > Config::get('upload.ICON_MAX_SIZE')) {
			$result['status'] = 3;
			//上传文件大小超过限制
			$result['desc'] = '上传文件大小超过限制';
		} else {
			$ext = pathinfo($_FILES["uploadImg"]["name"], PATHINFO_EXTENSION);
			$fpath = Config::get('path.UPLOAD_PATH');
			$furl = Config::get('path.UPLOAD_URL');
			if (!file_exists($fpath.'/'.date('Ymd'))){
				mkdir($fpath.'/'.date('Ymd'), 0777, true);
			}
			$dest = '/'.date('Ymd').'/'.time().'.'.$ext;
			if (move_uploaded_file($_FILES["uploadImg"]["tmp_name"], $fpath.$dest)) {
				$result['status'] = 0;
				$result['imgurl'] = $furl.$dest;
				$result['desc'] = '上传成功';
			} else {
				$result['status'] = 4;
				$result['desc'] = '上传失败';
			}

		}
		echo json_encode($result);
	}

	public function soft()
	{
		//方法名不能和类名相同
		$result = array('status' => 0, 'desc' => '', 'uploadSoft' => '');
		if (empty($_FILES['uploadSoft']['name'])) {
			$result['status'] = 1;
			//上传错误，未检测到文件
			$result['desc'] = '上传文件错误';
		} else if (!in_array($_FILES['uploadSoft']['type'], Config::get('upload.SOFT_MIME'))) {
			$result['status'] = 2;
			//上传文件类型错误
			$result['desc'] = '上传文件类型错误';
		} else if ($_FILES['uploadSoft']['size'] > Config::get('upload.SOFT_MAX_SIZE')) {
			$result['status'] = 3;
			//上传文件大小超过限制
			$result['desc'] = '上传文件大小超过限制';
		} else {
			$ext = pathinfo($_FILES["uploadSoft"]["name"], PATHINFO_EXTENSION);
			$fpath = Config::get('path.SOFT_PATH');
			$furl = Config::get('path.SOFT_URL');
			if (!file_exists($fpath.'/'.date('Ymd'))){
				mkdir($fpath.'/'.date('Ymd'), 0777, true);
			}
			$dest = '/'.date('Ymd').'/'.time().'.'.$ext;
			if (move_uploaded_file($_FILES["uploadSoft"]["tmp_name"], $fpath.$dest)) {
				$result['status'] = 0;
				$result['uploadSoft'] = $furl.$dest;
				$result['desc'] = '上传成功';
			} else {
				$result['status'] = 4;
				$result['desc'] = '上传失败';
			}

		}
		echo json_encode($result);
	}
}
