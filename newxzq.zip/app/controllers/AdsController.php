<?php
class AdsController extends BaseController {

	/**
	 * Display a listing of ads
	 *
	 * @return Response
	 */
	public function index() {
		$id=Input::get('id');//要更新的站点
		$fid = Input::get('fid');//原来站点
		if(isset($id)){
			$content = Ad::where('siteId',$id)->pluck('content');
			$update = Ad::where('siteId',$fid)->update(array('content' => $content,'change_id'=>$id));
			if($update){
				echo 1;
			}
			exit();
		}
		$params['ads'] = Ad::with('site')->orderBy('is_offline','asc')->orderBy('display_order','desc')->get();
		$params['site'] = Site::get();

		return View::make('ads.index', $params);
	}

	/**
	 * Show the form for creating a new ad
	 *
	 * @return Response
	 */
	public function create() {
		$params['sites'] = Site::all();
		$params['materials'] = Material::all();
		$params['versions'] = Downer::all();
		return View::make('ads.create', $params);
	}

	/**
	 * Store a newly created ad in storage.
	 *
	 * @return Response
	 */
	public function store() {
		// 验证参数的合法性
		$data = Ad::preprocess(Input::all());

		if (empty($data)){
			return Redirect::back()->withErrors(array('message' => '内容填写有误！'));
		}
		$datetime=date("Y-m-d H;i:s");
		$relate = RelMaterialLink::preprocess($data['siteId'],$data['content']);
		if (isset($relate['create'])&&is_array($relate['create'])){
			foreach($relate['create'] as $key=>$val){
				if(!isset($val['mlinkName']) || $val['mlinkName']==''){
					$val['mlinkName']=$val['name'];
				}
				$mlink = MaterialLink::where('link',$val['link'])->get();
				if(isset($mlink[0])){
					$val['mlinkId']=$mlink[0]->id;
					unset($mlink);
				}else{
					$materiallink = MaterialLink::create(array('name'=>$val['mlinkName'],'link'=>$val['link'],'materialId'=>$val['id'],'created_at'=>$datetime));
					$val['mlinkId'] = $materiallink->id;
				}
				RelMaterialLink::create(array('siteId'=>$data['siteId'],'materialId'=>$val['id'],'mlinkId'=>$val['mlinkId'],'starttime'=>$datetime));
			}
		}
		// 插入数据库
		try {
			Ad::create($data);
			if(!Ad::cache($data)) {
				throw new Exception();
			}
		} catch (Exception $e) {
			//print $e->getMessage();
			return Redirect::back()->withErrors(array('message' => '添加广告失败！'));
		}
		return Redirect::route('admin.ad.index')->with('complete', '添加广告成功！');
	}

	/**
	 * Show the form for editing the specified ad.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id) {
		$params['sites'] = Site::all();
		$params['materials'] = Material::all();
		$params['versions'] = Downer::all();
		$params['ad'] = Ad::find($id);
		if(empty($params['ad'])){
			return Redirect::route('admin.ad.create');
		}
		$params['ad']['content'] = unserialize($params['ad']['content']);
		$params['ad']['extra'] = unserialize($params['ad']['extra']);
		return View::make('ads.edit', $params);
	}

	/**
	 * Update the specified ad in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id) {
		// 验证ID的合法性
		try {
			$ad = Ad::findOrFail($id);
		} catch (Illuminate\Database\Eloquent\ModelNotFoundException $e) {
			return Redirect::route('admin.ad.create');
		}
		// 验证参数的合法性
		$data = Ad::preprocess(Input::all());
		if (empty($data)){
			return Redirect::back()->withErrors(array('message' => '内容填写有误！'));
		}
		$datetime=date("Y-m-d H;i:s");
		$relate = RelMaterialLink::preprocess($data['siteId'],$data['content']);
		if (isset($relate['create'])&&is_array($relate['create'])){
			foreach($relate['create'] as $key=>$val){
				if(!isset($val['mlinkName']) || $val['mlinkName']==''){
					$val['mlinkName']=$val['name'];
				}
				$mlink = MaterialLink::where('link',$val['link'])->get();
				if(isset($mlink[0])){
					$val['mlinkId']=$mlink[0]->id;
					unset($mlink);
				}else{
					$materiallink = MaterialLink::create(array('name'=>$val['mlinkName'],'link'=>$val['link'],'materialId'=>$val['id'],'created_at'=>$datetime));
					$val['mlinkId'] = $materiallink->id;
				}
				RelMaterialLink::create(array('siteId'=>$data['siteId'],'materialId'=>$val['id'],'mlinkId'=>$val['mlinkId'],'starttime'=>$datetime));
			}
		}
		if (isset($relate['close'])&&is_array($relate['close'])){
			foreach($relate['close'] as $key=> $val){
				RelMaterialLink::where('id',$key)->update(array('endtime'=>$datetime));
			}
		}
		// 更新数据库
		try {
			$ad->update($data);
		} catch (Exception $e) {
			return Redirect::back()->withErrors(array('message' => '编辑广告失败！'));
		}
		if(!Ad::cache($data)) {
			return Redirect::back()->withErrors(array('message' => '刷新广告缓存失败！'));
		}
		// 生成广告缓存
		return Redirect::route('admin.ad.index')->with('complete', '编辑广告成功！');
	}

	/**
	 * Remove the specified ad from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id) {
		/* if(!Ad::destroy($id) || !Ad::cacheRm($id)){
			return Redirect::back()->withErrors(array('message' => '删除广告失败！'));
		} */
		return Redirect::route('admin.ad.index')->with('complete', '删除广告成功！');
	}

	/**
	 * 刷新广告XML列表
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function refresh($id) {
		// 验证ID的合法性
		try {
			$ad = Ad::findOrFail($id);
			// 刷新缓存
			if(!Ad::cache($ad)) {
				throw new Exception();
			}
		} catch (Exception $e) {
			return Redirect::back()->withErrors(array('message' => '刷新缓存失败！'));
		}
		return Redirect::route('admin.ad.index')->with('complete', '刷新缓存成功！');
	}

}