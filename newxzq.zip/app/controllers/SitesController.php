<?php

class SitesController extends BaseController {

	/**
	 * Display a listing of sites
	 *
	 * @return Response
	 */
	public function index()
	{
		$sites = Site::with('user')->orderBy('is_offline','asc')->orderBy('display_order','desc')->get();
		return View::make('sites.index')->with('sites', $sites);
	}

	/**
	 * Show the form for creating a new site
	 *
	 * @return Response
	 */
	public function create()
	{
		$users = Sentry::findAllUsers();
		return View::make('sites.create')->with('users', $users);
	}

	/**
	 * Store a newly created site in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make($data = Input::all(), Site::$rules);
		if ($validator->fails()){
			return Redirect::back()->withErrors($validator);
		}
		
		$data['apiUrl']=serialize($data['apiUrl']);
		Site::create($data);
		return Redirect::route('admin.site.index')->with('complete', '添加站点成功！');
	}

	/**
	 * Show the form for editing the specified site.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$params['site'] = Site::find($id);
		if(empty($params['site'])){
			return Redirect::route('admin.site.create');
		}
		$params['site']['apiUrl'] =unserialize($params['site']['apiUrl']); 
		$params['users'] = Sentry::findAllUsers();
		return View::make('sites.edit', $params);
	}

	/**
	 * Update the specified site in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		try {
			$site = Site::findOrFail($id);
		} catch (Illuminate\Database\Eloquent\ModelNotFoundException $e) {
			return Redirect::back()->withErrors(['错误：', '编辑的站点不存在！']);
		}
		$validator = Validator::make($data = Input::all(), Site::$rules);
		$data['apiUrl']=serialize($data['apiUrl']);
		if ($validator->fails()){
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$site->update($data);

		return Redirect::route('admin.site.index')->with('complete', '编辑站点成功！');
	}
	

        //批量修改高级选项自定义区域
        public function batchextra() {
                $data['sites'] = Site::all();
                $data['cas'] =  $data['sites']->groupBy('customArea');
                return View::make('sites.batchextra', $data);
        }

        //更新批量修改高级选项自定义区域
        public function updbatch() {
                ini_set('max_execution_time','30');
                $siteIds = Input::get('id');
                Site::whereIn('id',$siteIds)->update([ 'customArea' => Input::get('customArea') ]);
                foreach($siteIds as $id) {
			if($ad = Ad::find($id)) {
			// 刷新缓存
			if(!Ad::cache($ad)) {
                                return Redirect::back()->withErrors(['message' => ['刷新缓存失败']]);
			}
			}
                        //$data = Ad::where('siteId',$id)->get();
                        //if(!Ad::cache($data,$id)) {
                        //        return Redirect::back()->withErrors(['message' => ['刷新缓存失败']]);
                        //}
                }
                return Redirect::route('admin.site.batchextra')->with('complete', '站点高级选项修改成功！');
        }


	/**
	 * Remove the specified site from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
//	public function destroy($id)
//	{
//		$ads = Ad::where('siteId', '=', $id)->get();
//		if(!$ads->isEmpty()){
//			return Redirect::back()->withErrors(['错误：', '该站点正在投放广告，不可删除！']);
//		}
//		if(!Site::destroy($id)){
//			return Redirect::back()->withErrors(['错误：', '编辑站点失败！']);
//		}
//		return Redirect::route('admin.site.index')->with('complete', '删除站点成功！');
//	}
	
	public function destroy($id){
		$name = '禁用';
		try {
			$sites = Site::find($id);
			if($sites->activated ==0) {
		    		$sites->activated = 1;
				$name = '禁用';
			} else {
		    		$sites->activated = 0;
				$name = '启用';
			}
			if($sites->save()){
				return Redirect::route('admin.site.index')->with('complete', $name.'站点成功！');
			}else{
				return Redirect::route('admin.site.index')->withErrors('错误：', $name.'站点失败！');
			}
		} catch (Exception $e) {
			return Redirect::route('admin.site.index')->withErrors('错误：', $name.'站点失败！');
		}
		
	}

}
