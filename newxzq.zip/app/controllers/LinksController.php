<?php

class LinksController extends BaseController {

	/**
	 * Show the form for creating a new material
	 *
	 * @return Response
	 */
	 
	public function index($id) {
		$data['mlink'] =  MaterialLink::where('materialId',$id)->get();
		$data['material'] =  Material::find($id);
		return View::make('materiallink.index')->with('data',$data);
	}
	
	public function create($id) {
		$data['mlinks'] =  MaterialLink::where('materialId',$id)->get();
		$data['material'] =  Material::find($id);
		return View::make('materiallink.create')->with('data',$data);
	}
	
	public function edit($id){
		$data['mlink'] =  MaterialLink::with('material')->find($id);
		$data['mlinks'] =  MaterialLink::where('materialId',$data['mlink']['materialId'])->get();
		return View::make('materiallink.edit')->with('data',$data);
	}
	
	public function update($id){
		try {
			$mlink = MaterialLink::findOrFail($id);
		} catch (Illuminate\Database\Eloquent\ModelNotFoundException $e) {
			return Redirect::route('admin.product.create');
		}
		$validator = Validator::make($data = Input::all(), MaterialLink::$rules);
		if ($validator->fails()){
			return Redirect::back()->withErrors($validator)->withInput();
		}
		try {
			$mlink->update($data);
		} catch (Exception $e) {
			return Redirect::back()->withErrors(array('message' => '产品包链接更改失败！'));
		}
		return Redirect::route('admin.link.create',['id'=>$data['materialId']])->with('complete', '产品包链接更改成功');
	}
	
	/**
	 * Store a newly created material in storage.
	 *
	 * @return Response
	 */
	public function store() {
		$validator = Validator::make($data = Input::all(), MaterialLink::$rules);
		if ($validator->fails()){
			return Redirect::back()->withErrors($validator)->withInput();
		}
		try {
			$materiallink=MaterialLink::create($data);
			$charge = MaterialCharge::where("materialId",$data['materialId'])->get();
			foreach($charge as $key=>$val){
				ChargeItems::Create(array("mlinkId"=>$materiallink['id'],'item'=>$val['item'],"price"=>$val['price'],"create_time"=>date("Y-m-d H:i:s"),"deleted_at"=>$val['deleted_at']));
			}
		} catch (Exception $e) {
			return Redirect::back()->withErrors(array('message' => '部分产品链接已存在，或添加失败！'));
		}
		
		return Redirect::route('admin.link.create',['id'=>$data['materialId']])->with('complete', '产品包链接更改成功');
	}

	public function enabled($id){
		$mlink = MaterialLink::find($id);
		if(empty($mlink)){
			return Redirect::back()->withErrors(array('message' => '变更的链接不存在！'));
		}else{
			if($mlink->update(array('enabled'=>intval(!$mlink->enabled)))){
				return Redirect::route('admin.link.create',['id'=>$mlink->materialId])->with('complete', '状态变更成功');
			}else{
				return Redirect::back()->withErrors(array('message' => '状态变更成功失败！'));
			}
		}
	}
	
	/**
	 * Remove the specified material from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id) {
		if(!MaterialLink::destroy($id)){
			return Redirect::route('admin.link.index');
		}
		return Redirect::route('admin.material.index')->with('complete', '删除广告物料成功！');
	}

}
