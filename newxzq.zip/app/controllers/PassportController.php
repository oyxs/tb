<?php

class PassportController extends Controller {

	/**
	 * Display admin login page.
	 * GET /
	 *
	 * @return Response
	 */
	public function index()
	{
		return View::make('passport.login');
	}

	/**
	 * authenticate user.
	 * GET /login
	 *
	 * @return Response
	 */
	public function login()
	{
		try{
		    // Find the user using the user id
		    $user = Sentry::findUserByCredentials(array(
		    	'email' => Input::get('email'),
		    	'password' => Input::get('password')
		    ));

		    // Log the user in
		    Sentry::login($user, false);
		    return Response::json(array('code' => 0, 'msg' => '登陆成功！'));
		}catch (Cartalyst\Sentry\Users\LoginRequiredException $e){
		    return Response::json(array('code' => -100, 'msg' => '请输入Email和密码！'));
		}catch (Cartalyst\Sentry\Users\UserNotFoundException $e){
		    return Response::json(array('code' => -100, 'msg' => '用户名或密码错误！'));
		}catch (Cartalyst\Sentry\Users\UserNotActivatedException $e){
		    return Response::json(array('code' => -100, 'msg' => '该用户未激活！'));
		}
	}

	/**
	 * Display a listing of the resource.
	 * GET /logout
	 *
	 * @return Response
	 */
	public function logout()
	{
		Sentry::logout();
		return Redirect::route('admin.index');
	}

	public function main()
	{
		return View::make('passport.main');
	}

	public function def()
	{
		return View::make('passport.default');
	}
	
	/**
	 * Show password form.
	 * @return Response
	 */
	public function password()
	{
		return View::make('passport.password');
	}

	/**
	 * change password.
	 * @return Response
	 */
	public function chpsw()
	{
		if(Input::get('password') !== Input::get('password2')){
			return Redirect::back()->withErrors('错误：', '两次输入的密码不一致！');
		}
		$password = Input::get('password');
		$user = Sentry::getUser();
		$resetCode = $user->getResetPasswordCode();
		// Check if the reset password code is valid
		if ($user->checkResetPasswordCode($resetCode)) {
		    // Attempt to reset the user password
		    if ($user->attemptResetPassword($resetCode, $password)) {
		        return Redirect::back()->with('complete', '修改密码成功！');
		    } else {
		        return Redirect::back()->withErrors('错误：', '修改密码失败！');
		    }
		} else {
		    return Redirect::back()->withErrors('错误：', '输入的密码不合法！');
		}
	}


}
