<?php

class NewAdController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		$material = Material::where('place','!=',0)->get();
		return View::make('newad.index')->with('material', $material);
	}


	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('newad.create');
	}


	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$data = Input::all();
		$data['showTime'] =  implode(',',$data['showTime']);
		$validator = Validator::make($data, Material::$rules);


		if ($validator->fails()){
			return Redirect::back()->withErrors($validator);
		}
		try {
			Material::create($data);

		} catch (Exception $e) {
			//print $e->getMessage();
			return Redirect::back()->withErrors(array('message' => '物料已存在，或添加失败！'));
		}

		return Redirect::route('admin.newad.index')->with('complete', '添加广告物料成功！');
	}


	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		//$newad = NewAd::get();

	}


	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$material = Material::find($id);
		if(empty($material)){
			return Redirect::route('admin.newad.create');
		}
		$material['showTime'] = explode(',',$material['showTime']);
		return View::make('newad.edit')->with('materials', $material);
	}


	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		try {
			$material = Material::findOrFail($id);
		} catch (Illuminate\Database\Eloquent\ModelNotFoundException $e) {
			return Redirect::route('admin.newad.create');
		}
		$data = Input::all();
		$data['showTime'] =  implode(',',$data['showTime']);

		$validator = Validator::make($data, Material::$rules);
		if ($validator->fails()){
			return Redirect::back()->withErrors($validator)->withInput();
		}
		try {
			$material->update($data);
		} catch (Exception $e) {
			return Redirect::back()->withErrors(array('message' => '编辑物料失败！'));
		}

		return Redirect::route('admin.newad.index')->with('complete', '编辑广告物料成功！');
	}


	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		if(!Material::destroy($id)){
			return Redirect::route('admin.newad.index');
		}
		return Redirect::route('admin.newad.index')->with('complete', '删除广告物料成功！');
	}


}
