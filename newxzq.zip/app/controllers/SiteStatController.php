<?php

class SiteStatController extends BaseController {

	/**
	 * Display a listing of sites
	 */
	public function site()
	{
		return View::make('sitestat.site');
	}

	/**
	 * Display a listing of sites
	 */
	public function material()
	{
		$params['materials'] = Material::all();
		return View::make('sitestat.material', $params);
	}

	public function data() {
		// 获取参数
		$type = Input::get("_t");// 统计的模型
		$start = strtotime(Input::get("_s"));// 开始时间
		$end = strtotime(Input::get("_e"));// 结束时间
		$display = Input::get("_d");// 显示类型 按天|按小时
		if(!$start || !$end || $start > $end){
			return $this->responseJson('-100', '错误的参数');
		}
		$start = date("Y-m-d H:i:s", $start);
		$end = date("Y-m-d H:i:s", TimeHelper::getEndTime($end));

		// 获取站点ID
		try {
			$user = Sentry::getUser();
			$site = Site::query()->where('userId', '=', $user->id)->first();
			if(!isset($site->id)){
				return $this->responseJson('-100', '错误的参数');
			}
		} catch (Exception $e) {
			return $this->responseJson('-100', '错误的参数');
		}
		$siteId = $site->id;
		// 获取数据
		if($type == 'site'){// 站点概况
			if(!in_array($display, array('hour', 'day'))){
				return $this->responseJson('-100', '错误的参数');
			}
			// 获取统计数据
			$ostats = SiteStat::getList($siteId, $start, $end, $display);
			if(empty($ostats)){
				return $this->responseJson('-200', '查询失败');
			}
			
			// csv 格式导出
			if(Input::get('is_csv') == '1'){
				header("Content-Type:application/octet-stream; charset=UTF-8");
				header("Content-Disposition:attachment; filename=site.csv");
				print(chr(0xEF).chr(0xBB).chr(0xBF));
				echo "时间,打开,第一步,第二步,第三步,成功,失败,成功率,失败率\r\n";
				foreach ($ostats as $key => $value) {
					echo $value->created_at.',';
					echo $value->open.',';
					echo $value->one.',';
					echo $value->two.',';
					echo $value->three.',';
					echo $value->four.',';
					echo $value->error.',';
					echo $value->rate.',';
					echo $value->errrate."\r\n";
				}
				exit(0);
			}
		} elseif ($type == 'material') {// 物料统计
			if($siteId == 21) {
				// 获取统计数据
				$ostats = MaterialStat::getSumList($siteId, 0, $start, $end);
				if(empty($ostats)){
					return $this->responseJson('-200', '查询失败');
				}
				foreach($ostats as $key => $value) {
					if(!in_array($value->materialId,[170,63,106,140,23])) {
						unset($ostats[$key]);
					}
					if($value->materialId == 23 && $value->created_at < '2016-08-23') {
						unset($ostats[$key]);	
					}
				}
			}elseif($user->id == 62) {
				// 获取统计数据
				$ostats = MaterialStat::getList(0, 265, $start, $end);
				foreach($ostats as $key => $value) {
					$ostats[$key]->material = $value->created_at;
				}
				if(empty($ostats)){
					return $this->responseJson('-200', '查询失败');
				}
			}elseif($user->id == 65) {
				// 获取统计数据
				$ostats = MaterialStat::getList(0, 266, $start, $end);
				foreach($ostats as $key => $value) {
					$ostats[$key]->material = $value->created_at;
				}
				if(empty($ostats)){
					return $this->responseJson('-200', '查询失败');
				}

			}elseif($user->id == 67) {
				// 获取统计数据
				$ostats = MaterialStat::getList(0, 267, $start, $end);
				foreach($ostats as $key => $value) {
					$ostats[$key]->material = $value->created_at;
				}
				if(empty($ostats)){
					return $this->responseJson('-200', '查询失败');
				}
			}elseif($user->id == 71) {
				// 获取统计数据
				$ostats = MaterialStat::getList(0, 276, $start, $end);
				foreach($ostats as $key => $value) {
					$ostats[$key]->material = $value->created_at;
				}
				if(empty($ostats)){
					return $this->responseJson('-200', '查询失败');
				}
			}elseif($user->id == 72) {
				// 获取统计数据
				$ostats1 = MaterialStat::getList(0, 255, $start, $end);
				$ostats2 = MaterialStat::getList(0, 273, $start, $end);
				foreach($ostats1 as $key => $value) {
					$ostats1[$key]->material = 'XY蓝月传奇:'.$value->created_at;
				}
				foreach($ostats2 as $key => $value) {
					$ostats2[$key]->material = '蓝月传奇xy:'.$value->created_at;
				}
				$ostats = array_merge($ostats1,$ostats2);
				if(empty($ostats)){
					return $this->responseJson('-200', '查询失败');
				}
			}elseif($user->id == 73) {
				// 获取统计数据
				$ostats = MaterialStat::getList(0, 277, $start, $end);
				foreach($ostats as $key => $value) {
					$ostats[$key]->material = $value->created_at;
				}
				if(empty($ostats)){
					return $this->responseJson('-200', '查询失败');
				}
			}else {
				return $this->responseJson('-100', '错误的参数');
			}
			// csv 格式导出
			if(Input::get('is_csv') == '1'){
				header("Content-Type:application/octet-stream; charset=UTF-8");
				header("Content-Disposition:attachment; filename=sitesum.csv");
				print(chr(0xEF).chr(0xBB).chr(0xBF));
				echo "物料,展现,勾选,反勾选,重复,成功,失败,勾选率,成功率\r\n";
				foreach ($ostats as $key => $value) {
					echo $value->material.',';
					echo $value->show.',';
					echo $value->check.',';
					echo $value->uncheck.',';
					echo $value->repeat.',';
					echo $value->ok.',';
					echo $value->error.',';
					echo $value->checkrate.',';
					echo $value->okrate."\r\n";
				}
				exit(0);
			}
		} else {
			return $this->responseJson('-100', '错误的参数');
		}
		return $this->responseJson('0', '正确的查询', $ostats);
	}

}
