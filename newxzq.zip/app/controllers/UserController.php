<?php

class UserController extends BaseController {

	/**
	 * Display a listing of users
	 *
	 * @return Response
	 */
	public function index()
	{
		$users = Sentry::findAllUsersWithAccess(array());
		return View::make('user.index')->with('users', $users);
	}

	/**
	 * Show the form for creating a new user
	 *
	 * @return Response
	 */
	public function create()
	{
		$groups = Sentry::findAllGroups();
		return View::make('user.create')->with('groups', $groups);
	}

	/**
	 * Store a newly created user in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make($data = Input::all(), User::$rules);

		if ($validator->fails()){
			return Redirect::back()->withErrors($validator);
		}
		try {
			Sentry::getUserProvider()->create(array(
				'email'      => $data['email'],
				'password'   => $data['password'],
				'first_name' => $data['first_name'],
				'last_name'  => '',
				'activated'  => 1,
			));
			$adminUser  = Sentry::getUserProvider()->findByLogin($data['email']);
			$adminGroup = Sentry::findGroupById($data['group']);
			$adminUser->addGroup($adminGroup);
		} catch (Exception $e) {
			return Redirect::back()->withErrors(['错误：', '添加失败，请检查参数是否合法！']);
		}
		return Redirect::route('admin.user.index')->with('complete', '添加用户成功！');
	}

	/**
	 * Show the form for editing the specified user.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		try {
			$params['user'] = $user = Sentry::findUserById($id);
			$params['groups'] = Sentry::findAllGroups();
		} catch (Exception $e) {
			return Redirect::route('admin.user.create')->withErrors('错误：', '该用户未找到');
		}
		return View::make('user.edit', $params);
	}

	/**
	 * Update the specified user in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		try {
		    $user = Sentry::findUserById($id);

		    // Update the user details
		    if(!Input::has('email') or !Input::has('first_name')){
		    	throw new Exception();
		    }
		    $user->email = Input::get('email');
		    $user->first_name = Input::get('first_name');
		    if (!$user->save()) {
		        return Redirect::back()->withErrors(['错误：', '编辑用户失败！']);
		    }
		    return Redirect::route('admin.user.index')->with('complete', '编辑用户成功！');
		}
		catch (Exception $e) {
		    return Redirect::back()->withErrors(['错误：', '编辑用户失败！']);
		}
	}

	/**
	 * Remove the specified user from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		try {
		    $user = Sentry::findUserById($id);
			$sites = Site::where('userId', '=', $id)->get();
			if(!$sites->isEmpty()){
				return Redirect::back()->withErrors(['错误：', '该用户是站点管理员，不可删除！']);
			}
		    $user->delete();
			return Redirect::route('admin.user.index')->with('complete', '删除用户成功！');
		} catch (Exception $e) {
			return Redirect::route('admin.user.index')->withErrors('错误：', '删除用户失败！');
		}
	}

	/**
	 * reset password.
	 * @return Response
	 */
	public function resetPsw($id)
	{
		try {
			$user = Sentry::findUserById($id);
			$resetCode = $user->getResetPasswordCode();
			// Check if the reset password code is valid
			if (!$user->checkResetPasswordCode($resetCode)) {
				throw new Exception();
			}
		    // Attempt to reset the user password
		    if (!$user->attemptResetPassword($resetCode, Config::get('auth.default_password'))) {
		        throw new Exception();
		    }
		    return Redirect::route('admin.user.index')->with('complete', '重置密码成功！');
		} catch (Exception $e) {
			return Redirect::route('admin.user.index')->withErrors('错误：', '重置密码失败！');
		}
	}

}
