<?php

class StatController extends BaseController {

	/**
	 * Display a listing of sites
	 */
	public function site()
	{
		$params['sites'] = Site::all();
		return View::make('stat.site', $params);
	}

	/**
	 * Display a listing of sites
	 */
	public function material()
	{
		$params['sites'] = Site::all();
		$params['materials'] = Material::all();
		return View::make('stat.material', $params);
	}

	/**
	 * @return mixed
	 * 顶部广告统计
	 */
	public function newmaterial()
	{
		$params['sites'] = Site::all();
		$params['materials'] = Material::where('place', '=', 1)->get();
		return View::make('stat.newmaterial', $params);
	}

	/**
	 * @return mixed
	 * 侧边广告广告展示
	 */
	public function broadsidematerial()
	{
		$params['sites'] = Site::all();
		$params['materials'] = Material::where('place', '=', 2)->get();
		return View::make('stat.broadsidematerial', $params);
	}

	/**
	 * @return mixed
	 * 侧边广告
	 */
	public function broadsidedata(){
		$type = Input::get("_t");// 统计的模型
		$start = strtotime(Input::get("_s"));// 开始时间
		$end = strtotime(Input::get("_e"));// 结束时间
		$materialId = intval(Input::get("_mid"));// 物料ID
		$siteId = intval(Input::get("_sid"));// 站点ID


		// 验证参数
		if(!$start || !$end || $start>$end){
			return $this->responseJson('-100', '错误的参数');
		}

		$start = date("Y-m-d H:i:s", $start);
		$end = date("Y-m-d H:i:s", TimeHelper::getEndTime($end));

		if ($type == 'broadsidesum') {// 物料汇总统计
			/*if($materialId == 0){
				return $this->responseJson('-1002', '错误的参数');
			}*/


			// 获取统计数据
			$ostats = BroadSideAdcount::getList($siteId, $materialId, $start, $end);
			if(empty($ostats)){
				return $this->responseJson('-2020', '查询失败');
			}
		}    else {
			return $this->responseJson('-1005', '错误的参数');
		}

		return $this->responseJson('0', '正确的查询', $ostats);
	}

	/**
	 * @return mixed
	 * 顶部广告
	 */
	public function topdata() {
		// 获取参数
		$type = Input::get("_t");// 统计的模型
		$start = strtotime(Input::get("_s"));// 开始时间
		$end = strtotime(Input::get("_e"));// 结束时间
		$materialId = intval(Input::get("_mid"));// 物料ID
		$siteId = intval(Input::get("_sid"));// 站点ID

		// 验证参数
		if(!$start || !$end || $start>$end){
			return $this->responseJson('-100', '错误的参数');
		}

		$start = date("Y-m-d H:i:s", $start);
		$end = date("Y-m-d H:i:s", TimeHelper::getEndTime($end));

		if ($type == 'topsum') {// 物料汇总统计
			/*if($materialId == 0){
				return $this->responseJson('-100', '错误的参数');
			}*/

			// 获取统计数据
			$ostats = TopAdCount::getList($siteId, $materialId, $start, $end);
			if(empty($ostats)){
				return $this->responseJson('-200', '查询失败');
			}

			// csv 格式导出
			/*if(Input::get('is_csv') == '1'){
				header("Content-Type:application/octet-stream; charset=UTF-8");
				header("Content-Disposition:attachment; filename=materialsum.csv");
				print(chr(0xEF).chr(0xBB).chr(0xBF));
				echo "站点,展现,勾选,反勾选,重复,成功,失败,勾选率,成功率\r\n";
				foreach ($ostats as $key => $value) {
					echo $value->site.',';
					echo $value->show.',';
					echo $value->check.',';
					echo $value->uncheck.',';
					echo $value->repeat.',';
					echo $value->ok.',';
					echo $value->error.',';
					echo $value->checkrate.',';
					echo $value->okrate."\r\n";
				}
				exit(0);
			}*/
		}    else {
			return $this->responseJson('-100', '错误的参数');
		}

		return $this->responseJson('0', '正确的查询', $ostats);
	}

	/**
	 * Display a listing of sites
	 */
	public function siteSum()
	{
		$params['sites'] = Site::all();
		$params['materials'] = Material::all();
		return View::make('stat.sitesum', $params);
	}

	/**
	 * Display a listing of sites
	 */
	public function materialSum()
	{
		$params['materials'] = Material::all();
		return View::make('stat.materialsum', $params);
	}

	public function data() {
		// 获取参数
		$type = Input::get("_t");// 统计的模型
		$start = strtotime(Input::get("_s"));// 开始时间
		$end = strtotime(Input::get("_e"));// 结束时间
		$siteId = intval(Input::get("_sid"));// 站点ID
		$materialId = intval(Input::get("_mid"));// 物料ID
		$display = Input::get("_d");// 显示类型 按天|按小时

		// 验证参数
		if(!$start || !$end || $start>$end){
			return $this->responseJson('-100', '错误的参数');
		}
		
		$start = date("Y-m-d H:i:s", $start);
		$end = date("Y-m-d H:i:s", TimeHelper::getEndTime($end));

		if($type == 'site'){// 站点概况
			if($siteId == 0 || !in_array($display, array('hour', 'day'))){
				return $this->responseJson('-100', '错误的参数');
			}

			// 获取统计数据
			$ostats = SiteStat::getList($siteId, $start, $end, $display);
			if(empty($ostats)){
				return $this->responseJson('-200', '查询失败');
			}

			// csv 格式导出
			if(Input::get('is_csv') == '1'){
				header("Content-Type:application/octet-stream; charset=UTF-8");
				header("Content-Disposition:attachment; filename=site.csv");
				print(chr(0xEF).chr(0xBB).chr(0xBF));
				echo "时间,打开,第一步,第二步,第三步,成功,失败,成功率,失败率\r\n";
				foreach ($ostats as $key => $value) {
					echo $value->created_at.',';
					echo $value->open.',';
					echo $value->one.',';
					echo $value->two.',';
					echo $value->three.',';
					echo $value->four.',';
					echo $value->error.',';
					echo $value->rate.',';
					echo $value->errrate."\r\n";
				}
				exit(0);
			}
		} elseif ($type == 'material') {// 物料统计
			if($siteId == 0 || !in_array($display, array('hour', 'day'))){
				return $this->responseJson('-100', '错误的参数');
			}

			// 获取统计数据
			$ostats = MaterialStat::getList($siteId, $materialId, $start, $end, $display);
			if(empty($ostats)){
				return $this->responseJson('-200', '查询失败');
			}

			// csv 格式导出
			if(Input::get('is_csv') == '1'){
				header("Content-Type:application/octet-stream; charset=UTF-8");
				header("Content-Disposition:attachment; filename=material.csv");
				print(chr(0xEF).chr(0xBB).chr(0xBF));
				echo "时间,展现,勾选,反勾选,重复,成功,失败,勾选率,成功率\r\n";
				foreach ($ostats as $key => $value) {
					echo $value->created_at.',';
					echo $value->show.',';
					echo $value->check.',';
					echo $value->uncheck.',';
					echo $value->repeat.',';
					echo $value->ok.',';
					echo $value->error.',';
					echo $value->checkrate.',';
					echo $value->okrate."\r\n";
				}
				exit(0);
			}
		} elseif ($type == 'materialsum') {// 物料汇总统计
			if($materialId == 0){
				return $this->responseJson('-100', '错误的参数');
			}

			// 获取统计数据
			$ostats = MaterialStat::getSumList(0, $materialId, $start, $end);
			if(empty($ostats)){
				return $this->responseJson('-200', '查询失败');
			}

			// csv 格式导出
			if(Input::get('is_csv') == '1'){
				header("Content-Type:application/octet-stream; charset=UTF-8");
				header("Content-Disposition:attachment; filename=materialsum.csv");
				print(chr(0xEF).chr(0xBB).chr(0xBF));
				echo "站点,展现,勾选,反勾选,重复,成功,失败,勾选率,成功率\r\n";
				foreach ($ostats as $key => $value) {
					echo $value->site.',';
					echo $value->show.',';
					echo $value->check.',';
					echo $value->uncheck.',';
					echo $value->repeat.',';
					echo $value->ok.',';
					echo $value->error.',';
					echo $value->checkrate.',';
					echo $value->okrate."\r\n";
				}
				exit(0);
			}
		} elseif ($type == 'sitesum') {// 站点汇总统计
			if($siteId == 0){
				return $this->responseJson('-100', '错误的参数');
			}

			// 获取统计数据
			$ostats = MaterialStat::getSumList($siteId, 0, $start, $end);
			if(empty($ostats)){
				return $this->responseJson('-200', '查询失败');
			}

			// csv 格式导出
			if(Input::get('is_csv') == '1'){
				header("Content-Type:application/octet-stream; charset=UTF-8");
				header("Content-Disposition:attachment; filename=sitesum.csv");
				print(chr(0xEF).chr(0xBB).chr(0xBF));
				echo "物料,展现,勾选,反勾选,重复,成功,失败,勾选率,成功率\r\n";
				foreach ($ostats as $key => $value) {
					echo $value->material.',';
					echo $value->show.',';
					echo $value->check.',';
					echo $value->uncheck.',';
					echo $value->repeat.',';
					echo $value->ok.',';
					echo $value->error.',';
					echo $value->checkrate.',';
					echo $value->okrate."\r\n";
				}
				exit(0);
			}
		} else {
			return $this->responseJson('-100', '错误的参数');
		}

		return $this->responseJson('0', '正确的查询', $ostats);
	}

}
