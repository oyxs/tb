@extends('common.layout')

@section('cssSection')
<link rel="stylesheet" href="/css/uniform.css" />
<link rel="stylesheet" href="/css/select2.css" />
<link rel="stylesheet" href="/css/bootstrap-datetimepicker.min.css" />
<link rel="stylesheet" href="/css/statwell.css" />
<link rel="stylesheet" href="/css/product.css" />
<style>
	#search_position{position:absolute;left:40%;top:45px;width:300px;}
</style>
@stop

@section('header')
	<div id="content-header">
		<h1>产品录入</h1>
	</div>
	<div id="breadcrumb">
		<a href="/default" class="tip-bottom" data-original-title="回到首页"><i class="icon-home"></i> 管理首页</a>
		<a href="/material/createproduct" class="current">产品录入</a>
		<a href="/material/{{ $data['material']['id'] }}/editProduct" class="current">编辑产品</a>
	</div>
@stop

@section('content')

	<div class="row-fluid">
		<div class="span12">
			@if ($errors->all())
			<div class="alert alert-error alert-block">
				<a class="close" data-dismiss="alert" href="#">×</a>
				<h4 class="alert-heading">错误!</h4>
				@foreach($errors->all() as $error)
				    {{ $error }}
				@endforeach
			</div>
			@endif
			<div class="widget-box">
				<div class="widget-title">
					<span class="icon">
						<i class="icon-file"></i>
					</span>
					<h5>产品录入</h5>
				</div>
				<div class="widget-content nopadding">
					<div class="well form-horizontal">
						<div class="control-group">
							<span class="pull-left span2">产品名称:</span> 
							<span class="pull-left">{{ $data['material']['name'] }}</span> 
						</div>
						
						<div class="control-group">
							<span class="pull-left span2">付费方式:</span>
							<span class="pull-left">
							@foreach( $data['material']['materialcharge'] as $key=>$val)
								{{ $val['item'] }}、
							@endforeach
							</span>
						</div>
						<div class="control-group">
							<span class="pull-left span2">合同信息 ：</span>
							<span class="pull-left">
							@if($data['material']['contId']==0)
								无合同
							@elseif($data['material']['contId']==1)
								电子合同
							@else
								合同编号：{{ $data['material']['contId'] }}
							@endif
							</span>
						</div>
						@if(isset($data['contract']))
						<div class="control-group">
							<span class="pull-left span2">合同有效期：</span>
							</span class="pull-left">
							@if(isset($data['contract']['start_at']))
							{{ $data['contract']['start_at'] }}
							@endif
							到
							@if(isset($data['contract']['end_at']))
							{{ $data['contract']['end_at'] }}
							@endif
							</span>
						</div>
						@endif
						
						<div class="control-group">
							<span  class="pull-left span2" >后台链接：</span>
							<span  class="pull-left" >
							{{ $data['material']['adminUrl'] }}
							</span>
						</div>
						<div class="control-group">
							<span  class="pull-left span2" >账号密码：</span>
							<span class="pull-left" >
							{{ $data['material']['userAndPwd'] }}
							</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
@stop

@section('jsSection')
@stop