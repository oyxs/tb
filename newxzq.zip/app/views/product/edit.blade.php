@extends('common.layout')

@section('cssSection')
<link rel="stylesheet" href="/css/uniform.css" />
<link rel="stylesheet" href="/css/select2.css" />
<link rel="stylesheet" href="/css/bootstrap-datetimepicker.min.css" />
<link rel="stylesheet" href="/css/statwell.css" />
<link rel="stylesheet" href="/css/product.css" />
<style>
	#search_position{position:absolute;left:40%;top:45px;width:300px;}
</style>
@stop

@section('header')
	<div id="content-header">
		<h1>产品录入</h1>
	</div>
	<div id="breadcrumb">
		<a href="/default" class="tip-bottom" data-original-title="回到首页"><i class="icon-home"></i> 管理首页</a>
		<a href="/material/createproduct" class="current">产品录入</a>
		<a href="/material/{{ $data['material']['id'] }}/editProduct" class="current">编辑产品</a>
	</div>
@stop

@section('content')

	<div class="row-fluid">
		<div class="span12">
			@if ($errors->all())
			<div class="alert alert-error alert-block">
				<a class="close" data-dismiss="alert" href="#">×</a>
				<h4 class="alert-heading">错误!</h4>
				@foreach($errors->all() as $error)
				    {{ $error }}
				@endforeach
			</div>
			@endif
			<div class="widget-box">
				<div class="widget-title">
					<span class="icon">
						<i class="icon-file"></i>
					</span>
					<h5>产品录入</h5>
				</div>
				<div class="widget-content nopadding">
					<div class="well"></div>
					<form class="form-horizontal" action="{{ URL::route('admin.material.updateproduct',['id'=>$data['material']['id']]) }}" method="post" >
					<div class="half-content " >
						<input type="hidden" name="silent" value="0"/>
						<input type="hidden" name="defCheck" value="0"/>
						<div class="control-group">
							<label class="control-label">产品名称 <span class="red bold">*</span></label>
							<div class="controls">
								<input type="text" name="name" value="{{ $data['material']['name'] }}" />
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label">付费方式 <span class="red bold">*</span></label>
							<div class="controls">
								@if(isset($data['materialcharge']['安装']))
								<div class="checkbox">
									<label><input type="checkbox" data-num="0" name="charge[0][item]" checked value="安装">安装
									<span class="pricebox"><input type="text" name="charge[0][price]" placeholder="单价" value="{{ $data['materialcharge']['安装'] }}" /></span></label>
								</div>
								@else
								<div class="checkbox">
									<label><input type="checkbox" data-num="0" name="charge[0][item]" value="安装">安装
									<span class="pricebox"></span></label>
								</div>
								@endif
								@if(isset($data['materialcharge']['激活']))
								<div class="checkbox">
									<label><input type="checkbox" data-num="1" name="charge[1][item]" checked="checked" value="激活">激活
									<span class="pricebox"><input type="text" name="charge[1][price]" placeholder="单价" value="{{ $data['materialcharge']['激活'] }}" /></span></label>
								</div>
								@else
								<div class="checkbox">
									<label><input type="checkbox" data-num="1" name="charge[1][item]" value="激活">激活
									<span class="pricebox"></span></label>
								</div>
								@endif
								@if(isset($data['materialcharge']['注册']))
								<div class="checkbox">
									<label><input type="checkbox" data-num="2" name="charge[2][item]" checked="checked" value="注册">注册
									<span class="pricebox"><input type="text" name="charge[2][price]" placeholder="单价" value="{{ $data['materialcharge']['注册'] }}" /></span></label>
								</div>
								@else
								<div class="checkbox">
									<label><input type="checkbox" data-num="2" name="charge[2][item]" value="注册">注册
									<span class="pricebox"></span></label>
								</div>
								@endif
								@if(isset($data['materialcharge']['CPS']))
								<div class="checkbox">
									<label><input type="checkbox" data-num="3" name="charge[3][item]" checked value="CPS">CPS
									<span class="pricebox"><input type="text" name="charge[3][price]" placeholder="单价" value="{{ $data['materialcharge']['CPS'] }}" /></span></label>
								</div>
								@else
								<div class="checkbox">
									<label><input type="checkbox" data-num="3" name="charge[3][item]" value="CPS">CPS
									<span class="pricebox"></span></label>
								</div>
								@endif
							</div>
						</div>
						<div class="control-group">
							<label class="control-label"> 合同信息 </label>
							<div class="controls">
								<div class="radio-left">
									<label><input type="radio" name="contType" @if($data['material']['contId']>=2) checked="checked" @endif value="2"> 合同编号</label>
								</div>
								<div class="radio-left">
									<label><input type="radio" @if($data['material']['contId']==0) checked="checked" @endif name="contType" value="0" > 无合同 </label>
								</div>
								<div class="radio-left">
									<label><input type="radio" @if($data['material']['contId']==1) checked="checked" @endif name="contType" value="1"> 电子合同 </label>
								</div>
							</div>
						</div>
						<div class="control-group cont-info" @if($data['material']['contId'] < 2) style="display:none;" @endif >
							<label class="control-label"> </label>
							<div class="controls">
								<input type="text" name="id" placeholder="请输入合同编号" @if($data['material']['contId'] >= 2) value="{{ $data['material']['contId'] }}" @endif />
							</div>
							<label class="control-label">合同有效期</label>
							<div class="controls">
								<span class="timeSpan">
									<div class="input-append date form_date">
									  <input class="input-small" name="start_at" id="time-start" style="width:110px;" type="text" @if(isset($data['contract']['start_at'])) value="{{ $data['contract']['start_at'] }}" @endif />
									  <span class="add-on"><i class="icon-time"></i></span>
									</div>
									<span> 到 </span>
									<div class="input-append date form_date">
									  <input class="input-small" name="end_at" id="time-end" style="width:110px;"  type="text" @if(isset($data['contract']['end_at'])) value="{{ $data['contract']['end_at'] }}" @endif />
									  <span class="add-on"><i class="icon-time"></i></span>
									</div>
								</span>
							</div>
						</div>
					</div>
					<div class="half-content" >
						<input type="hidden" name="silent" value="0"/>
						<input type="hidden" name="defCheck" value="0"/>
						<div class="control-group">
							<label class="control-label">后台链接 </label>
							<div class="controls">
								<textarea rows="4" name="adminUrl" placeholder="如输入多个链接用分号隔开" >{{ $data['material']['adminUrl'] }}</textarea>
							</div>
						</div>
						<div class="control-group">
							<label class="control-label">账号密码 </label>
							<div class="controls">
								<textarea rows="4" name="userAndPwd" placeholder="如输入密码用分号隔开" >{{ $data['material']['userAndPwd'] }}</textarea>
							</div>
						</div>
					</div>
					<div class="form-actions">
						<input class="btn btn-primary" type="submit" value="提交" />
					</div>
					</form>
				</div>
				<div class="widget-content nopadding">
					<table class="table table-bordered data-table">
						<thead>
							<tr>
								<th>产品名称</th>
								<th>后台链接</th>
								<th>账号密码</th>
								<th>付费方式</th>
								<th>合同信息</th>
								<th>状态</th>
								<th>操作</th>
							</tr>
						</thead>
						<tfoot>
							<th></th>
							<th></th>
							<th></th>
							<th></th>
							<th></th>
							<th></th>
							<th></th>
						</tfoot>
						<tbody>
							@foreach ($data['materials'] as $val)
							<tr>
								<td>{{ $val['name'] }}</td>
								<td >{{ $val['adminUrl'] }}</td>
								<td>{{ $val['userAndPwd'] }}</td>
								<td>
									@foreach($val['MaterialCharge'] as $v)
										{{$v['item']}}单价：{{round($v['price']/100,2)}}元<br>
									@endforeach
								</td>
								<td>@if($val['contId']==0)
										无合同
									@elseif($val['contId']==1)
										电子合同
									@else
										合同编号:{{$val['contId']}}
									@endif
								</td>
								<td>
									@if($val['enabled'])
										启用
									@else
										禁用
									@endif
								</td>
								<td>
									<a class="btn btn-primary btn-mini editBtn" dataId="{{ $val['id'] }}" title="编辑产品" href="{{ URL::route('admin.material.editproduct', ['id'=>$val['id']]) }}"> 编辑</a>
									<a class="btn btn-info btn-mini" dataId="{{ $val['id'] }}" title="查看产品" href="{{ URL::route('admin.material.info', ['id'=>$val['id']]) }}">查看</a>
									@if($val['enabled'])
									<a class="btn btn-danger btn-mini enabled" data-link="{{ URL::route('admin.material.enabled', ['id'=>$val['id']]) }}" title="禁用" role="button" > 禁用</a>
									@else
									<a class="btn btn-danger btn-mini enabled" data-link="{{ URL::route('admin.material.enabled', ['id'=>$val['id']]) }}" title="启用" role="button" >启用</a>
									@endif
									<a class="btn btn-warning btn-mini" dataId="{{ $val['id'] }}" title="数据管理" href="{{ URL::route('admin.charge.material') }}">数据管理</a>
									<a class="btn btn-warning btn-mini" dataId="{{ $val['id'] }}" title="产品包管理" href="{{ URL::route('admin.link.create', ['id'=>$val['id']]) }}">产品包管理</a>
								</td>
							</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
@stop

@section('jsSection')
<script type="text/javascript" src="/js/jquery.uniform.js"></script>
<script type="text/javascript" src="/js/select2.min.js"></script>
<script type="text/javascript" src="/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="/js/rest.js"></script>
<script type="text/javascript" src="/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript" src="/js/bootstrap-datetimepicker.zh-CN.js"></script>
<script type="text/javascript" src="/js/stat.js"></script>
<script>
	$(document).ready(function(){
		var enabled = function(){
			if(confirm("【注意】：确定要"+$(this).attr('title')+"该链接吗")){
				if(confirm("【注意】：禁用后所有在线上是链接都会下线哦！")){
					window.location.href=$(this).attr('data-link');
				}
			}
		}
		$(".checkbox input[type=checkbox]").change(function() {
			if($(this).attr('checked')){
				var cname = "charge["+$(this).attr('data-num')+"][price]";
				$(this).closest('.checker').siblings(".pricebox").html("<input type=\"text\" name=\""+cname+"\" placeholder=\"单价\" />");
			}else{
				$(this).closest('.checker').siblings(".pricebox").html("");
			}
		});
		
		$('.enabled').click(enabled);
		
		$("input[name=contType]").click(function() {
			if($(this).val()==2){
				$('.cont-info').show();
			}else{
				$('.cont-info').hide();
			}
		});
		$('.data-table').dataTable({
			"bJQueryUI": true,
			"pageLength": 10,
			"order": [[ 5, "asc" ],[0,"asc"]],
			"sPaginationType": "full_numbers",
			"sDom": '<"#search_position"f>t<"F"p>',
			"language": {
				"paginate": {
				  "first": "首页",
				  "last": "尾页",
				  "previous": "上一页",
				  "next": "下一页"
				},
				"lengthMenu": "显示 _MENU_ 条记录",
				"search":"搜索："
			},
			"columnDefs": [ {
					"targets": [0,1,2],
					"autoWidthDT": false,
					"width": "120px"
				} ,
				{"orderable":false,"targets":5}
			],
			initComplete: function () {
				var api = this.api();
				var column = api.column( 5 );
				var select = $('<select class="input-small"><option value="">状态</option></select>').appendTo( $(column.header()).empty() ).on( 'change', function (){
					var val = $.fn.dataTable.util.escapeRegex(
						$(this).val()
					);
					column.search( val ? '^'+val+'$' : '', true, false ).draw();
				} );
				column.data().unique().sort().each( function ( d, j ) {
					select.append( '<option value="'+d+'">'+d+'</option>' )
				} );
			}
		});
	});

</script>
@stop