@extends('common.layout')

@section('cssSection')
<link rel="stylesheet" href="/css/uniform.css" />
<link rel="stylesheet" href="/css/select2.css" />
@stop

@section('header')
	<div id="content-header">
		<h1>产品列表</h1>
	</div>
	<div id="breadcrumb">
		<a href="/default" class="tip-bottom" data-original-title="回到首页"><i class="icon-home"></i> 管理首页</a>
		<a href="/product" class="current">产品列表</a>
	</div>
@stop

@section('content')

@if (Session::has('complete'))
<div class="alertSection row-fluid">
	<div class="alert alert-success alert-block">
		<a class="close" data-dismiss="alert" href="javascript:void(0);">×</a>
		<h4 class="alert-heading">成功了!</h4>
		{{ Session::get('complete') }}
	</div>
</div>
@endif

<div class="widget-box">
	<div class="widget-title">
		<span class="icon">
			<i class="icon-file"></i>
		</span>
		<h5>产品列表</h5>
	</div>
	<div class="widget-content nopadding">
		<table class="table table-bordered data-table">
			<thead>
				<tr>
					<th>ID</th>
					<th>产品名称</th>
					<th>渠道名称</th>
					<th>创建时间</th>
					<th>更新时间</th>
					<th>操作</th>
				</tr>
			</thead>
			<tbody>
				@foreach ($product as $val)
				<tr>
					<td>{{ $val['id'] }}</td>
					<td>{{ $val['name'] }}</td>
					<td>{{ $val['type'] }}</td>
					<td>{{ $val['created_at'] }}</td>
					<td>{{ $val['updated_at'] }}</td>
					<td>
						<a class="btn btn-primary btn-mini editBtn" dataId="{{ $val['id'] }}" title="编辑站点" href="{{ URL::route('admin.product.edit', ['id'=>$val['id']]) }}"><i class="icon-pencil icon-white"></i> 编辑</a>
						<a class="btn btn-danger btn-mini rmBtn" dataId="{{ $val['id'] }}" title="删除站点" href="{{ URL::route('admin.product.destroy', ['id'=>$val['id']]) }}"><i class="icon-remove icon-white"></i> 删除</a>
					</td>
				</tr>
				@endforeach
			</tbody>
		</table>					
	</div>
</div>
@stop

@section('jsSection')
<script type="text/javascript" src="/js/select2.min.js"></script>
<script type="text/javascript" src="/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="/js/rest.js"></script>
<script type="text/javascript" src="/js/jquery.uniform.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$('.data-table').dataTable({
		"bJQueryUI": true,
		"pageLength": 50,
		"sPaginationType": "full_numbers",
		"sDom": '<""l>t<"F"fp>',
		"language": {
			"paginate": {
			  "first": "首页",
			  "last": "尾页",
			  "previous": "上一页",
			  "next": "下一页"
			},
			"lengthMenu": "显示 _MENU_ 条记录",
			"search": "搜索:"
		}
	});
	$('input[type=checkbox],input[type=radio],input[type=file]').uniform();
	$('select').select2();
});
</script>
@stop