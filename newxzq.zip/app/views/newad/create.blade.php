@extends('common.layout')

@section('cssSection')
    <link rel="stylesheet" href="/css/uniform.css" />
    <link rel="stylesheet" href="/css/select2.css" />
@stop

@section('header')
    <div id="content-header">
        <h1>添加新广告物料</h1>
    </div>
    <div id="breadcrumb">
        <a href="/default" class="tip-bottom" data-original-title="回到首页"><i class="icon-home"></i> 管理首页</a>
        <a href="/newad"  class="tip-bottom" data-original-title="广告物料列表">广告物料列表</a>
        <a href="/newad/create" class="current">添加广告物料</a>
    </div>
@stop

@section('content')

    <div class="row-fluid">
        <div class="span12">
            @if ($errors->all())
                <div class="alert alert-error alert-block">
                    <a class="close" data-dismiss="alert" href="#">×</a>
                    <h4 class="alert-heading">错误!</h4>
                    @foreach($errors->all() as $error)
                        {{ $error }}
                    @endforeach
                </div>
            @endif
            <div class="widget-box">
                <div class="widget-title">
					<span class="icon">
						<i class="icon-file"></i>
					</span>
                    <h5>添加新广告物料</h5>
                </div>
                <div class="widget-content nopadding">
                    <form class="form-horizontal" action="{{ URL::route('admin.newad.store') }}" method="post" />

                    <div class="control-group">
                        <label class="control-label">广告物料名称 <span class="red bold">*</span></label>
                        <div class="controls">
                            <input type="text" name="name" />
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">广告物料类型 <span class="red bold">*</span></label>
                        <div class="controls">
                            <select name="type">
                                <option value='0'>--请选择--</option>
                                <option value="textlink">文字链接</option>
                                <option value="imglink">图片链接</option>
                                <option value="giflink">GIF链接</option>
                                <option value="swflink">SWF链接</option>
                            </select>
                        </div>
                    </div>
                    <input type="hidden" name="silent" value="0" />

                    <div class="control-group" style="display:none;">
                        <label class="control-label">默认勾选 <span class="red bold">*</span></label>
                        <div class="controls">
                            <label><input type="radio" name="defCheck" value="1" checked="checked" /> 是</label>
                            <label><input type="radio" name="defCheck" value="0" /> 否</label>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">显示时间 <span class="red bold">*</span></label>
                        <div class="controls">
                            <input name="showTime[]" type="checkbox" value="1" />周一
                            <input name="showTime[]" type="checkbox" value="2" />周二
                            <input name="showTime[]" type="checkbox" value="3" />周三
                            <input name="showTime[]" type="checkbox" value="4" />周四
                            <input name="showTime[]" type="checkbox" value="5" />周五
                            <input name="showTime[]" type="checkbox" value="6" />周六
                            <input name="showTime[]" type="checkbox" value="0" />周日
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">位置 <span class="red bold">*</span></label>
                        <div class="controls">
                            <label><input type="radio" name="place" value="1" checked="checked"/> 顶部广告</label>
                            <label><input type="radio" name="place" value="2"  /> 侧边广告</label>
                        </div>
                    </div>



                    <div class="control-group imglink giflink swflink" style="display:none;">
                        <label class="control-label">图片</label>
                        <div class="controls show_image">
                            <img id="picPreviewImg" src="/img/default.png" alt="图片">
                            <input type="file" id="upfile" name="uploadImg" size="40">
                            <input type="text" class="picPreviewUrl" name="img" value="" />
                            <span class="picLoading"></span>
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">提示信息</label>
                        <div class="controls">
                            <input type="text" name="tip" />
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">链接名称 <span class="red bold">*</span></label>
                        <div class="controls">
                            <input type="text" name="linkName" />
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">链接地址 <span class="red bold">*</span></label>
                        <div class="controls">
                            <input type="text" name="link" />
                        </div>
                    </div>

                    <div class="form-actions">
                        <input class="btn btn-primary" type="submit" value="提交" />
                        <input class="btn btn-primary" type="reset" value="重置" />
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <form id="uploadImgForm" style="display:none;" method="post" action="{{ URL::route('admin.upload.icon') }}" enctype="multipart/form-data" target="upIframe"></form>
@stop

@section('jsSection')
    <script type="text/javascript" src="/js/jquery.uniform.js"></script>
    <script type="text/javascript" src="/js/select2.min.js"></script>
    <script type="text/javascript" src="/js/jquery.form.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $('input[type=checkbox],input[type=radio]').uniform();
            $('select').select2();

            $("select[name=type]").change(function(){
                var type = $(this).val();
                $(".textlink").hide();
                $(".textlink input[type=text]").val("");
                $(".imglink").hide();
                $(".imglink input[type=text]").val("");
                $("." + type).show();
            });

            // 上传图标
            $(".show_image").change(function() {
                var _this = this;
                $(".picLoading").css("display", "block");
                var option = {
                    dataType : 'json',
                    error : function(XMLResponse) {
                        alert('ERROR:' + XMLResponse.responseText);
                        $(_this).find("img").after('<input type="file" id="upfile" name="uploadImg" size="40">');
                        $(".picLoading").css("display", "none");
                    },
                    success : successHandler
                };
                if ($(this).children('input[type=file]').val() != '' && $(this).children('input[type=file]').val() != undefined) {
                    $('#uploadImgForm').empty();
                    $('#uploadImgForm').append($(this).children('input[type=file]'));
                    $('#uploadImgForm').ajaxSubmit(option);
                }
                function successHandler(responseText, statusText) {
                    if (responseText.status == 0) {
                        $(_this).find("img").attr('src', '{{ Config::get('app.url') }}'+responseText.imgurl);
                        $(_this).find('.picPreviewUrl').val('{{ Config::get('app.url') }}'+responseText.imgurl);
                        $(_this).find("img").after('<input type="file" id="upfile" name="uploadImg" size="40">');
                        $('#uploadImgForm').empty();
                        $(".picLoading").css("display", "none");
                    } else {
                        alert('ERROR:' + responseText.status + ': ' + responseText.desc);
                        $(".picLoading").css("display", "none");
                        $(_this).find("img").after('<input type="file" id="upfile" name="uploadImg" size="40">');
                        $('#uploadImgForm').empty();
                    }
                }
            });
        });
    </script>
@stop
