@extends('common.layout')

@section('cssSection')
<link rel="stylesheet" href="/css/uniform.css" />
<link rel="stylesheet" href="/css/select2.css" />
@stop

@section('header')
	<div id="content-header">
		<h1>编辑站点</h1>
	</div>
	<div id="breadcrumb">
		<a href="/default" class="tip-bottom" data-original-title="回到首页"><i class="icon-home"></i> 管理首页</a>
		<a href="/site"  class="tip-bottom" data-original-title="站点列表">站点列表</a>
		<a href="{{ URL::route('admin.site.edit', ['id' => $site['id']]) }}" class="current">编辑站点</a>
	</div>
@stop

@section('content')

	<div class="row-fluid">
		<div class="span12">
@if (Session::has('complete'))
<div class="alertSection row-fluid">
	<div class="alert alert-success alert-block">
		<a class="close" data-dismiss="alert" href="javascript:void(0);">×</a>
		<h4 class="alert-heading">成功了!</h4>
		{{ Session::get('complete') }}
	</div>
</div>
@endif

@if ($errors->all())
<div class="alert alert-error alert-block">
	<a class="close" data-dismiss="alert" href="#">×</a>
	<h4 class="alert-heading">错误!</h4>
	@foreach($errors->all() as $error)
	    {{ $error }}
	@endforeach
</div>
@endif
			<div class="widget-box">
				<div class="widget-title">
					<span class="icon">
						<i class="icon-globe"></i>
					</span>
					<h5>添加站点</h5>
				</div>
				<div class="widget-content nopadding">
					<form class="form-horizontal" action="{{ URL::route('admin.site.update', ['id' => $site['id']]) }}" method="post" />
						<div class="control-group">
							<label class="control-label">站点名称</label>
							<div class="controls">
								<input type="text" name="name" value="{{ $site['name'] }}" />
							</div>
						</div>
						<div class="control-group">
							<label class="control-label">站点地址</label>
							<div class="controls">
								<input type="text" name="siteUrl" value="{{ $site['siteUrl'] }}" />
							</div>
						</div>
						<div class="control-group">
							<label class="control-label">百度搜索地址</label>
							<div class="controls">
								<input type="text" name="search" value="{{ $site['search'] }}" />
							</div>
						</div>
						<div class="control-group">
							<label class="control-label">数据接口地址(主)</label>
							<div class="controls">
								<input type="text" name="apiUrl[url][]" value="{{ $site['apiUrl']['url'][0] }}" />
							</div>
						</div>
						<div class="control-group">
							<label class="control-label">接口检测地址(主)</label>
							<div class="controls">
								<input type="text" name="apiUrl[checkUrl][]" value="{{ $site['apiUrl']['checkUrl'][0] }}" />
							</div>
						</div>
						<input type="hidden" name="apiUrl[status][]" value="0" />
						<div class="control-group">
							<label class="control-label">数据接口地址(备用1)</label>
							<div class="controls">
								<input type="text" name="apiUrl[url][]" value="{{ $site['apiUrl']['url'][1] }}" />
							</div>
						</div>
						<div class="control-group">
							<label class="control-label">接口检测地址(备用1)</label>
							<div class="controls">
								<input type="text" name="apiUrl[checkUrl][]" value="{{ $site['apiUrl']['checkUrl'][1] }}" />
							</div>
						</div>
						<input type="hidden" name="apiUrl[status][]" value="0" />
						<div class="control-group">
							<label class="control-label">数据接口地址(备用2)</label>
							<div class="controls">
								<input type="text" name="apiUrl[url][]" value="{{ $site['apiUrl']['url'][2] }}" />
							</div>
						</div>
						<div class="control-group">
							<label class="control-label">接口检测地址(备用2)</label>
							<div class="controls">
								<input type="text" name="apiUrl[checkUrl][]" value="{{ $site['apiUrl']['checkUrl'][2] }}" />
							</div>
						</div>
						<input type="hidden" name="apiUrl[status][]" value="0" />
						<div class="control-group">
							<label class="control-label">站点图标</label>
							<div class="controls">
								<input type="text" name="siteIcon" value="{{ $site['siteIcon'] }}" />
							</div>
						</div>
						<div class="control-group">
							<label class="control-label">数据接口TAG</label>
							<div class="controls">
								<input type="text" name="apiTag" value="{{ $site['apiTag'] }}" />
							</div>
						</div>
						<div class="control-group">
							<label class="control-label">关联管理员</label>
							<div class="controls">
								<select name="userId">
									<option value='-1'>---请选择---</option>
									@foreach ($users as $user)
									<option {{{ $site['userId'] == $user['id'] ? 'selected="selected"' : '' }}} value="{{ $user['id'] }}">{{ $user['first_name'] }}</option>
									@endforeach
								</select>
							</div>
						</div>

						<div class="form-actions">
							<input class="btn btn-primary" type="submit" value="提交" />
							<input class="btn btn-primary" type="reset" value="重置" />
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

@stop

@section('jsSection')
<script type="text/javascript" src="/js/jquery.uniform.js"></script>
<script type="text/javascript" src="/js/select2.min.js"></script>
<script type="text/javascript">
	$('input[type=checkbox],input[type=radio],input[type=file]').uniform();
	$('select').select2();
</script>
@stop