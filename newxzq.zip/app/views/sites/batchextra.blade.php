@extends('common.layout')

@section('cssSection')
<link rel="stylesheet" href="/css/uniform.css" />
<link rel="stylesheet" href="/css/select2.css" />
<link rel="stylesheet" href="/css/colorpicker.css" />
@stop

@section('header')
    <div id="content-header">
        <h1>站点高级选项修改</h1>
    </div>
@stop

@section('content')

    <div class="row-fluid">
        <div class="span12">

            @if (Session::has('complete'))
            <div class="alertSection row-fluid">
                <div class="alert alert-success alert-block">
                    <a class="close" data-dismiss="alert" href="javascript:void(0);">×</a>
                    <h4 class="alert-heading">成功了!</h4>
                    {{ Session::get('complete') }}
                </div>
            </div>
            @endif

            @if ($errors->all())
            <div class="alert alert-error alert-block">
                <a class="close" data-dismiss="alert" href="#">×</a>
                <h4 class="alert-heading">错误!</h4>
                @foreach($errors->all() as $error)
                    {{ $error }}
                @endforeach
            </div>
            @endif

            <div class="widget-box">
                <div class="widget-content nopadding">
			<form class="form-horizontal" action="/site/updbatch" method="post" />
                        <div class="control-group">
                            <label class="control-label">站点名称</label>
                            <label class="control-label"> <a class="btn btn-primary btn-mini checkall">全选</a></label>
                            <label class="control-label"> <a class="btn btn-primary btn-mini uncheckall">全取消</a></label>
                        </div>
                        <div class="control-group">
                            @foreach($sites as $val)
                            <label class="control-label"> <input name="id[]" type="checkbox" value="{{ $val->id }}" />{{ $val->name }}</label>
                            @endforeach
                        </div>
                        <div class="control-group">
                            <label class="control-label">自定义区域</label>
                            <div class="controls">
                                <textarea name="customArea" rows="5"></textarea>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="form-actions">
                            <input class="btn btn-primary" type="submit" value="提交" />
                            <input class="btn btn-primary" type="reset" value="重置" />
                        </div>
			</form>
			@if(is_array($cas))
                        @foreach($cas as $key => $val)
                        <div class="control-group">
                                <div class="controls">{{ $val->implode('name', '，') }}自定义区域</div>
                        </div>
                        <div class="control-group">
                                <div class="controls">{{ $key }}</div>
                        </div>
                        @endforeach
			@endif
                </div>
            </div>
        </div>
    </div>

@stop

@section('jsSection')
<script type="text/javascript" src="/js/jquery.uniform.js"></script>
<script type="text/javascript" src="/js/select2.min.js"></script>
<script type="text/javascript" src="/js/bootstrap-colorpicker.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $('input[type=checkbox],input[type=radio],input[type=file]').uniform();
        $(".checkall").click(function() {
            $("input[type=checkbox]").attr("checked",true);
            $.uniform.update();
        });
        $(".uncheckall").click(function() {
            $("input[type=checkbox]").attr("checked",false);
            $.uniform.update();
        });
    });
</script>
@stop
