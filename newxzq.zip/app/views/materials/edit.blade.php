@extends('common.layout')

@section('cssSection')
<link rel="stylesheet" href="/css/uniform.css" />
<link rel="stylesheet" href="/css/select2.css" />
@stop

@section('header')
	<div id="content-header">
		<h1>编辑广告物料</h1>
	</div>
	<div id="breadcrumb">
		<a href="/default" class="tip-bottom" data-original-title="回到首页"><i class="icon-home"></i> 管理首页</a>
		<a href="/material"  class="tip-bottom" data-original-title="广告物料列表">广告物料列表</a>
		<a href="{{ URL::route('admin.material.edit', ['id'=>$material['id']]) }}" class="current">编辑广告物料</a>
	</div>
@stop

@section('content')

	<div class="row-fluid">
		<div class="span12">
			@if ($errors->all())
			<div class="alert alert-error alert-block">
				<a class="close" data-dismiss="alert" href="#">×</a>
				<h4 class="alert-heading">错误!</h4>
				@foreach($errors->all() as $error)
				    {{ $error }}
				@endforeach
			</div>
			@endif
			<div class="widget-box">
				<div class="widget-title">
					<span class="icon">
						<i class="icon-file"></i>
					</span>
					<h5>编辑广告物料</h5>
				</div>
				<div class="widget-content nopadding">
					<form class="form-horizontal" action="{{ URL::route('admin.material.update', ['id'=>$material['id']]) }}" method="post" />

						<div class="control-group">
							<label class="control-label">广告物料名称 <span class="red bold">*</span></label>
							<div class="controls">
								<input type="text" name="name" value="{{ $material['name'] }}" />
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">广告物料类型 <span class="red bold">*</span></label>
							<div class="controls">
								<select name="type">
									<option value='0'>--请选择--</option>
									<option value="startpage" {{{ $material['type'] == 'startpage' ? 'selected="selected"' : '' }}}>设置首页</option>
									<option value="install" {{{ $material['type'] == 'install' ? 'selected="selected"' : '' }}}>安装软件</option>
									<option value="createlink" {{{ $material['type'] == 'createlink' ? 'selected="selected"' : '' }}}>创建链接</option>
								</select>
							</div>
						</div>

						<input type="hidden" name="silent" value="0" />

						<div class="control-group">
							<label class="control-label">默认勾选 <span class="red bold">*</span></label>
							<div class="controls">
								<label><input type="radio" name="defCheck" value="0" {{{ $material['defCheck'] == '0' ? 'checked="checked"' : '' }}} /> 否</label>
								<label><input type="radio" name="defCheck" value="1" {{{ $material['defCheck'] == '1' ? 'checked="checked"' : '' }}} /> 是</label>
							</div>
						</div>

						<div class="control-group install createlink" style="display:none;">
							<label class="control-label">链接图标</label>
							<div class="controls show_image">
								<img id="picPreviewImg" src="{{ empty($material['linkIcon'])?'/img/default.png':$material['linkIcon'] }}" alt="任务图片">
								<input type="file" id="upfile" name="uploadImg" size="40">
								<input type="hidden" class="picPreviewUrl" name="linkIcon" value="{{ empty($material['linkIcon'])?'':$material['linkIcon'] }}" />
								<span class="picLoading"></span>
							</div>
						</div>
						
						<div class="control-group createlink" style="display:none;">
							<label class="control-label">软件图标</label>
							<div class="controls show_image">
								<img id="picPreviewImg" src="{{ empty($material['logoUrl'])?'/img/default.png':$material['logoUrl'] }}" alt="任务图片">
								<input type="file" id="upfile" name="uploadImg" size="40">
								<input type="hidden" class="picPreviewUrl" name="logoUrl" value="{{ empty($material['logoUrl'])?'':$material['logoUrl'] }}" />
								<span class="picLoading"></span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">提示信息</label>
							<div class="controls">
								<input type="text" name="tip" value="{{ $material['tip'] }}" />
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">链接地址 <span class="red bold">*</span></label>
							<div class="controls">
								<input type="text" name="link" value="{{ $material['link'] }}" />
							</div>
						</div>

						<div class="control-group install createlink" style="display:none;">
							<label class="control-label">本地安装地址</label>
							<div class="controls">
								<input type="text" name="savePath" value="{{ $material['savePath'] }}" />
							</div>
						</div>

						<div class="control-group install" style="display:none;">
							<label class="control-label">注册表路径</label>
							<div class="controls">
								<input type="text" name="rootKey" value="{{ $material['rootKey'] }}" />
							</div>
						</div>

						<div class="control-group install" style="display:none;">
							<label class="control-label">注册表键名</label>
							<div class="controls">
								<input type="text" name="keyName" value="{{ $material['keyName'] }}" />
							</div>
						</div>

						<div class="control-group install" style="display:none;">
							<label class="control-label">安装后缀名</label>
							<div class="controls">
								<input type="text" name="regExt" value="{{ $material['regExt'] }}" />
							</div>
						</div>

						<div class="control-group install" style="display:none;">
							<label class="control-label">执行参数</label>
							<div class="controls">
								<input type="text" name="cmdLine" value="{{ $material['cmdLine'] }}" />
							</div>
						</div>

						<div class="control-group createlink startpage" style="display:none;">
							<label class="control-label">链接名称</label>
							<div class="controls">
								<input type="text" name="linkName" value="{{ $material['linkName'] }}" />
							</div>
						</div>

						<div class="form-actions">
							<input class="btn btn-primary" type="submit" value="提交" />
							<input class="btn btn-primary" type="reset" value="重置" />
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	
	<form id="uploadImgForm" style="display:none;" method="post" action="{{ URL::route('admin.upload.icon') }}" enctype="multipart/form-data" target="upIframe"></form>
@stop

@section('jsSection')
<script type="text/javascript" src="/js/jquery.uniform.js"></script>
<script type="text/javascript" src="/js/select2.min.js"></script>
<script type="text/javascript" src="/js/jquery.form.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$('input[type=checkbox],input[type=radio]').uniform();
	$('select').select2();

	var type = $("select[name=type]").val();
	if(type != 'undefined'){
		$("." + type).show();
	}

	$("select[name=type]").change(function(){
		var type = $(this).val();
		$(".startpage").hide();
		$(".startpage input[type=text]").val("");
		$(".install").hide();
		$(".install input[type=text]").val("");
		$(".createlink").hide();
		$(".createlink input[type=text]").val("");
		$("." + type).show();
	});

	// 上传图标
	$(".show_image").change(function() {
		var _this = this;
		$(".picLoading").css("display", "block");
		var option = {
			dataType : 'json',
			error : function(XMLResponse) {
				alert('ERROR:' + XMLResponse.responseText);
				$(_this).find("img").after('<input type="file" id="upfile" name="uploadImg" size="40">');
				$(".picLoading").css("display", "none");
			},
			success : successHandler
		};
		if ($(this).children('input[type=file]').val() != '' && $(this).children('input[type=file]').val() != undefined) {
			$('#uploadImgForm').empty();
			$('#uploadImgForm').append($(this).children('input[type=file]'));
			$('#uploadImgForm').ajaxSubmit(option);
		}
		function successHandler(responseText, statusText) {
			if (responseText.status == 0) {
				$(_this).find("img").attr('src', '{{ Config::get('app.url') }}'+responseText.imgurl);
				$(_this).find('.picPreviewUrl').val('{{ Config::get('app.url') }}'+responseText.imgurl);
				$(_this).find("img").after('<input type="file" id="upfile" name="uploadImg" size="40">');
				$('#uploadImgForm').empty();
				$(".picLoading").css("display", "none");
			} else {
				alert('ERROR:' + responseText.status + ': ' + responseText.desc);
				$(".picLoading").css("display", "none");
				$(_this).find("img").after('<input type="file" id="upfile" name="uploadImg" size="40">');
				$('#uploadImgForm').empty();
			}
		}
	});
});
</script>
@stop
