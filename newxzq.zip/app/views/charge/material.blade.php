@extends('common.layout')

@section('cssSection')
<link rel="stylesheet" href="/css/uniform.css" />
<link rel="stylesheet" href="/css/select2.css" />
<link rel="stylesheet" href="/css/bootstrap-datetimepicker.min.css" />
<link rel="stylesheet" href="/css/statwell.css" />
<link rel="stylesheet" href="/css/charge.css" />
@stop

@section('header')
	<div id="content-header">
		<h1>物料统计</h1>
	</div>
	<div id="breadcrumb">
		<a href="/default" class="tip-bottom" data-original-title="回到首页"><i class="icon-home"></i> 管理首页</a>
		<a href="/charge/material"  class="tip-bottom" data-original-title="数据汇总">数据汇总</a>
		<a href="/charge/material" class="current">产品数据汇总</a>
	</div>
@stop

@section('content')
<div class="row-fluid">
	@if (Session::has('complete'))
	<div class="alertSection row-fluid">
		<div class="alert alert-success alert-block">
			<a class="close" data-dismiss="alert" href="javascript:void(0);">×</a>
			<h4 class="alert-heading">成功了!</h4>
			{{ Session::get('complete') }}
		</div>
	</div>
	@endif
	@if ($errors->all())
	<div class="alert alert-error alert-block">
		<a class="close" data-dismiss="alert" href="#">×</a>
		<h4 class="alert-heading">错误!</h4>
		@foreach($errors->all() as $error)
			{{ $error }}
		@endforeach
	</div>
	@endif
	<div class="statwell well">
		<span>
			<select name="materialId" style="width:150px;">
				<option value="0">--选择物料--</option>
				@if (isset($materials) and !empty($materials))
				@foreach ($materials as $val)
					<option value="{{ $val['id'] }}">{{ $val['name'] }}</option>
				@endforeach
				@endif
			</select>
		</span>
		<span>
			<div id="dateChooser" class="btn-group" data-value="month">
			  <button data-value="month" class="btn active">本月</button>
			  <button data-value="time" class="btn">自定义</button>
			</div>
		</span>
		<span class="timeSpan" style="display:none;">
			<div class="input-append date form_date">
			  <input class="input-small" id="time-start" style="width:120px;" type="text" readonly />
			  <span class="add-on"><i class="icon-time"></i></span>
			</div>
			<span> 到 </span>
			<div class="input-append date form_date">
			  <input class="input-small" id="time-end" style="width:120px;" type="text" readonly />
			  <span class="add-on"><i class="icon-time"></i></span>
			</div>
		</span>
		<button id="timeOkBtn" class="btn btn-primary">查询</button>
	</div>

	<div class="widget-box">
		<div class="widget-title">
			<span class="icon">
				<i class="icon-align-left"></i>
			</span>
			<h5>统计详情</h5>
			<h5 class="alertSpan hide"></h5>
			<div class="buttons">
				<a id="exportCSVBtn" href="javascript:void(0);" class="btn btn-mini btn-info">
					<i class="icon icon-share-alt icon-white"></i> 导出列表
				</a>
			</div>
		</div>
		<div class="widget-content nopadding">
			<table id="statTable" class="table table-bordered">
				<thead>
					<tr>
					</tr>
					<tr>
					</tr>
				</thead>
				<tbody></tbody>
			</table>
		</div>
	</div>
</div>
@stop

@section('jsSection')
<script type="text/javascript" src="/js/jquery.uniform.js"></script>
<script type="text/javascript" src="/js/select2.min.js"></script>
<script type="text/javascript" src="/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript" src="/js/bootstrap-datetimepicker.zh-CN.js"></script>
<script type="text/javascript" src="/js/mustache.js"></script>
<script type="text/javascript" src="/js/moment-locales.min.js"></script>
<script type="text/javascript" src="/js/stat.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$("#timeOkBtn").click(function(e){
		e.preventDefault();
		var timeType = $("#dateChooser").attr("data-value");

		if(!timeType || timeType=='') {
			showAlert("参数错误！","error");
			return false;
		}
		var duration = getDurationTime(timeType);
		var start = duration.start, end = duration.end;
		var materialId = $("select[name=materialId]").val();

		Mustache.tags = ["<%", "%>"];
		var tr_temp = $("#trTemp").html();
		var thTemp = $("#thTemp").html();
		
		var thead_tr = $("#statTable thead tr");
		thead_tr.empty();
		
		var tbody = $("#statTable tbody");
		tbody.empty();

		$.getJSON("/charge/data", {
			_t : "material",
			_mid : materialId,
			_s : start,
			_e : end
		}, function(data){
			if(data.code != 0 || data.data == undefined){
				showAlert("查询失败！","error");
				return;
			}
			var jsonnum=0;
			thead_tr.eq(0).append("<th></th>");
			$.each(data.data.materiallink,function(k,v){
				thead_tr.eq(0).append("<th colspan='"+v.count+"' >"+v.name+"</th>");
			});
			thead_tr.eq(1).append("<th>时间</th>");
			$.each(data.data.materiallink,function(key,val){
				$.each(data.data.items[[val.id]],function(k,v){
					jsonnum++;
					thead_tr.eq(1).append("<th>"+v.item+"</th>");
				});
			});
			var width_tmp=eval(60*jsonnum)+100;
			if($(".container-fluid").width()<width_tmp){
				$(".container-fluid").css("width",width_tmp);
			}
			$.each(data.data.data, function(k,v){
				tbody.append("<tr>");
				tbody.append("<td class=\"day\" >"+k+"</td>");
				$.each(v,function(key,val){
					$.each(val,function(keys,values){
						tbody.append("<td class=\"values\" >"+values+"</td>");
					});
				});
				tbody.append("</tr>");
			});
			var width_tmp=$("#statTable").width();
			if($(".container-fluid").width()<width_tmp){
				$(".container-fluid").css("width",width_tmp);
				$("#content-header").css("width",width_tmp+20);
				$("#breadcrumb").css("width",width_tmp);
			}
		});
	});
});
</script>
@stop