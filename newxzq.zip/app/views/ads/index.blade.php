@extends('common.layout')

@section('cssSection')
<link rel="stylesheet" href="/css/uniform.css" />
<link rel="stylesheet" href="/css/select2.css" />
@stop

@section('header')
	<div id="content-header">
		<h1>站点列表</h1>
	</div>
	<div id="breadcrumb">
		<a href="/default" class="tip-bottom" data-original-title="回到首页"><i class="icon-home"></i> 管理首页</a>
		<a href="/ad" class="current">广告列表</a>
	</div>
@stop

@section('content')

@if (Session::has('complete'))
<div class="alertSection row-fluid">
	<div class="alert alert-success alert-block">
		<a class="close" data-dismiss="alert" href="javascript:void(0);">×</a>
		<h4 class="alert-heading">成功了!</h4>
		{{ Session::get('complete') }}
	</div>
</div>
@endif

<div class="widget-box">
	<div class="widget-title">
		<span class="icon">
			<i class="icon-file"></i>
		</span>
		<h5>广告物料列表</h5>
	</div>
	<div class="widget-content nopadding">
		<table class="table table-bordered data-table">
			<thead>
				<tr>
					<th>站点ID</th>
					<th>站点名称</th>
					<th>下载器版本</th>
					<th>更新时间</th>
					<th>一键复制</th>
					<th>操作</th>
				</tr>
			</thead>
			<tbody>
				@foreach ($ads as $val)
				<tr>
					<td>{{ $val['siteId'] }}</td>
					<td><a target="_blank" href="http://api.zheguow.com/ad/{{ $val['siteId'] }}">{{ $val->site['name'] }}</a></td>
					<td>{{ $val->downer['name'] }}</td>
					<td>{{ $val['updated_at'] }}</td>
					<td>
						<select name="clone-site" class="clone-site" fid ="{{ $val['siteId'] }}"  style="margin: 0px;">
							<option value="0">--选择复制--</option>
							@foreach ($site as $v)
								<option  @if($val['change_id']==$v['id']) selected = "selected" @endif  value="{{ $v['id'] }}">{{ $v['name'] }}</option>
							@endforeach
						</select>
					</td>
					<td>
						<a class="btn btn-mini btn-primary" href="{{ URL::route('admin.ad.edit', ['id'=>$val['id']]) }}"><i class="icon-pencil icon-white"></i> 编辑</a>
						<a class="btn btn-mini btn-danger btnRemove" href="javascript:;" data-link="{{ URL::route('admin.ad.destroy', ['id'=>$val['id']]) }}"><i class="icon-remove icon-white"></i> 删除</a>
						<a class="btn btn-mini btn-warning" href="{{ URL::route('admin.ad.refresh', ['id'=>$val['id']]) }}"><i class="icon-refresh icon-white"></i> 刷新缓存</a>
					</td>
				</tr>
				@endforeach
			</tbody>
		</table>					
	</div>
</div>
@stop

@section('jsSection')
<script type="text/javascript" src="/js/select2.min.js"></script>
<script type="text/javascript" src="/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="/js/rest.js"></script>
<script type="text/javascript" src="/js/jquery.uniform.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	var rmAdHandler = function(){
		if(confirm("【注意】：确定要删除该广告吗？删除就不能恢复了！")) {
			if(confirm("【注意】：确定不是手滑点错了？点“确定”表示确实要删除！")) {
				if(confirm("【注意】：最后确认一次！我真的删除了哦！")) {
					window.location = $(this).attr("data-link");
				}
			}
		}
	}

	$('.data-table').dataTable({
		"bJQueryUI": true,
		"pageLength": 50,
		"sPaginationType": "full_numbers",
		"sDom": '<""l>t<"F"fp>',
		"bSort" : false;
		"language": {
			"paginate": {
			  "first": "首页",
			  "last": "尾页",
			  "previous": "上一页",
			  "next": "下一页"
			},
			"lengthMenu": "显示 _MENU_ 条记录",
			"search": "搜索:"
		}
	});

	$('input[type=checkbox],input[type=radio],input[type=file]').uniform();
	$('select').select2();

	$(".btnRemove").click(rmAdHandler);
});
</script>
	<script>
		$(function(){
			$(".clone-site").change(function(){
				var fid = $(this).attr("fid");
				var site_id = $(this).attr('value');
				$.ajax({
						type:"GET",
						url:"/ad",
						data: {id:site_id,fid:fid},
						async:true,
						success:function(data){

						}
					});
			});
		});
	</script>
@stop
