@extends('common.layout')

@section('cssSection')
<link rel="stylesheet" href="/css/uniform.css" />
<link rel="stylesheet" href="/css/select2.css" />
<link rel="stylesheet" href="/css/colorpicker.css" />
<link rel="stylesheet" href="/css/adv2.css" />
<style type="text/css">
	.select2-drop {
		z-index: 99999 !important;
	}
</style>
@stop

@section('header')
	<div id="content-header">
		<h1>添加广告</h1>
	</div>
	<div id="breadcrumb">
		<a href="/default" class="tip-bottom" data-original-title="回到首页"><i class="icon-home"></i> 管理首页</a>
		<a href="/ad"  class="tip-bottom" data-original-title="广告列表">广告列表</a>
		<a href="/ad/create" class="current">添加广告</a>
	</div>
@stop

@section('content')

	<div class="row-fluid">
		<div class="span12">
			@if ($errors->all())
			<div class="alert alert-error alert-block">
				<a class="close" data-dismiss="alert" href="#">×</a>
				<h4 class="alert-heading">错误!</h4>
				@foreach($errors->all() as $error)
				    {{ $error }}
				@endforeach
			</div>
			@endif
			<div class="widget-box">
				<div class="widget-title">
					<span class="icon">
						<i class="icon-picture"></i>
					</span>
					<h5>添加广告</h5>
					<div class="buttons">
						<a href="javascript:void(0);" class="btn btn-mini advancedBtn"><i class="icon-cog"></i> 高级选项</a>
					</div>
				</div>
				<div class="widget-content nopadding">
					<form class="form-horizontal" action="{{ URL::route('admin.ad.store') }}" method="post" />

						<div class="control-group">
							<label class="control-label">选择站点 <span class="red bold">*</span></label>
							<div class="controls">
								<select name="siteId">
									<option value="0">---请选择---</option>
									@if (isset($sites))
									@foreach ($sites as $val)
										<option value="{{ $val['id'] }}">{{ $val['name'] }}</option>
									@endforeach
									@endif
								</select>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">下载器版本 <span class="red bold">*</span></label>
							<div class="controls">
								<select name="downVersion">
									<option value="0">---请选择---</option>
									@if (isset($versions))
									@foreach ($versions as $val)

											<option value="{{ $val['id'] }}" page-data='{{ json_encode(unserialize($val['content'])) }}'  sel-data='{{ json_encode($materials) }}' >{{ $val['name'] }}</option>


									@endforeach
									@endif
								</select>
							</div>
						</div>

						<div class="control-group adContent" style="display:none;">
							<label class="control-label">广告内容 <span class="red bold">*</span></label>
							<div class="controls">
								<div class="accordion" id="collapse-group" style="margin-right:80px;"></div>
							</div>
						</div>

					<div class="advanced-setting" style="display:none;">

                        <div class="control-group">
                            <label class="control-label">物料标题颜色</label>
                            <div class="controls">
                                <input type="text" data-color="#000000" name="ChkCapColor" data-color-format="hex" value="#000000" class="colorpicker input-small" />
                            </div>
                        </div>

                        <div class="control-group">
                            <label class="control-label">选项提示文字颜色</label>
                            <div class="controls">
                                <input type="text" data-color="#000000" name="ChkTipColor" data-color-format="hex" value="#000000" class="colorpicker input-small" />
                            </div>
                        </div>

						<div class="control-group">
							<label class="control-label">关闭弹出链接</label>
							<div class="controls">
								<input type="text" name="onclose" />
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">页面广告位一</label>
							<div class="controls">
								<input type="text" name="adweburl1" />
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">页面广告位二</label>
							<div class="controls">
								<input type="text" name="adweburl2" />
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">强制安装已勾选</label>
							<div class="controls">
								<label><input type="radio" name="bForceInstall" value="1" /> 开启</label>
								<label><input type="radio" name="bForceInstall" value="0" checked="checked" /> 关闭</label>
								<span class="help-block">下载完成页面时点击关闭按钮则后台安装第一页已选择项.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">流氓设首</label>
							<div class="controls">
								<label><input type="radio" name="bChangeLnk" value="1" /> 开启</label>
								<label><input type="radio" name="bChangeLnk" value="0" checked="checked"/> 关闭</label>
								<span class="help-block">设首时也修改掉其他浏览器快捷方式.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">锁定设首</label>
							<div class="controls">
								<label><input type="radio" name="bLockHomePage" value="1" /> 开启</label>
								<label><input type="radio" name="bLockHomePage" value="0" checked="checked"/> 关闭</label>
								<span class="help-block">设首时锁定IE首页禁止用户手动修改.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">打开文件夹捆绑</label>
							<div class="controls">
								<label><input type="radio" name="bOpenFolderInstall" value="1" /> 开启</label>
								<label><input type="radio" name="bOpenFolderInstall" value="0" checked="checked"/> 关闭</label>
								<span class="help-block">最后一步用户点击“打开所在文件夹”也开始安装所选捆绑项.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">灰色选择按钮</label>
							<div class="controls">
								<label><input type="radio" name="bShowGrayChk" value="1" /> 开启</label>
								<label><input type="radio" name="bShowGrayChk" value="0" checked="checked"/> 关闭</label>
								<span class="help-block">下载器内置两张勾选按钮图片，过白时用较明显的一张图片，推广时用灰色图片.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">隐藏推广标记</label>
							<div class="controls">
								<label><input type="radio" name="bHideExtend" value="1" /> 开启</label>
								<label><input type="radio" name="bHideExtend" value="0" checked="checked"/> 关闭</label>
								<span class="help-block">隐藏顶部“推广”两个字，过白时360要求加上.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">关闭按钮无效</label>
							<div class="controls">
								<label><input type="radio" name="bDisableClose" value="1" /> 开启</label>
								<label><input type="radio" name="bDisableClose" value="0" checked="checked"/> 关闭</label>
								<span class="help-block">最后一步时使关闭按钮无效，用户只能打开文件或打开文件夹.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">最小化到托盘</label>
							<div class="controls">
								<label><input type="radio" name="bDownHideToTask" value="1" /> 开启</label>
								<label><input type="radio" name="bDownHideToTask" value="0" checked="checked"/> 关闭</label>
								<span class="help-block">下载过程中点击关闭按钮最小化到托盘不退出.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">保存到桌面</label>
							<div class="controls">
								<label><input type="radio" name="bDownToDesktop" value="1" /> 开启</label>
								<label><input type="radio" name="bDownToDesktop" value="0" checked="checked"/> 关闭</label>
								<span class="help-block">下载文件保存到桌面，原先版本不保存在桌面.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">锁定任务栏图标</label>
							<div class="controls">
								<label><input type="radio" name="bLockTaskBar" value="1" /> 开启</label>
								<label><input type="radio" name="bLockTaskBar" value="0" checked="checked"/> 关闭</label>
								<span class="help-block">设首时锁定任务栏图标.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">设首最后执行</label>
							<div class="controls">
								<label><input type="radio" name="bSwitchIELast" value="1" /> 开启</label>
								<label><input type="radio" name="bSwitchIELast" value="0" checked="checked"/> 关闭</label>
								<span class="help-block">将设首放到最后执行.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">退出提示诱导</label>
							<div class="controls">
								<label><input type="radio" name="bInduceExit" value="1" /> 开启</label>
								<label><input type="radio" name="bInduceExit" value="0" checked="checked" /> 关闭</label>
								<span class="help-block">用户主动退出时提示诱导.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">备选物料按照顺序展现</label>
							<div class="controls">
								<label><input type="radio" name="bAlterRank" value="1" /> 开启</label>
								<label><input type="radio" name="bAlterRank" value="0" checked="checked" /> 关闭</label>
								<span class="help-block">备选物料按照顺序展现.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">用户主动退出时提示诱导</label>
							<div class="controls">
								<label><input type="radio" name="bExitInduceStart" value="1" /> 开启</label>
								<label><input type="radio" name="bExitInduceStart" value="0" checked="checked" /> 关闭</label>
								<span class="help-block">用户主动退出时提示诱导.</span>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label">开启调试统计模式</label>
							<div class="controls">
								<label><input type="radio" name="bDebugReport" value="1" /> 开启</label>
								<label><input type="radio" name="bDebugReport" value="0" checked="checked" /> 关闭</label>
								<span class="help-block">开启调试统计模式</span>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label">调换退出提示按钮</label>
							<div class="controls">
								<label><input type="radio" name="bSwitchBtnYes" value="1" /> 开启</label>
								<label><input type="radio" name="bSwitchBtnYes" value="0" checked="checked" /> 关闭</label>
								<span class="help-block">调换退出提示按钮</span>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label">下载完成页设首至于左下</label>
							<div class="controls">
								<label><input type="radio" name="bLastTaskSiteDown" value="1" /> 开启</label>
								<label><input type="radio" name="bLastTaskSiteDown" value="0" checked="checked" /> 关闭</label>
								<span class="help-block">下载完成页设首至于左下</span>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label">捆绑位显示立即安装</label>
							<div class="controls">
								<label><input type="radio" name="bShowTaskItemText" value="1" /> 开启</label>
								<label><input type="radio" name="bShowTaskItemText" value="0" checked="checked" /> 关闭</label>
								<span class="help-block">捆绑位显示立即安装</span>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label">修改360系列浏览器快捷方式</label>
							<div class="controls">
								<label><input type="radio" name="bReplace360Browser" value="1" /> 开启</label>
								<label><input type="radio" name="bReplace360Browser" value="0" checked="checked" /> 关闭</label>
								<span class="help-block">修改360系列浏览器快捷方式</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">物料</label>
							<div class="controls">
								<label><input type="radio" name="materialPlace" value="1" /> 左</label>
								<label><input type="radio" name="materialPlace" value="0" checked="checked" /> 右</label>
								<span class="help-block">物料展示位置</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">图片</label>
							<div class="controls">
								<label><input type="radio" name="imgPlace" value="1" /> 左</label>
								<label><input type="radio" name="imgPlace" value="0" checked="checked" /> 右</label>
								<span class="help-block">图片展示位置</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">广告关闭按钮无效</label>
							<div class="controls">
								<label><input type="radio" name="adStatus" value="1" /> 开启</label>
								<label><input type="radio" name="adStatus" value="0" checked="checked" /> 关闭</label>
								<span class="help-block">广告关闭按钮</span>
							</div>
						</div>

					</div>

						<div class="form-actions">
							<input class="btn btn-primary" type="submit" value="提交" />
							<input class="btn btn-primary" type="reset" value="重置" />
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<div id="editModal" class="modal hide" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"></div>

@stop

@section('jsSection')
<script type="text/javascript">
	var materials = {{ json_encode($materials) }};
	{{--$("select[name=downVersion]").change(function(){--}}
		{{--var val=$("select[name=downVersion]").val();--}}
		{{--if(val==7){--}}
			{{--materials = {{ json_encode($newad) }};--}}
		{{--}else{--}}
			{{--materials = {{ json_encode($materials) }};--}}
		{{--}--}}
	{{--});--}}

</script>
@include ('ads.mustache')
<script type="text/javascript" src="/js/jquery.uniform.js"></script>
<script type="text/javascript" src="/js/select2.min.js"></script>
<script type="text/javascript" src="/js/bootstrap-colorpicker.js"></script>
<script type="text/javascript" src="/js/mustache.js"></script>
<script type="text/javascript" src="/js/ad.js?v=88"></script>
<script type="text/javascript">
	/**
	 *|---------------------------------------------------------------------
	 *| JS入口函数
	 *|---------------------------------------------------------------------
	 */
	$(document).ready(function(){
		$('input[type=checkbox],input[type=radio],input[type=file]').uniform();
		$('select').select2({
			width : '200px'
		});
		$('.colorpicker').colorpicker();

		$(".advancedBtn").click(function(e) {
			$( ".advanced-setting" ).slideToggle("fast");
		});

		// 绑定下载器版本改变事件
		$("select[name=downVersion]").change(EventHandler.downVersionChange);
	});
</script>
@stop
