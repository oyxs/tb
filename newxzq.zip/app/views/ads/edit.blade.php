@extends('common.layout')

@section('cssSection')
	<link rel="stylesheet" href="/css/uniform.css" />
	<link rel="stylesheet" href="/css/select2.css" />
	<link rel="stylesheet" href="/css/colorpicker.css" />
	<link rel="stylesheet" href="/css/adv2.css" />
	<style type="text/css">
		.select2-drop {
			z-index: 99999 !important;
		}
		.dropdown-menu{
			z-index:99999 !important;
		}
	</style>
@stop

@section('header')
	<div id="content-header">
		<h1>编辑广告</h1>
	</div>
	<div id="breadcrumb">
		<a href="/default" class="tip-bottom" data-original-title="回到首页"><i class="icon-home"></i> 管理首页</a>
		<a href="/ad"  class="tip-bottom" data-original-title="广告列表">广告列表</a>
		<a href="{{ URL::route('admin.ad.edit',['id'=>$ad['id']]) }}" class="current">编辑广告</a>
	</div>
@stop

@section('content')

	<div class="row-fluid">
		<div class="span12">
			@if ($errors->all())
				<div class="alert alert-error alert-block">
					<a class="close" data-dismiss="alert" href="#">×</a>
					<h4 class="alert-heading">错误!</h4>
					@foreach($errors->all() as $error)
						{{ $error }}
					@endforeach
				</div>
			@endif
			<div class="widget-box">
				<div class="widget-title">
					<span class="icon">
						<i class="icon-picture"></i>
					</span>
					<h5>编辑广告</h5>
					<div class="buttons">
						<a href="javascript:void(0);" class="btn btn-mini advancedBtn"><i class="icon-cog"></i> 高级选项</a>
					</div>
				</div>
				<div class="widget-content nopadding">
					<form class="form-horizontal" action="{{ URL::route('admin.ad.update',['id'=>$ad['id']]) }}" method="post" />

					<div class="control-group">
						<label class="control-label">选择站点 <span class="red bold">*</span></label>
						<div class="controls">
							<select name="siteId">
								<option value="0">---请选择---</option>
								@if (isset($sites))
									@foreach ($sites as $val)
										<option value="{{ $val['id'] }}" {{ $val['id'] == $ad['siteId'] ? 'selected="selected"' : '' }}>{{ $val['name'] }}</option>
									@endforeach
								@endif
							</select>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label">下载器版本 <span class="red bold">*</span></label>
						<div class="controls">
							<select name="downVersion">
								<option value="0">---请选择---</option>
								@if (isset($versions))
									@foreach ($versions as $val)
										<option value="{{ $val['id'] }}" {{ $val['id'] == $ad['downVersion'] ? 'selected="selected"' : '' }} page-data='{{ json_encode(unserialize($val['content'])) }}' sel-data='{{ json_encode($materials) }}'>{{ $val['name'] }}</option>
									@endforeach
								@endif
							</select>
						</div>
					</div>

					<div class="control-group adContent">
						<label class="control-label">广告内容 <span class="red bold">*</span></label>
						<div class="controls">
							<div class="accordion" id="collapse-group" style="margin-right:80px;">

								@foreach (unserialize($ad->downer['content']) as $key => $val)

									<div class="accordion-group widget-box">
										<div class="accordion-heading">
											<div class="widget-title">
												<a data-parent="#collapse-group" href="#{{ $key }}" data-toggle="collapse">
													<span class="icon"><i class="icon-th-list"></i></span><h5>{{ $val['name'] }}</h5>
												</a>
											</div>
										</div>
										<div class="collapse accordion-body" id="{{ $key }}">
											<div class="widget-content nopadding width-half">
												<table class="table table-striped table-bordered">
													<thead>
													<tr>
														<th width="45%">物料名称1</th>
														<th width="30%">备选物料1</th>
														<th width="25%">操作1</th>
													</tr>
													</thead>
													<tbody>

													@for ($i = 0; $i < $val['num']; $i++)
														<tr id="1_{{ $key }}_{{ $i }}" class="mater1">
															<td class="materName">
																<i class="icon-ok-sign"></i> <span class="blue">{{ isset($ad['content'][0][$key][$i]['name'])?$ad['content'][0][$key][$i]['name']:'' }}</span>
															</td>
															<td class="altMaterName">
																<span class="blue">{{ isset($ad['content'][0][$key][$i]['altname']) ? $ad['content'][0][$key][$i]['altname'] : '' }}</span>
															</td>
															<td class="materOptions">
																<input type="hidden" name="content[0][{{ $key }}][]" value='{{ empty($ad['content'][0][$key][$i])?'':json_encode($ad['content'][0][$key][$i]) }}'  />
																<a href="javascript:void(0);" page-id="{{ $key }}" item-id="1_{{ $key }}_{{ $i }}" class="tip-top itemEditBtn" data-original-title="编辑"><i class="icon-pencil"></i></a>
																<a href="javascript:void(0);" page-id="{{ $key }}" item-id="1_{{ $key }}_{{ $i }}" class="tip-top itemMoveBtn" data-original-title="移动至"><i class="icon-move"></i></a>
																<a href="javascript:void(0);" page-id="{{ $key }}" item-id="1_{{ $key }}_{{ $i }}" class="tip-top itemUpBtn" data-original-title="上移"><i class="icon-arrow-up"></i></a>
																<a href="javascript:void(0);" page-id="{{ $key }}" item-id="1_{{ $key }}_{{ $i }}" class="tip-top itemDownBtn" data-original-title="下移"><i class="icon-arrow-down"></i></a>
															</td>
														</tr>

													@endfor

													</tbody>
												</table>
											</div>
											<div class="widget-content nopadding width-half">
												<table class="table table-striped table-bordered">
													<thead>
													<tr>
														<th width="45%">物料名称2</th>
														<th width="30%">备选物料2</th>
														<th width="25%">操作2</th>
													</tr>
													</thead>
													<tbody>

													@for ($i = 0; $i < $val['num']; $i++)

														<tr id="2_{{ $key }}_{{ $i }}"  class="mater2">
															<td class="materName">
																<i class="icon-ok-sign"></i> <span class="blue">{{ isset($ad['content'][1][$key][$i]['name'])?$ad['content'][1][$key][$i]['name']:'' }}</span>
															</td>
															<td class="altMaterName">
																<span class="blue">{{ isset($ad['content'][1][$key][$i]['altname']) ? $ad['content'][1][$key][$i]['altname'] : '' }}</span>
															</td>
															<td class="materOptions">
																<input type="hidden" name="content[1][{{ $key }}][]" value='{{ empty($ad['content'][1][$key][$i])?'':json_encode($ad['content'][1][$key][$i]) }}'  />
																<a href="javascript:void(0);" page-id="{{ $key }}" item-id="2_{{ $key }}_{{ $i }}" class="tip-top itemEditBtn" data-original-title="编辑"><i class="icon-pencil"></i></a>
																<a href="javascript:void(0);" page-id="{{ $key }}" item-id="2_{{ $key }}_{{ $i }}" class="tip-top itemMoveBtn" data-original-title="移动至"><i class="icon-move"></i></a>
																<a href="javascript:void(0);" page-id="{{ $key }}" item-id="2_{{ $key }}_{{ $i }}" class="tip-top itemUpBtn" data-original-title="上移"><i class="icon-arrow-up"></i></a>
																<a href="javascript:void(0);" page-id="{{ $key }}" item-id="2_{{ $key }}_{{ $i }}" class="tip-top itemDownBtn" data-original-title="下移"><i class="icon-arrow-down"></i></a>
															</td>
														</tr>

													@endfor

													</tbody>
												</table>
											</div>
										</div>
									</div>

								@endforeach

							</div>
						</div>
					</div>

					<div class="advanced-setting" style="display:none;">

						<div class="control-group">
							<label class="control-label">物料标题颜色</label>
							<div class="controls">
								<input type="text" data-color="{{ isset($ad['extra']['ChkCapColor'])?$ad['extra']['ChkCapColor']:'#000000' }}" name="ChkCapColor" data-color-format="hex" value="{{ isset($ad['extra']['ChkCapColor'])?$ad['extra']['ChkCapColor']:'#000000' }}" class="colorpicker input-small" />
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">选项提示文字颜色</label>
							<div class="controls">
								<input type="text" data-color="{{ isset($ad['extra']['ChkCapColor'])?$ad['extra']['ChkTipColor']:'#000000' }}" name="ChkTipColor" data-color-format="hex" value="{{ isset($ad['extra']['ChkCapColor'])?$ad['extra']['ChkTipColor']:'#000000' }}" class="colorpicker input-small" />
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">关闭弹出链接</label>
							<div class="controls">
								<input type="text" name="onclose" value="{{ isset($ad['extra']['onclose'])?$ad['extra']['onclose']:'' }}" />
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">页面广告位一</label>
							<div class="controls">
								<input type="text" name="adweburl1" value="{{ isset($ad['extra']['adweburl1'])?$ad['extra']['adweburl1']:'' }}" />
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">页面广告位二</label>
							<div class="controls">
								<input type="text" name="adweburl2" value="{{ isset($ad['extra']['adweburl2'])?$ad['extra']['adweburl2']:'' }}" />
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">强制安装已勾选</label>
							<div class="controls">
								@if(isset($ad['extra']['bForceInstall']) and $ad['extra']['bForceInstall']=='1')
									<label><input type="radio" name="bForceInstall" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="bForceInstall" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="bForceInstall" value="1" /> 开启</label>
									<label><input type="radio" name="bForceInstall" value="0" checked="checked" /> 关闭</label>
								@endif
								<span class="help-block">下载完成页面时点击关闭按钮则后台安装第一页已选择项.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">流氓设首</label>
							<div class="controls">
								@if(isset($ad['extra']['bChangeLnk']) and $ad['extra']['bChangeLnk']=='1')
									<label><input type="radio" name="bChangeLnk" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="bChangeLnk" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="bChangeLnk" value="1" /> 开启</label>
									<label><input type="radio" name="bChangeLnk" value="0" checked="checked" /> 关闭</label>
								@endif
								<span class="help-block">设首时也修改掉其他浏览器快捷方式.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">锁定设首</label>
							<div class="controls">
								@if(isset($ad['extra']['bLockHomePage']) and $ad['extra']['bLockHomePage']=='1')
									<label><input type="radio" name="bLockHomePage" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="bLockHomePage" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="bLockHomePage" value="1" /> 开启</label>
									<label><input type="radio" name="bLockHomePage" value="0" checked="checked" /> 关闭</label>
								@endif
								<span class="help-block">设首时锁定IE首页禁止用户手动修改.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">打开文件夹捆绑</label>
							<div class="controls">
								@if(isset($ad['extra']['bOpenFolderInstall']) and $ad['extra']['bOpenFolderInstall']=='1')
									<label><input type="radio" name="bOpenFolderInstall" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="bOpenFolderInstall" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="bOpenFolderInstall" value="1" /> 开启</label>
									<label><input type="radio" name="bOpenFolderInstall" value="0" checked="checked" /> 关闭</label>
								@endif
								<span class="help-block">最后一步用户点击“打开所在文件夹”也开始安装所选捆绑项.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">灰色选择按钮</label>
							<div class="controls">
								@if(isset($ad['extra']['bShowGrayChk']) and $ad['extra']['bShowGrayChk']=='1')
									<label><input type="radio" name="bShowGrayChk" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="bShowGrayChk" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="bShowGrayChk" value="1" /> 开启</label>
									<label><input type="radio" name="bShowGrayChk" value="0" checked="checked" /> 关闭</label>
								@endif
								<span class="help-block">下载器内置两张勾选按钮图片，过白时用较明显的一张图片，推广时用灰色图片.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">隐藏推广标记</label>
							<div class="controls">
								@if(isset($ad['extra']['bHideExtend']) and $ad['extra']['bHideExtend']=='1')
									<label><input type="radio" name="bHideExtend" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="bHideExtend" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="bHideExtend" value="1" /> 开启</label>
									<label><input type="radio" name="bHideExtend" value="0" checked="checked" /> 关闭</label>
								@endif
								<span class="help-block">隐藏顶部“推广”两个字，过白时360要求加上.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">关闭按钮无效</label>
							<div class="controls">
								@if(isset($ad['extra']['bDisableClose']) and $ad['extra']['bDisableClose']=='1')
									<label><input type="radio" name="bDisableClose" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="bDisableClose" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="bDisableClose" value="1" /> 开启</label>
									<label><input type="radio" name="bDisableClose" value="0" checked="checked" /> 关闭</label>
								@endif
								<span class="help-block">最后一步时使关闭按钮无效，用户只能打开文件或打开文件夹.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">最小化到托盘</label>
							<div class="controls">
								@if(isset($ad['extra']['bDownHideToTask']) and $ad['extra']['bDownHideToTask']=='1')
									<label><input type="radio" name="bDownHideToTask" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="bDownHideToTask" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="bDownHideToTask" value="1" /> 开启</label>
									<label><input type="radio" name="bDownHideToTask" value="0" checked="checked" /> 关闭</label>
								@endif
								<span class="help-block">下载过程中点击关闭按钮最小化到托盘不退出.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">保存到桌面</label>
							<div class="controls">
								@if(isset($ad['extra']['bDownToDesktop']) and $ad['extra']['bDownToDesktop']=='1')
									<label><input type="radio" name="bDownToDesktop" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="bDownToDesktop" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="bDownToDesktop" value="1" /> 开启</label>
									<label><input type="radio" name="bDownToDesktop" value="0" checked="checked" /> 关闭</label>
								@endif
								<span class="help-block">下载文件保存到桌面，原先版本不保存在桌面.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">锁定任务栏图标</label>
							<div class="controls">
								@if(isset($ad['extra']['bLockTaskBar']) and $ad['extra']['bLockTaskBar']=='1')
									<label><input type="radio" name="bLockTaskBar" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="bLockTaskBar" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="bLockTaskBar" value="1" /> 开启</label>
									<label><input type="radio" name="bLockTaskBar" value="0" checked="checked"/> 关闭</label>
								@endif
								<span class="help-block">设首时锁定任务栏图标.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">设首最后执行</label>
							<div class="controls">
								@if(isset($ad['extra']['bSwitchIELast']) and $ad['extra']['bSwitchIELast']=='1')
									<label><input type="radio" name="bSwitchIELast" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="bSwitchIELast" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="bSwitchIELast" value="1" /> 开启</label>
									<label><input type="radio" name="bSwitchIELast" value="0" checked="checked"/> 关闭</label>
								@endif
								<span class="help-block">将设首放到最后执行.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">退出提示诱导</label>
							<div class="controls">
								@if(isset($ad['extra']['bInduceExit']) and $ad['extra']['bInduceExit']=='1')
									<label><input type="radio" name="bInduceExit" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="bInduceExit" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="bInduceExit" value="1" /> 开启</label>
									<label><input type="radio" name="bInduceExit" value="0" checked="checked"/> 关闭</label>
								@endif
								<span class="help-block">用户主动退出时提示诱导.</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">备选物料按照顺序展现</label>
							<div class="controls">
								@if(isset($ad['extra']['bAlterRank']) and $ad['extra']['bAlterRank']=='1')
									<label><input type="radio" name="bAlterRank" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="bAlterRank" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="bAlterRank" value="1" /> 开启</label>
									<label><input type="radio" name="bAlterRank" value="0" checked="checked"/> 关闭</label>
								@endif
								<span class="help-block">备选物料按照顺序展现</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">退出提示诱导开始下载</label>
							<div class="controls">
								@if(isset($ad['extra']['bExitInduceStart']) and $ad['extra']['bExitInduceStart']=='1')
									<label><input type="radio" name="bExitInduceStart" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="bExitInduceStart" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="bExitInduceStart" value="1" /> 开启</label>
									<label><input type="radio" name="bExitInduceStart" value="0" checked="checked"/> 关闭</label>
								@endif
								<span class="help-block">退出提示诱导开始下载</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">开启调试统计模式</label>
							<div class="controls">
								@if(isset($ad['extra']['bDebugReport']) and $ad['extra']['bDebugReport']=='1')
									<label><input type="radio" name="bDebugReport" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="bDebugReport" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="bDebugReport" value="1" /> 开启</label>
									<label><input type="radio" name="bDebugReport" value="0" checked="checked"/> 关闭</label>
								@endif
								<span class="help-block">开启调试统计模式</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">调换退出提示按钮</label>
							<div class="controls">
								@if(isset($ad['extra']['bSwitchBtnYes']) and $ad['extra']['bSwitchBtnYes']=='1')
									<label><input type="radio" name="bSwitchBtnYes" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="bSwitchBtnYes" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="bSwitchBtnYes" value="1" /> 开启</label>
									<label><input type="radio" name="bSwitchBtnYes" value="0" checked="checked"/> 关闭</label>
								@endif
								<span class="help-block">调换退出提示按钮</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">下载完成页设首至于左下</label>
							<div class="controls">
								@if(isset($ad['extra']['bLastTaskSiteDown']) and $ad['extra']['bLastTaskSiteDown']=='1')
									<label><input type="radio" name="bLastTaskSiteDown" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="bLastTaskSiteDown" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="bLastTaskSiteDown" value="1" /> 开启</label>
									<label><input type="radio" name="bLastTaskSiteDown" value="0" checked="checked"/> 关闭</label>
								@endif
								<span class="help-block">下载完成页设首至于左下</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">捆绑位显示立即安装</label>
							<div class="controls">
								@if(isset($ad['extra']['bShowTaskItemText']) and $ad['extra']['bShowTaskItemText']=='1')
									<label><input type="radio" name="bShowTaskItemText" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="bShowTaskItemText" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="bShowTaskItemText" value="1" /> 开启</label>
									<label><input type="radio" name="bShowTaskItemText" value="0" checked="checked"/> 关闭</label>
								@endif
								<span class="help-block">捆绑位显示立即安装</span>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">修改360系列浏览器快捷方式</label>
							<div class="controls">
								@if(isset($ad['extra']['bReplace360Browser']) and $ad['extra']['bReplace360Browser']=='1')
									<label><input type="radio" name="bReplace360Browser" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="bReplace360Browser" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="bReplace360Browser" value="1" /> 开启</label>
									<label><input type="radio" name="bReplace360Browser" value="0" checked="checked"/> 关闭</label>
								@endif
								<span class="help-block">修改360系列浏览器快捷方式</span>
							</div>
						</div>
						<div class="control-group">
							<label class="control-label">物料</label>
							<div class="controls">
								@if(isset($ad['extra']['materialPlace']) and $ad['extra']['materialPlace']=='1')
									<label><input type="radio" name="materialPlace" value="1" checked="checked" /> 左</label>
									<label><input type="radio" name="materialPlace" value="0" /> 右</label>
								@else
									<label><input type="radio" name="materialPlace" value="1" /> 左</label>
									<label><input type="radio" name="materialPlace" value="0" checked="checked"/> 右</label>
								@endif
								<span class="help-block">物料位置</span>
							</div>
						</div>
						<div class="control-group">
							<label class="control-label">图片</label>
							<div class="controls">
								@if(isset($ad['extra']['imgPlace']) and $ad['extra']['imgPlace']=='1')
									<label><input type="radio" name="imgPlace" value="1" checked="checked" /> 左</label>
									<label><input type="radio" name="imgPlace" value="0" /> 右</label>
								@else
									<label><input type="radio" name="imgPlace" value="1" /> 左</label>
									<label><input type="radio" name="imgPlace" value="0" checked="checked"/> 右</label>
								@endif
								<span class="help-block">图片位置</span>
							</div>
						</div>
						<div class="control-group">
							<label class="control-label">广告关闭按钮无效</label>
							<div class="controls">
								@if(isset($ad['extra']['adStatus']) and $ad['extra']['adStatus']=='1')
									<label><input type="radio" name="adStatus" value="1" checked="checked" /> 开启</label>
									<label><input type="radio" name="adStatus" value="0" /> 关闭</label>
								@else
									<label><input type="radio" name="adStatus" value="1" /> 开启</label>
									<label><input type="radio" name="adStatus" value="0" checked="checked"/> 关闭</label>
								@endif
								<span class="help-block">广告关闭按钮</span>
							</div>
						</div>

					</div>

					<div class="form-actions">
						<input class="btn btn-primary" type="submit" value="提交" />
						<input class="btn btn-primary" type="reset" value="重置" />
					</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<div id="editModal" class="modal hide" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"></div>
	<div id="moveModal" class="modal hide" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"></div>

@stop

@section('jsSection')
	<script type="text/javascript">
		var materials = {{ json_encode($materials) }};
	</script>
	@include ('ads.mustache')
	<script type="text/javascript" src="/js/jquery.uniform.js"></script>
	<script type="text/javascript" src="/js/select2.min.js"></script>
	<script type="text/javascript" src="/js/bootstrap-colorpicker.js"></script>
	<script type="text/javascript" src="/js/mustache.js"></script>
	<script type="text/javascript" src="/js/ad.js?v=33332"></script>
	<script type="text/javascript">
		/**
		 *|---------------------------------------------------------------------
		 *| JS入口函数
		 *|---------------------------------------------------------------------
		 */
		$(document).ready(function(){
			$('input[type=checkbox],input[type=radio],input[type=file]').uniform();
			$('select').select2({
				width : '200px'
			});

			$("select[name=siteId]").select2("readonly", true);
			$('.colorpicker').colorpicker();

			$(".advancedBtn").click(function(e) {
				$( ".advanced-setting" ).slideToggle("fast");
			});

			// 绑定下载器版本改变事件
			$("select[name=downVersion]").change(EventHandler.downVersionChange);

			$(".adContent .itemEditBtn").click(EventHandler.itemEditBtnClick);
			$(".adContent .itemMoveBtn").click(EventHandler.itemMoveBtnClick);
			$(".adContent .itemUpBtn").click(EventHandler.itemUpBtnClick);
			$(".adContent .itemDownBtn").click(EventHandler.itemDownBtnClick);
		});
	</script>
@stop