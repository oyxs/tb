@extends('common.layout')
@section('cssSection')
<link rel="stylesheet" href="/css/uniform.css" />
<link rel="stylesheet" href="/css/select2.css" />
<link rel="stylesheet" href="/css/bootstrap-datetimepicker.min.css" />
<link rel="stylesheet" href="/css/statwell.css" />
<link rel="stylesheet" href="/css/charge.css" />
@stop

@section('header')
	<div id="content-header">
		<h1>站点产品详细数据</h1>
	</div>
	<div id="breadcrumb">
		<a href="/default" class="tip-bottom" data-original-title="回到首页"><i class="icon-home"></i> 管理首页</a>
		<a href="/charge/material"  class="tip-bottom" data-original-title="所有产品数据统计">所有产品数据统计</a>
		<a href="/chargestat/index" class="current">站点产品详细数据</a>
	</div>
@stop

@section('content')
<div class="row-fluid">
	<div class="statwell well">
		<select name="siteId" style="width:120px;">
			<option value="0">--选择站点--</option>
			@if (isset($sites) and !empty($sites))
			@foreach ($sites as $val)
				<option value="{{ $val['id'] }}">{{ $val['name'] }}</option>
			@endforeach
			@endif
		</select>
		<span>
			<select name="materialId" style="width:150px;">
				<option value="0">--选择物料--</option>
				@if (isset($materials) and !empty($materials))
				@foreach ($materials as $val)
					<option value="{{ $val['id'] }}">{{ $val['name'] }}</option>
				@endforeach
				@endif
			</select>
		</span>
		<span>
			<div id="dateChooser" class="btn-group" data-value="week">
			  <button data-value="week" class="btn active">本周</button>
			  <button data-value="month" class="btn">本月</button>
			  <button data-value="time" class="btn">自定义</button>
			</div>
		</span>
		<span class="timeSpan" style="display:none;">
			<div class="input-append date form_date">
			  <input class="input-small" id="time-start" style="width:110px;" type="text" />
			  <span class="add-on"><i class="icon-time"></i></span>
			</div>
			<span> 到 </span>
			<div class="input-append date form_date">
			  <input class="input-small" id="time-end" style="width:110px;" type="text" />
			  <span class="add-on"><i class="icon-time"></i></span>
			</div>
		</span>
		<button id="timeOkBtn" class="btn btn-primary">查询</button>
	</div>

	<div class="widget-box">
		<div class="widget-title">
			<span class="icon">
				<i class="icon-align-left"></i>
			</span>
			<h5>统计详情</h5>
			<h5 class="alertSpan hide"></h5>
			<div class="buttons">
				<a id="exportExcelBtn" href="javascript:void(0);" class="btn btn-mini btn-info">
					<i class="icon icon-share-alt icon-white"></i> 导出列表
				</a>
			</div>
		</div>
		<div class="widget-content nopadding">
			<table id="statTable" class="table table-bordered">
				<thead>
					<tr></tr>
					<tr></tr>
				</thead>
				<tbody></tbody>
			</table>
		</div>
	</div>
</div>

@stop

@section('jsSection')
<script type="text/javascript" src="/js/jquery.uniform.js"></script>
<script type="text/javascript" src="/js/select2.min.js"></script>
<script type="text/javascript" src="/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript" src="/js/bootstrap-datetimepicker.zh-CN.js"></script>
<script type="text/javascript" src="/js/mustache.js"></script>
<script type="text/javascript" src="/js/moment-locales.min.js"></script>
<script type="text/javascript" src="/js/stat.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$("#exportExcelBtn").click(function(e){
		e.preventDefault();
		var timeType = $("#dateChooser").attr("data-value");

		if(!timeType || timeType=='') {
			showAlert("参数错误！","error");
			return false;
		}
		var duration = getDurationTime(timeType);
		var start = duration.start, end = duration.end;
		var materialId = $("select[name=materialId]").val();
		var siteId = $("select[name=siteId]").val();
		var uri = {
			_sid : siteId,
			_mid : materialId,
			_s : start,
			_e : end,
			is_xls : 1
		};
		window.open("/chargestat/data?"+$.param(uri));
	});

	$("#timeOkBtn").click(function(e){
		e.preventDefault();
		var timeType = $("#dateChooser").attr("data-value");

		if(!timeType || timeType=='') {
			showAlert("参数错误！","error");
			return false;
		}
		var duration = getDurationTime(timeType);
		var start = duration.start, end = duration.end;
		var materialId = $("select[name=materialId]").val();
		var siteId = $("select[name=siteId]").val();

		Mustache.tags = ["<%", "%>"];
		var tr_temp = $("#trTemp").html();
		var thTemp = $("#thTemp").html();
		
		var thead_tr = $("#statTable thead tr");
		thead_tr.empty();
		
		var tbody = $("#statTable tbody");
		tbody.empty();

		$.getJSON("/chargestat/data", {
			_sid : siteId,
			_mid : materialId,
			_s : start,
			_e : end,
			is_xls : 0
		}, function(data){
			var colspan=0;
			if(data.code != 0 || data.data == undefined){
				showAlert("查询失败！","error");
				return;
			}
			thead_tr.eq(0).append("<th></th>");
			$.each(data.data.material,function(k,v){
				colspan=6;
				$.each(data.data.chargeitems[k],function(key,val){
					colspan++;
				});
				thead_tr.eq(0).append("<th class= \"borderLeft borderRight borderTop\" colspan='"+colspan+"' >"+v+"</th>");
			});
			var jsonnum=0;
			thead_tr.eq(1).append("<th>时间</th>");
			$.each(data.data.material,function(k,v){
				jsonnum+=7;
				thead_tr.eq(1).append("<th class= \"borderLeft\">展现</th><th>勾选</th><th>成功</th>");
				$.each(data.data.chargeitems[k],function(key,val){
					thead_tr.eq(1).append("<th>"+val.item+"</th>");
					jsonnum++;
				});
				thead_tr.eq(1).append("<th>百分比</th><th>收益</th><th class= \"borderRight\">万次收益</th>");
			});
			var width_tmp=eval(60*jsonnum)+100;
			if($(".container-fluid").width()<width_tmp){
				$(".container-fluid").css("width",width_tmp);
			}
			var str='';
			$.each(data.data.data,function(day,values){
				 str += "<tr><td>"+day+"</td>";
				$.each(data.data.material,function(k,v){
					if(typeof(values[k]) != "undefined"){
						str += "<td class= \"borderLeft\">"+values[k]['show']+"</td><td>"+values[k]['check']+"</td><td>"+values[k]['ok']+"</td>";
						$.each(data.data.chargeitems[k],function(key,val){
							str += "<td>"+values[k][val.id]['chargedata']+"</td>";
						});
						str += "<td>"+values[k]['percent']+"</td><td>"+values[k]['sumincome']+"</td>";
						if(values[k]['tincome']<600){
							str +="<td class= \"red borderRight\" >"+values[k]['tincome']+"</td>";
						}else{
							str +="<td class= \"borderRight\">"+values[k]['tincome']+"</td>";
						}
					}else{
						str += "<td class= \"borderLeft\"></td><td></td><td></td>";
						$.each(data.data.chargeitems[k],function(key,val){
							str += "<td></td>";
						});
						str += "<td></td><td></td><td class= \"borderRight\"></td>";
					}
				});
				str += "</tr>";
			});
			tbody.append(str);
		});
	});
});
</script>
@stop