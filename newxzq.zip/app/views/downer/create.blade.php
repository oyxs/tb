@extends('common.layout')

@section('cssSection')
<link rel="stylesheet" href="/css/uniform.css" />
<link rel="stylesheet" href="/css/select2.css" />
@stop

@section('header')
	<div id="content-header">
		<h1>添加下载器</h1>
	</div>
	<div id="breadcrumb">
		<a href="/default" class="tip-bottom" data-original-title="回到首页"><i class="icon-home"></i> 管理首页</a>
		<a href="/downer"  class="tip-bottom" data-original-title="下载器列表">下载器列表</a>
		<a href="/downer/create" class="current">添加下载器</a>
	</div>
@stop

@section('content')
	<div class="row-fluid">
		<div class="span12">
			
@if (Session::has('complete'))
<div class="alertSection row-fluid">
	<div class="alert alert-success alert-block">
		<a class="close" data-dismiss="alert" href="javascript:void(0);">×</a>
		<h4 class="alert-heading">成功了!</h4>
		{{ Session::get('complete') }}
	</div>
</div>
@endif

@if ($errors->all())
<div class="alert alert-error alert-block">
	<a class="close" data-dismiss="alert" href="#">×</a>
	<h4 class="alert-heading">错误!</h4>
	@foreach($errors->all() as $error)
	    {{ $error }}
	@endforeach
</div>
@endif

			<div class="widget-box">
				<div class="widget-title">
					<span class="icon">
						<i class="icon-globe"></i>
					</span>
					<h5>添加下载器</h5>
				</div>
				<div class="widget-content nopadding">
					<form class="form-horizontal" action="{{ URL::route('admin.downer.store') }}" method="post" />
						<div class="control-group">
							<label class="control-label">下载器名称 <span class="red bold">*</span></label>
							<div class="controls">
								<input type="text" name="name" />
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">下载器路径 <span class="red bold">*</span></label>
							<div class="controls">
								<input type="text" name="path" />
							</div>
						</div>

						<div class="control-group">
							<label class="control-label">下载器大小(MB)</label>
							<div class="controls">
								<input type="text" name="size" />
							</div>
						</div>

						<div class="control-group adContent">
							<label class="control-label">广告位布置 <span class="red bold">*</span></label>
							<div class="controls">

								<div class="widget-box" style="margin-right:220px;">
									<div class="widget-title">
										<span class="icon"><i class="icon-time"></i></span>
										<h5>广告位布置</h5>
										<div class="buttons">
											<a class="btn btn-mini btn-primary btnAddPage" href="javascript:;">
												<i class="icon-plus-sign icon-white"></i> 添加一页
											</a>
										</div>
									</div>
									<div class="widget-content nopadding">
										<table class="table table-striped table-bordered">
	                                        <thead>
	                                            <tr>
	                                                <th>页名称</th>
	                                                <th>广告位个数</th>
	                                                <th>操作</th>
	                                            </tr>
	                                        </thead>
	                                        <tbody class="pageTbody">
	                                            <tr>
	                                                <td class="taskDesc">
	                                                	<i class="icon-info-sign"></i> 备选区
	                                                </td>
	                                                <td class="taskStatus">
	                                                	<input type="text" name="altNum" placeholder="请填写备选区广告位数量" />
	                                                </td>
	                                                <td class="taskOptions"></td>
	                                            </tr>
	                                            <tr>
	                                                <td class="taskDesc">
														<input type="text" name="pageName[]" placeholder="请填写该页名称" />
	                                                </td>
	                                                <td class="taskStatus">
														<input type="text" name="pageNum[]" placeholder="请填写该页广告位数量" />
	                                                </td>
	                                                <td class="taskOptions">
	                                                	<a href="javascript:;" class="tip-top btnRmPage" data-original-title="删除该页">
	                                                		<i class="icon-remove"></i>
	                                                	</a>
	                                                </td>
	                                            </tr>

	                                        </tbody>
	                                    </table>
									</div>
								</div>
							</div>
						</div>

						<div class="form-actions">
							<input class="btn btn-primary" type="submit" value="提交" />
							<input class="btn btn-primary" type="reset" value="重置" />
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

@stop

@section('jsSection')
<script id="addPageTemp" type="x-tmpl-mustache">
<tr>
    <td class="taskDesc">
		<input type="text" name="pageName[]" placeholder="请填写该页名称" />
    </td>
    <td class="taskStatus">
		<input type="text" name="pageNum[]" placeholder="请填写该页广告位数量" />
    </td>
    <td class="taskOptions">
    	<a href="javascript:;" class="tip-top btnRmPage" data-original-title="删除该页">
    		<i class="icon-remove"></i>
    	</a>
    </td>
</tr>
</script>
<script type="text/javascript" src="/js/jquery.uniform.js"></script>
<script type="text/javascript" src="/js/select2.min.js"></script>
<script type="text/javascript" src="/js/mustache.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$("input[type=checkbox],input[type=radio]").uniform();
	$("select").select2();

	var pageTbody = $('.pageTbody');
	var btnRmPage = $(".btnRmPage");
	var btnAddPage = $(".btnAddPage");

	var addPageTemp = $("#addPageTemp").html();
	Mustache.parse(addPageTemp);

	var rmEventHandler = function(e){
		e.preventDefault();
		$(this).parentsUntil("tbody").remove();
	};
	btnRmPage.click(rmEventHandler);

	btnAddPage.click(function(e){
		e.preventDefault();
		var rendered = Mustache.render(addPageTemp, {});
		pageTbody.append($(rendered));
		$(".btnRmPage").click(rmEventHandler);
	});
	
});
</script>
@stop