@extends('common.layout')

@section('cssSection')
<link rel="stylesheet" href="/css/uniform.css" />
<link rel="stylesheet" href="/css/select2.css" />
<link rel="stylesheet" href="/css/bootstrap-datetimepicker.min.css" />
<link rel="stylesheet" href="/css/statwell.css" />
@stop

@section('header')
	<div id="content-header">
		<h1>物料统计</h1>
	</div>
	<div id="breadcrumb">
		<a href="/default" class="tip-bottom" data-original-title="回到首页"><i class="icon-home"></i> 管理首页</a>
		<a href="/sitestat/site"  class="tip-bottom" data-original-title="数据统计">数据统计</a>
		<a href="/sitestat/material" class="current">物料统计</a>
	</div>
@stop

@section('content')
<div class="row-fluid">
	<div class="statwell well">
		<span>
			<div id="dateChooser" class="btn-group" data-value="day">
			  <button data-value="day" class="btn active">本日</button>
			  <button data-value="week" class="btn">本周</button>
			  <button data-value="month" class="btn">本月</button>
			  <button data-value="time" class="btn">自定义</button>
			</div>
		</span>
		<span class="timeSpan" style="display:none;">
			<div class="input-append date form_datetime">
			  <input class="input-small" id="time-start" style="width:120px;" type="text" readonly />
			  <span class="add-on"><i class="icon-time"></i></span>
			</div>
			<span> 到 </span>
			<div class="input-append date form_datetime">
			  <input class="input-small" id="time-end" style="width:120px;" type="text" readonly />
			  <span class="add-on"><i class="icon-time"></i></span>
			</div>
		</span>
		<button id="timeOkBtn" class="btn btn-primary">查询</button>
	</div>

	<div class="widget-box">
		<div class="widget-title">
			<span class="icon">
				<i class="icon-align-left"></i>
			</span>
			<h5>统计详情</h5>
			<h5 class="alertSpan hide"></h5>
			<div class="buttons">
				<a id="exportCSVBtn" href="javascript:void(0);" class="btn btn-mini btn-info">
					<i class="icon icon-share-alt icon-white"></i> 导出列表
				</a>
			</div>
		</div>
		<div class="widget-content nopadding">
			<table id="statTable" class="table table-bordered">
				<thead>
					<tr>
						<th>物料</th>
						<th>展现</th>
						<th>勾选</th>
						<th>反勾选</th>
						<th>重复</th>
						<th>成功</th>
						<th>失败</th>
						<th>勾选率</th>
						<th>成功率</th>
					</tr>
				</thead>
				<tbody></tbody>
			</table>							
		</div>
	</div>
</div>
@stop

@section('jsSection')
<script id="trTemp" type="x-tmpl-mustache">
<tr>
	<td><% material %></td>
	<td><% show %></td>
	<td><% check %></td>
	<td><% uncheck %></td>
	<td><% repeat %></td>
	<td><% ok %></td>
	<td><% error %></td>
	<td><% checkrate %></td>
	<td><% okrate %></td>
</tr>
</script>
<script type="text/javascript" src="/js/jquery.uniform.js"></script>
<script type="text/javascript" src="/js/select2.min.js"></script>
<script type="text/javascript" src="/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript" src="/js/bootstrap-datetimepicker.zh-CN.js"></script>
<script type="text/javascript" src="/js/mustache.js"></script>
<script type="text/javascript" src="/js/moment-locales.min.js"></script>
<script type="text/javascript" src="/js/stat.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$("#exportCSVBtn").click(function(e){
		e.preventDefault();
		var timeType = $("#dateChooser").attr("data-value");

		if(!timeType || timeType=='') {
			showAlert("参数错误！","error");
			return false;
		}
		var duration = getDurationTime(timeType);
		var start = duration.start, end = duration.end;

		var uri = {
			_t : "material",
			_s : start,
			_e : end,
			is_csv : 1
		};
		window.open("/sitestat/data?"+$.param(uri));
	});

	$("#timeOkBtn").click(function(e){
		e.preventDefault();
		var timeType = $("#dateChooser").attr("data-value");

		if(!timeType || timeType=='') {
			showAlert("参数错误！","error");
			return false;
		}
		var duration = getDurationTime(timeType);
		var start = duration.start, end = duration.end;

		Mustache.tags = ["<%", "%>"];
		var tr_temp = $("#trTemp").html();
		Mustache.parse(tr_temp);

		var tbody = $("#statTable tbody");
		tbody.empty();

		$.getJSON("/sitestat/data", {
			_t : "material",
			_s : start,
			_e : end
		}, function(data){
			if(data.code != 0 || data.data == undefined){
				showAlert("查询失败！","error");
				return;
			}

			$.each(data.data, function(k,v){
				var tr = Mustache.render(tr_temp, v);
				tbody.append(tr);
			});
		});

	});
});
</script>
@stop