<!DOCTYPE html>
<html lang="en">
<head>
	<title>下载器后台系统</title>
	<meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="stylesheet" href="/css/bootstrap.min.css" />
	<link rel="stylesheet" href="/css/bootstrap-responsive.min.css" />
	<link rel="stylesheet" href="/css/unicorn.page.css" />
	@yield('cssSection')
</head>
<body>
	@yield('header')

	<div class="container-fluid">

		@yield('content')

	</div>
	<script type="text/javascript" src="/js/jquery.min.js"></script>
    <script type="text/javascript" src="/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="/js/jquery.ui.custom.js"></script>
    <script type="text/javascript">
	$(document).ready(function(){
		// === Tooltips === //
		$('.tip').tooltip();
		$('.tip-left').tooltip({ placement: 'left' });
		$('.tip-right').tooltip({ placement: 'right' });
		$('.tip-top').tooltip({ placement: 'top' });
		$('.tip-bottom').tooltip({ placement: 'bottom' });
	});
    </script>
	@yield('jsSection')
</body>
</html>