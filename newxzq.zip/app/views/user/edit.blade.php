@extends('common.layout')

@section('cssSection')
<link rel="stylesheet" href="/css/uniform.css" />
<link rel="stylesheet" href="/css/select2.css" />
@stop

@section('header')
	<div id="content-header">
		<h1>编辑用户</h1>
	</div>
	<div id="breadcrumb">
		<a href="/default" class="tip-bottom" data-original-title="回到首页"><i class="icon-home"></i> 管理首页</a>
		<a href="/user"  class="tip-bottom" data-original-title="用户列表">用户列表</a>
		<a href="{{ URL::route('admin.user.update', ['id' => $user['id']]) }}" class="current">编辑用户</a>
	</div>
@stop

@section('content')

	<div class="row-fluid">
		<div class="span12">
			@if ($errors->all())
			<div class="alert alert-error alert-block">
				<a class="close" data-dismiss="alert" href="#">×</a>
				<h4 class="alert-heading">错误!</h4>
				@foreach($errors->all() as $error)
				    {{ $error }}
				@endforeach
			</div>
			@endif
			<div class="widget-box">
				<div class="widget-title">
					<span class="icon">
						<i class="icon-globe"></i>
					</span>
					<h5>编辑用户</h5>
				</div>
				<div class="widget-content nopadding">
					<form class="form-horizontal" action="{{ URL::route('admin.user.update', ['id' => $user['id']]) }}" method="post" />
						<div class="control-group">
							<label class="control-label">Email</label>
							<div class="controls">
								<input type="text" name="email" value="{{$user['email'] or ''}}" />
							</div>
						</div>
						<div class="control-group">
							<label class="control-label">用户名</label>
							<div class="controls">
								<input type="text" name="first_name" value="{{$user['first_name'] or ''}}" />
							</div>
						</div>

						<div class="form-actions">
							<input class="btn btn-primary" type="submit" value="提交" />
							<input class="btn btn-primary" type="reset" value="重置" />
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

@stop

@section('jsSection')
<script type="text/javascript" src="/js/jquery.uniform.js"></script>
<script type="text/javascript" src="/js/select2.min.js"></script>
<script type="text/javascript">
	$('input[type=checkbox],input[type=radio],input[type=file]').uniform();
	$('select').select2({
		'width' : '200px'
	});
</script>
@stop