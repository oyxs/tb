@extends('common.layout')

@section('cssSection')
<link rel="stylesheet" href="/css/uniform.css" />
<link rel="stylesheet" href="/css/select2.css" />
<link rel="stylesheet" href="/css/bootstrap-datetimepicker.min.css" />
<link rel="stylesheet" href="/css/statwell.css" />
@stop

@section('header')
	<div id="content-header">
		<h1>物料统计</h1>
	</div>
	<div id="breadcrumb">
		<a href="/default" class="tip-bottom" data-original-title="回到首页"><i class="icon-home"></i> 管理首页</a>
		<a href="/stat/site"  class="tip-bottom" data-original-title="数据统计">数据统计</a>
		<a href="/stat/material" class="current">物料统计</a>
	</div>
@stop

@section('content')
<div class="row-fluid">
	<div class="statwell well">
		<select name="siteId" style="width:120px;">
			<option value="0">--选择站点--</option>
			@if (isset($sites) and !empty($sites))
			@foreach ($sites as $val)
				<option value="{{ $val['id'] }}">{{ $val['name'] }}</option>
			@endforeach
			@endif
		</select>
		<span>
			<select name="materialId" style="width:150px;">
				<option value="0">--选择物料--</option>
				@if (isset($materials) and !empty($materials))
				@foreach ($materials as $val)
					<option value="{{ $val['id'] }}">{{ $val['name'] }}</option>
				@endforeach
				@endif
			</select>
		</span>
		<span>
			<div id="dateChooser" class="btn-group" data-value="day">
			  <button data-value="day" class="btn active">本日</button>
			  <button data-value="week" class="btn">本周</button>
			  <button data-value="month" class="btn">本月</button>
			  <button data-value="time" class="btn">自定义</button>
			</div>
		</span>
		<span>
			<div id="destChooser" class="btn-group" data-value="day">
				<button data-value="day" title="按天显示" class="btn active">按天</button>
				<button data-value="hour" title="按小时显示" class="btn">按小时</button>
			</div>
		</span>
		<span class="timeSpan" style="display:none;">
			<div class="input-append date form_datetime">
			  <input class="input-small" id="time-start" style="width:110px;" type="text" />
			  <span class="add-on"><i class="icon-time"></i></span>
			</div>
			<span> 到 </span>
			<div class="input-append date form_datetime">
			  <input class="input-small" id="time-end" style="width:110px;" type="text" />
			  <span class="add-on"><i class="icon-time"></i></span>
			</div>
		</span>
		<button id="timeOkBtn" class="btn btn-primary">查询</button>
	</div>

	<div class="widget-box">
		<div class="widget-title">
			<span class="icon">
				<i class="icon-align-left"></i>
			</span>
			<h5>统计详情</h5>
			<h5 class="alertSpan hide"></h5>
			<div class="buttons">
				<a id="exportCSVBtn" href="javascript:void(0);" class="btn btn-mini btn-info">
					<i class="icon icon-share-alt icon-white"></i> 导出列表
				</a>
			</div>
			<div class="buttons">
				<a id="makehighcharts" href="javascript:void(0);" class="btn btn-mini btn-success">
					 查看曲线图
				</a>
			</div>
			<div class="buttons">
				<a id="checkline" href="javascript:void(0);" class="btn btn-mini btn-primary">
					 返回列表
				</a>
			</div>
		</div>
		<div class="widget-content nopadding">
			<table id="statTable" class="table table-bordered">
				<thead>
					<tr>
						<th>时间</th>
						<th>展现</th>
						<th>勾选</th>
						<th>反勾选</th>
						<th>重复</th>
						<th>成功</th>
						<th>失败</th>
						<th>勾选率</th>
						<th>成功率</th>
					</tr>
				</thead>
				<tbody></tbody>
			</table>
		</div>
	</div>
</div>

<!--<div id="highcharts" class="well"></div>-->
@stop
<div>
@section('jsSection')
<script id="trTemp" type="x-tmpl-mustache">
<tr>
	<td><% created_at %></td>
	<td><% show %></td>
	<td><% check %></td>
	<td><% uncheck %></td>
	<td><% repeat %></td>
	<td><% ok %></td>
	<td><% error %></td>
	<td><% checkrate %></td>
	<td><% okrate %></td>
</tr>
</script>
</div>
<div id="container" style="min-width:900px;height:600px;display:none"></div>
<script type="text/javascript" src="/js/jquery.uniform.js"></script>
<script type="text/javascript" src="/js/select2.min.js"></script>
<script type="text/javascript" src="/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript" src="/js/bootstrap-datetimepicker.zh-CN.js"></script>
<script type="text/javascript" src="/js/mustache.js"></script>
<script type="text/javascript" src="/js/moment-locales.min.js"></script>
<script type="text/javascript" src="/js/stat.js"></script>
<script type="text/javascript" src="/js/xx/highcharts.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	function mkcharts(titl,xaxis,serie){
				$('#container').highcharts({
						credits: {  enabled: false},//去掉highcharts.com商标
						title: titl,
						xAxis: xaxis,
						yAxis: {title: {text: '数据量(次)'},plotLines: [{value: 0,width: 1,color: '#808080'}]},
						legend: {layout: 'vertical',align: 'right',verticalAlign: 'middle',borderWidth: 0},
						series: serie
				});
		}
	$("#checkline").click(function(e){
		$("#container").hide();
		$("#statTable").show();
	});
	$("#exportCSVBtn").click(function(e){
		e.preventDefault();
		var siteId = $("select[name=siteId]").val();
		var materialId = $("select[name=materialId]").val();
		var timeType = $("#dateChooser").attr("data-value");
		var display = $("#destChooser").attr("data-value");

		if(!siteId || siteId=='') {
			showAlert("参数错误！","error");
			return false;
		}
		if(!timeType || timeType=='' || !display || display=='') {
			showAlert("参数错误！","error");
			return false;
		}
		var duration = getDurationTime(timeType);
		var start = duration.start, end = duration.end;

		var uri = {
			_t : "material",
			_sid : siteId,
			_mid : materialId,
			_s : start,
			_e : end,
			_d : display,
			is_csv : 1
		};
		window.open("/stat/data?"+$.param(uri));
	});

	$("#timeOkBtn").click(function(e){
		e.preventDefault();
		$("#container").hide();
		$("#statTable").show();
		var siteId = $("select[name=siteId]").val();
		var materialId = $("select[name=materialId]").val();
		var timeType = $("#dateChooser").attr("data-value");
		var display = $("#destChooser").attr("data-value");

		if(!siteId || siteId=='') {
			showAlert("参数错误！","error");
			return false;
		}
		if(!timeType || timeType=='' || !display || display=='') {
			showAlert("参数错误！","error");
			return false;
		}
		var duration = getDurationTime(timeType);
		var start = duration.start, end = duration.end;

		Mustache.tags = ["<%", "%>"];
		var tr_temp = $("#trTemp").html();
		Mustache.parse(tr_temp);

		var tbody = $("#statTable tbody");
		tbody.empty();

		$.getJSON("/stat/data", {
			_t : "material",
			_sid : siteId,
			_mid : materialId,
			_s : start,
			_e : end,
			_d : display
		}, function(data){
			if(data.code != 0 || data.data == undefined){
				showAlert("查询失败！","error");
				return;
			}

			$.each(data.data, function(k,v){
				var tr = Mustache.render(tr_temp, v);
				tbody.append(tr);
			});
		});

	});
	$("#makehighcharts").click(function(e){
		e.preventDefault();
		$("#statTable").hide();
		var siteId = $("select[name=siteId]").val();
		var materialId = $("select[name=materialId]").val();
		var timeType = $("#dateChooser").attr("data-value");
		var display = $("#destChooser").attr("data-value");

		var sitehtml = $("select[name=siteId] option:selected").text();

		if(!siteId || siteId=='') {
			showAlert("参数错误！","error");
			return false;
		}
		if(!timeType || timeType=='' || !display || display=='') {
			showAlert("参数错误！","error");
			return false;
		}
		var duration = getDurationTime(timeType);
		var start = duration.start, end = duration.end;
		$.getJSON("/stat/data", {
			_t : "material",
			_sid : siteId,
			_mid : materialId,
			_s : start,
			_e : end,
			_d : display
		}, function(data){
			if(data.code != 0 || data.data == undefined){
				showAlert("查询失败！","error");
				return;
			}
			var xAxis=new Array()
			var check_arr=new Array()
			var checkrate_arr=new Array()
			var error_arr=new Array()
			var ok_arr=new Array()
			var okrate_arr=new Array()//成功
			var repeat_arr=new Array()
			var show_arr=new Array()
			var uncheck_arr=new Array()
			var iii = 0;
			$.each(data.data,function(index,value){
	      xAxis[iii]=value.created_at;
	      check_arr[iii]=value.check;
	      repeat_arr[iii]=value.repeat;
	      error_arr[iii]=value.error;
	      ok_arr[iii]=value.ok;
	      show_arr[iii]=value.show;
	      okrate_arr[iii]=parseInt(value.okrate.split("%")[0]);
	      uncheck_arr[iii]=value.uncheck;
	      checkrate_arr[iii]=parseInt(value.checkrate.split("%")[0]);
	      iii++;
	    });
			var titl = {text: sitehtml+'曲线统计图',x: -20};
			var xaxis = {};
			xaxis.categories = xAxis;
			var serie = [{name: '展现',data: show_arr}, {name: '勾选',data: check_arr}, {name: '反勾选',data: uncheck_arr},  {name: '重复',data: repeat_arr},{name: '成功',data: ok_arr}, {name: '失败',data: error_arr}, {name: '勾选率(%)',data: checkrate_arr},{name: '成功率(%)',data: okrate_arr}];
			$("#container").show();
			mkcharts(titl,xaxis,serie);
			});
	});
});
</script>
@stop
