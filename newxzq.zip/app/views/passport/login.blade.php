<!DOCTYPE html>
<html lang="en">
    <head>
        <title>下载器后台系统</title>
		<meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="stylesheet" href="/css/bootstrap.min.css" />
		<link rel="stylesheet" href="/css/bootstrap-responsive.min.css" />
        <link rel="stylesheet" href="/css/unicorn.login.css" />
    </head>
    <body>
        <div id="logo">
            <img src="/img/logo.png" alt="下载器后台系统" />
        </div>
        <div id="loginbox">
            <form id="loginform" class="form-vertical">
				<p>输入用户名和密码登陆</p>
                <div class="control-group">
                    <div class="controls">
                        <div class="input-prepend">
                            <span class="add-on"><i class="icon-user"></i></span><input type="email" class="loginEmail" placeholder="E-mail" name="email" required="required" />
                        </div>
                    </div>
                </div>
                <div class="control-group">
                    <div class="controls">
                        <div class="input-prepend">
                            <span class="add-on"><i class="icon-lock"></i></span><input type="password" class="loginPassword" placeholder="密码" name="password" required="required" />
                        </div>
                    </div>
                </div>
                <div class="form-actions">
                    <span class="pull-left"><a href="javascript:void(0);" class="flip-link" id="to-recover">忘记密码？</a></span>
                    <span class="pull-right"><input type="submit" id="loginBtn" class="btn btn-inverse" value="登陆" /></span>
                    <span class="loginAlert hide"></span>
                </div>
            </form>
            <form id="recoverform" action="/forget" class="form-vertical">
				<p>输入E-mail，我们会把重置密码链接发到您的邮箱。</p>
				<div class="control-group">
                    <div class="controls">
                        <div class="input-prepend">
                            <span class="add-on"><i class="icon-envelope"></i></span><input type="text" placeholder="E-mail地址" />
                        </div>
                    </div>
                </div>
                <div class="form-actions">
                    <span class="pull-left"><a href="javascript:void(0);" class="flip-link" id="to-login">&lt; 回到登陆框</a></span>
                    <span class="pull-right"><input type="submit" class="btn btn-inverse" value="找回密码" /></span>
                </div>
            </form>
        </div>
        
        <script src="/js/jquery.min.js"></script>  
        <script src="/js/unicorn.login.js"></script> 
    </body>
</html>