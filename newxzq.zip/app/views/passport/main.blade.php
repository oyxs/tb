<!DOCTYPE html>
<html lang="en">
	<head>
		<title>下载器后台系统</title>
		<meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="stylesheet" href="/css/bootstrap.min.css" />
		<link rel="stylesheet" href="/css/bootstrap-responsive.min.css" />	
		<link rel="stylesheet" href="/css/unicorn.main.css" />
		<link rel="stylesheet" href="/css/unicorn.grey.css" class="skin-color" />
	</head>
	<body>
		<div id="header">
			<h1><a href="#">下载器后台系统</a></h1>		
		</div>

		<div id="user-nav" class="navbar navbar-inverse">
            <ul class="nav btn-group">
				<li class="btn btn-inverse dropdown" id="menu-messages"><a href="#" data-toggle="dropdown" data-target="#menu-messages" class="dropdown-toggle"><i class="icon icon-user"></i> <span class="text">{{ $currentUser }}</span> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a target="contentPage" href="/password">修改密码</a></li>
                    </ul>
                </li>
                <li class="btn btn-inverse"><a href="/logout"><i class="icon icon-share-alt"></i> <span class="text">退出登陆</span></a></li>
            </ul>
        </div>

		<div id="sidebar">
			<ul>
				@foreach ($menus as $menu)
				<li class="{{ isset($menu['submenu']) ? 'submenu' : 'primarymenu' }} {{ $menu['li-class'] or ''}}">
					<a href="{{ isset($menu['submenu']) ? 'javascript:void(0);' : $menu['url'] }}">
						<i class="icon {{ $menu['icon-class'] }}"></i> 
						<span>{{ $menu['title'] }}</span>
						@if (isset($menu['submenu']))
						<span class="label">{{ count($menu['submenu']) }}</span>
						@endif
					</a>
					@if (isset($menu['submenu']))
					<ul>

						@foreach ($menu['submenu'] as $submenu)

						<li class=""><a href="{{ $submenu['url'] }}">{{ $submenu['title'] }}</a></li>

						@endforeach

					</ul>
					@endif
				</li>
				@endforeach
			</ul>
		<div id="style-sidebar">
			<i class="icon-arrow-left icon-white"></i>
		</div>
		</div>
		<div id="style-switcher">
			<i class="icon-arrow-left icon-white"></i>
			<span>切换主题:</span>
			<a href="#grey" style="background-color: #555555;border-color: #aaaaaa;"></a>
			<a href="#blue" style="background-color: #2D2F57;"></a>
			<a href="#red" style="background-color: #673232;"></a>
		</div>
		
		<div id="content">
			<iframe src="/default" name="contentPage" frameborder="0"></iframe>
			<div id="footer">
				{{{ date('Y') }}} &copy; 日月同行科技有限公司. 
			</div>
		</div>

        <script type="text/javascript" src="/js/jquery.min.js"></script>
        <script type="text/javascript" src="/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="/js/jquery.ui.custom.js"></script>
        <script type="text/javascript" src="/js/unicorn.main.js"></script>
	</body>
</html>
