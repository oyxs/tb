@extends('common.layout')

@section('cssSection')
@stop

@section('header')
	<div id="content-header">
		<h1>管理首页</h1>
	</div>
	<div id="breadcrumb">
		<a href="/default"><i class="icon-home"></i> 管理首页</a>
	</div>
@stop

@section('content')

	<div class="row-fluid">
		<div class="span12">
			@if ($errors->all())
			<div class="alert alert-error alert-block">
				<a class="close" data-dismiss="alert" href="#">×</a>
				<h4 class="alert-heading">错误!</h4>
				@foreach($errors->all() as $error)
				    {{ $error }}
				@endforeach
			</div>
			@endif

			@if (Session::has('complete'))
			<div class="alertSection row-fluid">
				<div class="alert alert-success alert-block">
					<a class="close" data-dismiss="alert" href="javascript:void(0);">×</a>
					<h4 class="alert-heading">成功了!</h4>
					{{ Session::get('complete') }}
				</div>
			</div>
			@endif

		</div>
	</div>

@stop

@section('jsSection')
@stop