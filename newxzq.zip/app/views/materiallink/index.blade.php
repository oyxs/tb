@extends('common.layout')

@section('cssSection')
<link rel="stylesheet" href="/css/uniform.css" />
<link rel="stylesheet" href="/css/select2.css" />
@stop

@section('header')
	<div id="content-header">
		<h1>产品包链接列表</h1>
	</div>
	<div id="breadcrumb">
		<a href="/default" class="tip-bottom" data-original-title="回到首页"><i class="icon-home"></i> 管理首页</a>
		<a href="/material" class="current">产品包链接列表</a>
	</div>
@stop

@section('content')

@if (Session::has('complete'))
<div class="alertSection row-fluid">
	<div class="alert alert-success alert-block">
		<a class="close" data-dismiss="alert" href="javascript:void(0);">×</a>
		<h4 class="alert-heading">成功了!</h4>
		{{ Session::get('complete') }}
	</div>
</div>
@endif

<div class="alertSection row-fluid">
	<a class="btn btn-success btn-mini " title="添加产品包链接" href="{{ URL::route('admin.link.create', ['id'=>$data['material']['id']]) }}"><i class="icon-plus icon-white"></i> 添加产品包链接</a>
	<a class="btn btn-primary btn-mini " title="编辑产品包链接" href="{{ URL::route('admin.link.edit', ['id'=>$data['material']['id']]) }}"><i class="icon-pencil icon-white"></i> 编辑产品包链接</a>
</div>
<div class="widget-box">
	<div class="widget-title">
		<span class="icon">
			<i class="icon-file"></i>
		</span>
		<h5>广告产品列表</h5>
	</div>
	<div class="widget-content nopadding">
		<table class="table table-bordered data-table">
			<thead>
				<tr>
					<th>产品名称</th>
					<th>软件包名</th>
					<th>渠道链接</th>
				</tr>
			</thead>
			<tbody>
				@foreach ($data['mlink'] as $val)
				<tr>
					<td>{{ $data['material']['name'] }}</td>
					<td>{{ $val['name'] }}</td>
					<td>{{ $val['link'] }}</td>
				</tr>
				@endforeach
			</tbody>
		</table>					
	</div>
</div>
@stop

@section('jsSection')
<script type="text/javascript" src="/js/select2.min.js"></script>
<script type="text/javascript" src="/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="/js/rest.js"></script>
<script type="text/javascript" src="/js/jquery.uniform.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$('input[type=checkbox],input[type=radio],input[type=file]').uniform();
	$('select').select2();
});
</script>
@stop