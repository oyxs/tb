@extends('common.layout')

@section('cssSection')
<link rel="stylesheet" href="/css/uniform.css" />
<link rel="stylesheet" href="/css/select2.css" />
<link rel="stylesheet" href="/css/product.css" />
@stop

@section('header')
	@if (Session::has('complete'))
	<div class="alertSection row-fluid">
		<div class="alert alert-success alert-block">
			<a class="close" data-dismiss="alert" href="javascript:void(0);">×</a>
			<h4 class="alert-heading">成功了!</h4>
			{{ Session::get('complete') }}
		</div>
	</div>
	@endif
	<div id="content-header">
		<h1>添加产品包链接</h1>
	</div>
	<div id="breadcrumb">
		<a href="/default" class="tip-bottom" data-original-title="回到首页"><i class="icon-home"></i> 管理首页</a>
		<a href="/link/{{ $data['material']['id'] }}/create" class="current">添加产品包链接</a>
	</div>
@stop

@section('content')
	<div class="row-fluid">
		<div class="span12">
			@if ($errors->all())
			<div class="alert alert-error alert-block">
				<a class="close" data-dismiss="alert" href="#">×</a>
				<h4 class="alert-heading">错误!</h4>
				@foreach($errors->all() as $error)
				    {{ $error }}
				@endforeach
			</div>
			@endif
			<div class="widget-box">
				<div class="widget-title">
					<span class="icon">
						<i class="icon-file"></i>
					</span>
					<h5>添加{{ $data['material']['name'] }}的下载链接</h5>
				</div>
				<div class="widget-content nopadding">
					<form class="well" action="{{ URL::route('admin.link.store') }}" method="post" >
						<div class="form-inline">
							<input type="hidden"  name="materialId"  value="{{ $data['material']['id'] }}"/>
							<input type="text" class="input-xxlarge"  placeholder="输入下载地址" name="link">
							<input type="text" class="input-medium"  placeholder="软件包渠道号" name="name">
							<input type="text" class="input-medium"  placeholder="软件包名" name="pname">
							<input type="text" class="input-medium"  placeholder="静默参数" name="cmdLine">
						</div>
						<div class="clearfix"></div>
						<div class="form-horizontal" >
							<div class="control-group">
								<label class="control-label">备注信息：</label>
								<div class="controls">
									<textarea name="remarks" class="input-small" rows="4"  placeholder="最多输入255个字符" ></textarea>
								</div>
							</div>
							<div class="form-actions">
								<input class="btn btn-primary" type="submit" value="确认添加" />
							</div>
						</div>
					</form>
				</div>
				<div class="widget-content nopadding">
					<table class="table table-bordered data-table">
						<thead>
							<tr>
								<th>软件包下载地址</th>
								<th>软件包渠道号</th>
								<th>软件包名称</th>
								<th>静默参数</th>
								<th>备注</th>
								<th>操作</th>
							</tr>
						</thead>
						<tbody>
							@foreach ($data['mlinks'] as $val)
							<tr>
								<td>{{ $val['link'] }}</td>
								<td>{{ $val['name'] }}</td>
								<td>{{ $val['pname'] }}</td>
								<td>{{ $val['cmdLine'] }}</td>
								<td>{{ $val['remarks'] }}</td>
								<td>
									<a class="btn btn-primary btn-mini editBtn" dataId="{{ $val['id'] }}" title="编辑产品" href="{{ URL::route('admin.link.edit', ['id'=>$val['id']]) }}"> 编辑</a>
									@if($val['enabled'])
									<a class="btn btn-danger btn-mini enabled" data-link="{{ URL::route('admin.link.enabled', ['id'=>$val['id']]) }}" title="禁用" role="button" > 禁用</a>
									@else
									<a class="btn btn-danger btn-mini enabled" data-link="{{ URL::route('admin.link.enabled', ['id'=>$val['id']]) }}" title="启用" role="button" >	启用</a>
									@endif
								</td>
							</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
@stop

@section('jsSection')
<script type="text/javascript" src="/js/select2.min.js"></script>
<script type="text/javascript" src="/js/jquery.dataTables.min.js"></script>
<script >
$(document).ready(function(){
	var enabled = function(){
		if(confirm("【注意】：确定要禁用该链接吗")){
			if(confirm("【注意】：禁用后所有在线上是链接都会下线哦！")){
				window.location.href=$(this).attr('data-link');
			}
		}
	}
	$('.data-table').dataTable({
		"bJQueryUI": true,
		"pageLength": 10,
		"sPaginationType": "full_numbers",
		"sDom": '<"">t<"F"fp>',
		"language": {
			"paginate": {
			  "first": "首页",
			  "last": "尾页",
			  "previous": "上一页",
			  "next": "下一页"
			},
			"lengthMenu": "显示 _MENU_ 条记录",
			"search":"搜索："
		}
	});
	$('.enabled').click(enabled);
});
</script>
@stop