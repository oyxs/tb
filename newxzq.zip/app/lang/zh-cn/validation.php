<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| Validation Language Lines
	|--------------------------------------------------------------------------
	|
	| following language lines contain default error messages used by
	| validator class. Some of these rules have multiple versions such
	| as size rules. Feel free to tweak each of these messages here.
	|
	*/

	"accepted"             => ":attribute必须是被接受的。",
	"active_url"           => ":attribute不是一个可用的URL。",
	"after"                => ":attribute必须为一个在:date之后的时间。",
	"alpha"                => ":attribute只可包含字母。",
	"alpha_dash"           => ":attribute只可包含字母、数字和'-'。",
	"alpha_num"            => ":attribute只可包含字母、数字。",
	"array"                => ":attribute必须是一个数组。",
	"before"               => ":attribute必须为一个在:date之前的时间。",
	"between"              => array(
		"numeric" => ":attribute必须在:min和:max之间。",
		"file"    => ":attribute必须在:min KB和:max KB之间。",
		"string"  => ":attribute必须在:min 个字符到:max 个字符之间。",
		"array"   => ":attribute必须包含:min到:max个元素。",
	),
	"boolean"              => ":attribute字段必须是true或者false。",
	"confirmed"            => ":attribute确认信息不匹配。",
	"date"                 => ":attribute不是一个合法的时间。",
	"date_format"          => ":attribute不符合:format的时间格式。",
	"different"            => ":attribute和:other必须为不同值。",
	"digits"               => ":attribute必须为:digits位数字。",
	"digits_between"       => ":attribute必须为:min到:max位数字。",
	"email"                => ":attribute必须为合法的EMAIL地址。",
	"exists"               => "selected :attribute不合法。",
	"image"                => ":attribute必须是个图片。",
	"in"                   => "selected :attribute不合法。",
	"integer"              => ":attribute必须是个整数。",
	"ip"                   => ":attribute必须是合法的IP地址。",
	"max"                  => array(
		"numeric" => ":attribute不应该大于:max。",
		"file"    => ":attribute不应该大于:max KB。",
		"string"  => ":attribute不应该大于:max 个字符。",
		"array"   => ":attribute不应该多于:max 个元素。",
	),
	"mimes"                => ":attribute必须一个类型为：:values的文件。",
	"min"                  => array(
		"numeric" => ":attribute必须大于:min。",
		"file"    => ":attribute必须大于:min KB。",
		"string"  => ":attribute必须大于:min 个字符。",
		"array"   => ":attribute必须至少有:min个元素。",
	),
	"not_in"               => "selected :attribute不合法。",
	"numeric"              => ":attribute必须是个数字。",
	"regex"                => ":attribute格式不正确。",
	"required"             => ":attribute不可为空。",
	"required_if"          => "当:other等于:value时，:attribute不可为空。",
	"required_with"        => "当:values有值时，:attribute不可为空。",
	"required_with_all"    => "当:values有值时，:attribute不可为空。",
	"required_without"     => "当:values无值时，:attribute不可为空。",
	"required_without_all" => "当:values都无值时，:attribute不可为空。",
	"same"                 => ":attribute和:other必须匹配。",
	"size"                 => array(
		"numeric" => ":attribute必须为:size。",
		"file"    => ":attribute大小必须为:size KB。",
		"string"  => ":attribute必须为:size字符。",
		"array"   => ":attribute必须包含:size个元素。",
	),
	"unique"               => ":attribute为重复条目。",
	"url"                  => ":attribute不是合法的URL。",
	"timezone"             => ":attribute不是合法的时区。",

	/*
	|--------------------------------------------------------------------------
	| Custom Validation Language Lines
	|--------------------------------------------------------------------------
	|
	| Here you may specify custom validation messages for attributes using the
	| convention "attribute.rule" to name lines. This makes it quick to
	| specify a specific custom language line for a given attribute rule.
	|
	*/

	'custom' => array(
		'attribute-name' => array(
			'rule-name' => 'custom-message',
		),
	),

	/*
	|--------------------------------------------------------------------------
	| Custom Validation Attributes
	|--------------------------------------------------------------------------
	|
	| following language lines are used to swap attribute place-holders
	| with something more reader friendly such as E-Mail Address instead
	| of "email". This simply helps us make messages a little cleaner.
	|
	*/

	'attributes' => array(),

);
