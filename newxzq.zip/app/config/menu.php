<?php
return array(
	'admin.default' => array(
		'title' => '首页',
		'icon-class' => 'icon-home',
		'li-class' => 'active open',
		'url' => URL::route('admin.default')
	),

	'admin.ad' => array(
		'title' => '广告管理',
		'icon-class' => 'icon-picture',
		'submenu' => array(
			'admin.ad.index' => array(
				'title' => '广告列表',
				'url' => URL::route('admin.ad.index')
			),
			'admin.ad.create' => array(
				'title' => '发布广告',
				'url' => URL::route('admin.ad.create')
			),
			'admin.ad.material' => array(
				'title' => '添加物料',
				'url' => URL::route('admin.ad.index')
			),
		),
	),

	'admin.material' => array(
		'title' => '广告物料管理',
		'icon-class' => 'icon-file',
		'submenu' => array(
			'admin.material.index' => array(
				'title' => '广告物料列表',
				'url' => URL::route('admin.material.index')
			),
			'admin.material.create' => array(
				'title' => '添加广告物料',
				'url' => URL::route('admin.material.create')
			)
		)
	),
		'admin.newad' => array(
				'title' => '新广告物料管理',
				'icon-class' => 'icon-user',
				'submenu' => array(
						'admin.newad.index' => array(
								'title' => '物料列表',
								'url' => URL::route('admin.newad.index')
						),
						'admin.newad.create' => array(
								'title' => '添加物料',
								'url' => URL::route('admin.newad.create')
						)
				),
		),
//	'admin.material.createproduct' => array(
//		'title' => '添加产品',
//		'icon-class' => 'icon-file',
//		'url' => URL::route('admin.material.createproduct')
//	),
	'admin.downer' => array(
		'title' => '下载器管理',
		'icon-class' => 'icon-download-alt',
		'submenu' => array(
			'admin.downer.index' => array(
				'title' => '下载器列表',
				'url' => URL::route('admin.downer.index')
			),
			'admin.downer.create' => array(
				'title' => '添加下载器',
				'url' => URL::route('admin.downer.create')
			)
		),
	),

	'admin.site' => array(
		'title' => '站点管理',
		'icon-class' => 'icon-globe',
		'submenu' => array(
			'admin.site.index' => array(
				'title' => '站点列表',
				'url' => URL::route('admin.site.index')
			),
			'admin.site.create' => array(
				'title' => '添加站点',
				'url' => URL::route('admin.site.create')
			),
			'admin.site.batchextra' => array(
				'title' => '高级选项',
				'url' => URL::route('admin.site.batchextra')
			)
		),
	),

	'admin.stat' => array(
		'title' => '数据统计',
		'icon-class' => 'icon-align-left',
		'submenu' => array(
			// 管理员统计
			'admin.stat.site' => array(
				'title' => '网站概况',
				'url' => URL::route('admin.stat.site')
			),
			'admin.stat.material' => array(
				'title' => '物料统计',
				'url' => URL::route('admin.stat.material')
			),
			'admin.stat.newmaterial' => array(
					'title' => '顶部物料统计',
					'url' => URL::route('admin.stat.newmaterial')
			),
			'admin.stat.broadsidematerial' => array(
						'title' => '侧边料统计',
						'url' => URL::route('admin.stat.broadsidematerial')
			),
			'admin.stat.materialSum' => array(
				'title' => '物料推广汇总',
				'url' => URL::route('admin.stat.materialSum')
			),
			'admin.stat.siteSum' => array(
				'title' => '站点推广汇总',
				'url' => URL::route('admin.stat.siteSum')
			),

			// 合作站点统计
			'admin.stat.sitesite' => array(
				'title' => '网站概况',
				'url' => URL::route('admin.stat.sitesite')
			),
			'admin.stat.sitematerial' => array(
				'title' => '物料统计',
				'url' => URL::route('admin.stat.sitematerial')
			),

		),
	),
	
//	'admin.charge' =>array(
//		'title' => '所有站点数据汇总',
//		'icon-class' => 'icon-align-left',
//		'submenu' => array(
//			'admin.charge.material' =>array(
//				'title' => '下载器数据明细',
//				'url' => URL::route('admin.charge.material')
//			),
//			'admin.charge.add' =>array(
//				'title' => '下载器数据录入',
//				'url' => URL::route('admin.charge.add')
//			),
//			'admin.charge.chargestat' =>array(
//				'title' => '站点产品详细数据',
//				'url' => URL::route('admin.charge.chargestat')
//			),
//		)
//	),

	'admin.user' => array(
		'title' => '用户管理',
		'icon-class' => 'icon-user',
		'submenu' => array(
			'admin.user.index' => array(
				'title' => '用户列表',
				'url' => URL::route('admin.user.index')
			),
			'admin.user.create' => array(
				'title' => '添加用户',
				'url' => URL::route('admin.user.create')
			)
		),
	),

	'admin.password' => array(
		'title' => '修改密码',
		'icon-class' => 'icon-cog',
		'url' => URL::route('admin.password')
	),
);
