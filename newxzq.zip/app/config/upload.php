<?php
return array(
	'ICON_MIME' => array(
		'image/jpeg', 
		'image/jpg', 
		'image/x-ms-bmp', 
		'image/gif', 
		'image/png', 
		'image/pjpeg',
		'image/x-icon'
	),

	'ICON_MAX_SIZE' => 2 * 1024 * 1024,


	'SOFT_MIME' => [
		'application/octet-stream'
	],

	'SOFT_MAX_SIZE' => 10 * 1024 * 1024,
);