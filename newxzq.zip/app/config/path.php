<?php
return array(
	'ACCESS_LOG_PATH' => '/data0/logs/nginx/api.zheguow.com',

	'DOWN_XML_PATH' => public_path() . '/xml',

	'UPLOAD_PATH' => public_path() . '/upload',

	'UPLOAD_URL' => '/upload',

	'SOFT_PATH' => public_path() . '/soft',

	'SOFT_URL' => '/soft',
);
