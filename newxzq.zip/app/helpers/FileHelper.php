<?php
class FileHelper {
	
	public static function fileRowMap($file, $closure, &$return) {
		$handle = @fopen($file, "r");
		if (!$handle) {
			return false;
		}
	    while (($row = @fgets($handle)) !== false) {
	    	$closure($row, $return);
	    }
	    fclose($handle);
	}

	public static function scanViewDir($dir) {
		if(!file_exists($dir)){
			return false;
		}
		$files = scandir($dir);
		$result = array();
		foreach ($files as $value) {
			if($value == '.' || $value == '..'){
				continue;
			}
			if(0 < preg_match('/^(\w+).blade.php/', $value, $out)){
				$result[] = $out[1];
			}
		}
		return $result;
	}
}