<?php
class MenuHelper {

	/**
     * Get Menus.
     */
	public static function getAuthorizedMenus($permissions, $current)
	{
		// get this user's valid menus
		$menus = Config::get('menu');
		$invalid_menus = array();
		foreach ($menus as $key => $value) {
			if(!array_key_exists($key, $permissions) || !$permissions[$key]){
				continue;
			}
			$invalid_menus[$key] = $value;
			if(0 === strpos($current, $key)){
				$invalid_menus[$key]['active'] = true;
			}
			// get invalid sub menus
			if(isset($value['submenu']) && !empty($value['submenu'])){
				foreach ($value['submenu'] as $k => $v) {
					if(!array_key_exists($k, $permissions) || !$permissions[$k]){
						unset($invalid_menus[$key]['submenu'][$k]);
					}
					if($k === $current){
						$invalid_menus[$key]['submenu'][$k]['active'] = true;
					}
				}
			}
		}
		return $invalid_menus;
	}
}