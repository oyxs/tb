<?php
class CurlHelper {
	/* 
	* ��ȡurl״̬��
	* 
	* @function getHttpStatus
	* @param $url string	url����
	* @return int ״̬��
	*/
	public static function getHttpCode($url) {
		$ch = curl_init();
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch,CURLOPT_HEADER,0);
		curl_exec($ch);
		$httpCode = curl_getinfo($ch,CURLINFO_HTTP_CODE);  
		curl_close($ch);
		return $httpCode;
	}
}