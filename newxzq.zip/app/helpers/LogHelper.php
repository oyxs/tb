<?php
/**
 * @author zyx
 * @version 20150723
 * log_format '$remote_addr |-| $time_local |-| $request |-| $http_referer |-| $http_user_agent';
 */
class LogHelper {
	public $site_stat = array();
	public $material_stat = array();
	public $uri = array();

	const REGEXP_XML = '/\/xml\/(\d+)(.*) HTTP\/1.1$/';
	const REGEXP_STAT = '/\/stat\?(.+) HTTP\/1.1$/';
	const REGEXP_ERROR = '/\/error\?(.+) HTTP\/1.1$/';

	public function parseAccess($file) {
		$handle = @fopen($file, "r");
		if (!$handle) {
			return false;
		}
	    while (($row = @fgets($handle)) !== false) {
			$arr = explode(' |-| ', $row);
	    	if(isset($arr[2]) && !empty($arr[2])){
	    		if(preg_match(static::REGEXP_XML, $arr[2], $out)) {
	    			echo "xml:{$out[1]}\n";
	    			$this->parseXmlLog($out[1],$out[2]);
	    		} elseif(preg_match(static::REGEXP_STAT, $arr[2], $out)) {
	    			echo "stat:{$out[1]}\n";
	    			$this->parseStatLog($out[1]);
	    		} elseif (preg_match(static::REGEXP_ERROR, $arr[2], $out)) {
	    			echo "error:{$out[1]}\n";
	    			$this->parseErrorLog($out[1]);
	    		}
	    	}
	    }
	    fclose($handle);
	    return true;
	}

	/**
	 * 解析广告XML的访问日志
	 * @return array
	 */
	public function parseXmlLog($val,$param) {
		parse_str($param, $params);
		if(array_key_exists($param,$this->uri)){
			return true;
		}else{
			$this->uri[$param]=1;
		}
		if(isset($params['userev']) && intval($params['userev'])>0){
			$webid="41_".$val;
		}else{
			$webid=$val.'_0';
		}
		$this->incrSiteCount($webid, 'open');
	}

	/**
	 * 解析广告统计的访问日志
	 * @return array
	 */
	public function parseStatLog($val) {
		parse_str($val, $params);
		if(array_key_exists($val,$this->uri)){
			return true;
		}else{
			$this->uri[$val]=1;
		}
		// 获取站点id
		if(!isset($params['webid']) || intval($params['webid']) <= 0){
			return;
		}
		if(isset($params['userev']) && intval($params['userev'])>0){
			$webid = "41_".intval($params['webid']);
		}else{
			$webid = intval($params['webid'])."_0";
		}
		// 解析当前日志条目退出的步骤
		if(isset($params['step']) && intval($params['step']) > 0) {
			switch ($params['step']) {
				case 1:
					$this->incrSiteCount($webid, 'one');
					break;
				case 2:
					$this->incrSiteCount($webid, 'two');
					break;
				case 3:
					$this->incrSiteCount($webid, 'three');
					break;
				case 4:
					$this->incrSiteCount($webid, 'four');
					break;
			}
		}

		$this->parseParamsItem($params, 'show');
		$this->parseParamsItem($params, 'check');
		$this->parseParamsItem($params, 'uncheck');
		$this->parseParamsItem($params, 'repeat');
		$this->parseParamsItem($params, 'ok');
		$this->parseParamsItem($params, 'error');
	}

	/**
	 * 解析错误日志
	 * @return array
	 */
	public function parseErrorLog($val) {
		parse_str($val, $params);
		// 获取站点id
		if(!isset($params['webid']) || intval($params['webid']) <= 0){
			return false;
		}
		if(isset($params['userev']) && intval($params['userev'])>0){
			$webid = "41_".intval($params['webid']);
		}else{
			$webid = intval($params['webid'])."_0";
		}
		return $this->incrSiteCount($webid, 'error');
	}

	/**
	 * 解析多个值得参数
	 * 形如：1|2|3|4
	 * @return array
	 */
	private function parseParamsItem($params, $index){
		if(!isset($params[$index]) || empty($params[$index])){
			return false;
		}
		if(isset($params['userev']) && intval($params['userev'])>0){
			$webid = "41_".intval($params['webid']);
		}else{
			$webid = intval($params['webid'])."_0";
		}
		$array = explode('|', $params[$index]);
		foreach ($array as $value) {
			$this->incrMaterialCount($webid, $value, $index);
		}
		return true;
	}

	public function incrSiteCount($webid, $key) {
		if(intval($webid) <= 0) {
			return false;
		}
		if(!in_array($key, ['open','one','two','three','four','error'])) {
			return false;
		}
	    if(!isset($this->site_stat[$webid])){
	    	$this->site_stat[$webid]= [
				'open' => 0,
				'one' => 0,
				'two' => 0,
				'three' => 0,
				'four' => 0,
				'error' => 0
	    	];
		}
		$this->site_stat[$webid][$key]++;
		return true;
	}

	public function incrMaterialCount($webid, $materialid, $key) {
		if(intval($webid) <= 0 || intval($materialid) <= 0) {
			return false;
		}
		if(!in_array($key, ['show','check','uncheck','repeat','ok','error'])) {
			return false;
		}
		if(!isset($this->material_stat[$webid])) {
			$this->material_stat[$webid]= array();
		}
	    if(!isset($this->material_stat[$webid][$materialid])){
	    	$this->material_stat[$webid][$materialid] = [
				'show' => 0,
				'check' => 0,
				'uncheck' => 0,
				'repeat' => 0,
				'ok' => 0,
				'error' => 0
	    	];
		}
		$this->material_stat[$webid][$materialid][$key]++;
		return true;
	}
}