<?php
class TimeHelper {

	public static function getDate($time) {
		$array = array();
		if(is_string($time) && false !== strtotime($time)){
			return date_parse($time);
		} elseif(intval($time) > 0) {
			$arr = getdate($time);
			return array(
				'year' => $arr['year'],
				'month' => $arr['mon'],
				'day' => $arr['mday'],
				'hour' => $arr['hours'],
				'minute' => $arr['minutes'],
				'second' => $arr['seconds']
			);
		} else {
			return false;
		}
	}

	public static function getIntegralHour($time) {
		$time = self::getDate($time);
		if(!$time){
			return false;
		}
		return mktime($time['hour'],0,0,$time['month'],$time['day'],$time['year']);
	}

	public static function getIntegralDay($time) {
		$time = self::getDate($time);
		if(!$time){
			return false;
		}
		return mktime(0,0,0,$time['month'],$time['day'],$time['year']);
	}

	public static function getEndTime($time) {
		$time = self::getDate($time);
		if(!$time){
			return false;
		}
		if($time['hour'] == 0){
			$time['hour'] = 23;
		}
		if($time['minute'] == 0){
			$time['minute'] = 59;
		}
		if($time['second'] == 0){
			$time['second'] = 59;
		}
		return mktime($time['hour'],$time['minute'],$time['second'],$time['month'],$time['day'],$time['year']);
	}

}