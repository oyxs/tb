#!/bin/bash
#@author:Haletone(wenxiaotong@rytx.com)
#该文件是用来检测站点服务器是否可以正常访问，负责进行服务器自动切换

#网站根目录
admin_path="/home/wwwroot/admin.down.72zx.com/"
#分析日志
/usr/bin/php ${admin_path}artisan command:check