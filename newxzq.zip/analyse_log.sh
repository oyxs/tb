#!/bin/bash
#@author:Alex(11806947@qq.com)
#该文件是切割并分析下载器的访问日志

#设置日志文件存放目录
logs_path="/data0/logs/nginx/jiekou.zheguow.com/"
#设置pid文件
pid_path="/run/nginx.pid"
#网站根目录
admin_path="/data0/web/xzq.zheguow.com/"

if [ ! -d ${logs_path}$(date -d "today" +"%Y%m%d") ]
then
  mkdir ${logs_path}$(date -d "today" +"%Y%m%d")
fi

#重命名日志文件
mv ${logs_path}access.log ${logs_path}$(date -d "today" +"%Y%m%d")/access_$(date -d "today" +"%Y%m%d%H").log

#向nginx主进程发信号重新打开日志
/usr/local/webserver/nginx/sbin/nginx -s reload

#分析日志
/usr/local/webserver/php/bin/php ${admin_path}artisan command:analytics
